package io.github.kimovoid.reframed;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_43718703;
import net.minecraft.unmapped.C_95807626;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;

/**
 * Most of this stuff was ported from <a href="https://modrinth.com/mod/gambac">Gambac</a>
 * Credits to DanyGames2014
 */
public class ReframedMinecraft extends Minecraft {

    private final int previousWidth;
    private final int previousHeight;

    public ReframedMinecraft(int w, int h, boolean fullscreen) {
        super(null, null, null, w, h, fullscreen);
        this.previousWidth = w;
        this.previousHeight = h;
    }

    @Override
    public void m_49334482(C_95807626 crashSummary) {
        io.github.kimovoid.reframed.lwjgl3compat.CrashReport.report(crashSummary);
        this.m_12353564();
        System.exit(-1);
    }

    @Override
    public void m_67975642() {
        if (Display.getWidth() != this.f_31800787 || Display.getHeight() != this.f_74192110) {
            this.onResolutionChanged(Display.getWidth(), Display.getHeight());
        }

        super.m_67975642();
    }

    @Override
    public void m_87006267() {
        try {
            this.f_96101654 = !this.f_96101654;

            if (f_96101654) {
                this.f_31800787 = Display.getWidth();
                this.f_74192110 = Display.getHeight();

                Display.setDisplayMode(Display.getDesktopDisplayMode());
                this.f_31800787 = Display.getDisplayMode().getWidth();
                this.f_74192110 = Display.getDisplayMode().getHeight();
            } else {
                this.f_31800787 = this.previousWidth;
                this.f_74192110 = this.previousHeight;
                Display.setDisplayMode(new DisplayMode(this.f_31800787, this.f_74192110));
            }
            if (this.f_31800787 <= 0) {
                this.f_31800787 = 1;
            }
            if (this.f_74192110 <= 0) {
                this.f_74192110 = 1;
            }

            if (this.f_70816363 != null) {
                this.onResolutionChanged(this.f_31800787, this.f_74192110);
            }

            Display.setFullscreen(f_96101654);
            Display.update();
        } catch (Exception ignored) {}
    }

    private void onResolutionChanged(int w, int h) {
        if (w <= 0) {
            w = 1;
        }
        if (h <= 0) {
            h = 1;
        }
        this.f_31800787 = w;
        this.f_74192110 = h;
        if (this.f_70816363 != null) {
            C_43718703 scaled = new C_43718703(this.f_58088711, w, h);
            int scaledWidth = scaled.m_39119333();
            int scaledHeight = scaled.m_16103615();
            this.f_70816363.m_55923303(this, scaledWidth, scaledHeight);
        }
    }
}