package io.github.kimovoid.reframed.mixin;

import io.github.kimovoid.reframed.ReframedMinecraft;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MinecraftApplet;
import net.minecraft.unmapped.C_87604186;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import java.applet.Applet;

@SuppressWarnings({"removal"})
@Mixin(MinecraftApplet.class)
public class MinecraftAppletMixin extends Applet {

	@Shadow private Minecraft minecraft;

	/**
	 * @author kimoVoid
	 * @reason Replace AWT canvas
	 */
	@Overwrite
	public void init() {
		boolean bl = false;
		if (this.getParameter("fullscreen") != null) {
			bl = this.getParameter("fullscreen").equalsIgnoreCase("true");
		}

		this.minecraft = new ReframedMinecraft(getWidth(), getHeight(), bl);

		this.minecraft.f_56220406 = this.getDocumentBase().getHost();
		if (this.getDocumentBase().getPort() > 0) {
			this.minecraft.f_56220406 = this.minecraft.f_56220406 + ":" + this.getDocumentBase().getPort();
		}
		if (this.getParameter("username") != null && this.getParameter("sessionid") != null) {
			this.minecraft.f_69329575 = new C_87604186(this.getParameter("username"), this.getParameter("sessionid"));
			System.out.println("Setting user: " + this.minecraft.f_69329575.f_18340302 + ", " + this.minecraft.f_69329575.f_59704460);
			if (this.getParameter("mppass") != null) {
				this.minecraft.f_69329575.f_97866080 = this.getParameter("mppass");
			}
		} else {
			this.minecraft.f_69329575 = new C_87604186("Player", "");
		}
		if (this.getParameter("server") != null && this.getParameter("port") != null) {
			this.minecraft.m_83493923(this.getParameter("server"), Integer.parseInt(this.getParameter("port")));
		}

		this.minecraft.run();
	}
}