package io.github.kimovoid.moderncontrols.mixinterface;

public interface CustomKeyBinding {

    default int getDefault() {
        throw new UnsupportedOperationException();
    }

    default boolean allowsConflicts() {
        throw new UnsupportedOperationException();
    }
    default void setAllowsConflicts(boolean conflicts) {
        throw new UnsupportedOperationException();
    }
}
