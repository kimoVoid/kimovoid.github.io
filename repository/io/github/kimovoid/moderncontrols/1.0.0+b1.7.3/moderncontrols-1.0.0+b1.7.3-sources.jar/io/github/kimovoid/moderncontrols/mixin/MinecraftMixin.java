package io.github.kimovoid.moderncontrols.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.kimovoid.moderncontrols.ModernControls;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_57778754;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_87542771;
import org.lwjgl.input.Keyboard;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class MinecraftMixin {

    @Shadow public C_85740840 screen;
    @Shadow public C_57778754 player;

    @WrapOperation(
            method = "tick",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/entity/mob/player/PlayerInventory;selectedSlot:I",
                    opcode = Opcodes.PUTFIELD
            )
    )
    private void disableVanillaHotbar(C_87542771 instance, int value, Operation<Void> original) {
    }

    @ModifyConstant(method = "tick", constant = {
            @Constant(intValue = 61),
            @Constant(intValue = 63),
            @Constant(intValue = 66),
            @Constant(intValue = 87)
    })
    private int replaceKeys(int constant) {
        return ModernControls.getKeyCodeByOriginal(constant);
    }

    @ModifyConstant(method = "handleScreenshotKey", constant = @Constant(intValue = 60))
    private int setScreenshotKey(int constant) {
        return ModernControls.getKeyCodeByOriginal(constant);
    }

    @Inject(method = "tick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/entity/mob/player/ClientPlayerEntity;handleKeyEvent(IZ)V",
                    shift = At.Shift.AFTER
            )
    )
    public void handleKeys(CallbackInfo ci) {
        if (this.screen != null || !Keyboard.getEventKeyState()) {
            return;
        }

        int key = Keyboard.getEventKey();

        /* Hotbar slots */
        for(int i = 0; i < 9; ++i) {
            if (key == ModernControls.getKeyCodeByOriginal(2 + i)) {
                this.player.f_29439708.f_13682807 = i;
            }
        }
    }
}
