package io.github.kimovoid.moderncontrols.mixin;

import io.github.kimovoid.moderncontrols.mixinterface.CustomKeyBinding;
import net.minecraft.unmapped.C_23708450;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_23708450.class)
public class KeyBindingMixin implements CustomKeyBinding {

    @Unique private int defaultKeyCode;
    @Unique private boolean conflicts = false;

    @Inject(method = "<init>", at = @At("TAIL"))
    private void setDefaultKeyCode(String name, int keyCode, CallbackInfo ci) {
        this.defaultKeyCode = keyCode;
    }

    @Override
    public int getDefault() {
        return this.defaultKeyCode;
    }

    @Override
    public boolean allowsConflicts() {
        return this.conflicts;
    }

    @Override
    public void setAllowsConflicts(boolean conflicts) {
        this.conflicts = conflicts;
    }
}
