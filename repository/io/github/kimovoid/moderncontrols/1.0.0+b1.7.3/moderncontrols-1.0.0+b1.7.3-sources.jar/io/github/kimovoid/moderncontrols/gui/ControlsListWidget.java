package io.github.kimovoid.moderncontrols.gui;

import io.github.kimovoid.moderncontrols.gui.backport.EntryListWidget;
import io.github.kimovoid.moderncontrols.mixinterface.CustomKeyBinding;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_16154270;
import net.minecraft.unmapped.C_23708450;
import net.minecraft.unmapped.C_85125467;
import net.minecraft.unmapped.C_96603444;
import net.ornithemc.osl.keybinds.api.KeybindRegistry;
import org.apache.commons.lang3.ArrayUtils;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.util.Arrays;
import java.util.Comparator;

public class ControlsListWidget extends EntryListWidget {

    private final ControlsScreen parent;
    private final Minecraft minecraft;
    private final EntryListWidget.Entry[] entries;
    private int maxKeyNameLength = 0;

    public ControlsListWidget(ControlsScreen parent, Minecraft minecraft) {
        super(minecraft, parent.f_05230747, parent.f_07021018, 32, parent.f_07021018 - 32, 20);
        this.parent = parent;
        this.minecraft = minecraft;
        C_23708450[] keyBindings = ArrayUtils.clone(minecraft.f_58088711.f_41636781);
        this.entries = new EntryListWidget.Entry[keyBindings.length + KeybindRegistry.getCategories().size()];
        Arrays.sort(keyBindings, Comparator.comparing(key -> C_16154270.m_56062593().m_77288988(key.getCategory())));

        int i = 0;
        String lastCategory = null;
        for (C_23708450 keyBinding : keyBindings) {
            String category = keyBinding.getCategory();
            if (!category.equals(lastCategory)) {
                lastCategory = category;
                this.entries[i++] = new ControlsListWidget.CategoryEntry(category);
            }

            int l = minecraft.f_21497584.m_09235706(C_16154270.m_56062593().m_77288988(keyBinding.f_54130288));
            if (l > this.maxKeyNameLength) {
                this.maxKeyNameLength = l;
            }

            this.entries[i++] = new ControlsListWidget.KeyBindingEntry(keyBinding);
        }
    }

    @Override
    protected int size() {
        return this.entries.length;
    }

    @Override
    public EntryListWidget.Entry getEntry(int index) {
        return this.entries[index];
    }

    @Override
    protected int getScrollbarPosition() {
        return super.getScrollbarPosition() + 15;
    }

    @Override
    public int getRowWidth() {
        return super.getRowWidth() + 32;
    }

    @Environment(EnvType.CLIENT)
    public class CategoryEntry implements EntryListWidget.Entry {
        private final String name;
        private final int nameWidth;

        public CategoryEntry(String key) {
            this.name = C_16154270.m_56062593().m_77288988(key);
            this.nameWidth = ControlsListWidget.this.minecraft.f_21497584.m_09235706(this.name);
        }

        @Override
        public void render(int index, int x, int y, int width, int height, C_96603444 tesselator, int mouseX, int mouseY, boolean hovered) {
            ControlsListWidget.this.minecraft
                    .f_21497584
                    .m_72964882(
                            this.name,
                            ControlsListWidget.this.minecraft.f_70816363.f_05230747 / 2 - this.nameWidth / 2,
                            y + height - 8 - 1,
                            16777215
                    );
        }

        @Override
        public boolean mouseClicked(int index, int mouseX, int mouseY, int button, int entryMouseX, int entryMouseY) {
            return false;
        }

        @Override
        public void mouseReleased(int index, int mouseX, int mouseY, int button, int entryMouseX, int entryMouseY) {
        }
    }

    @Environment(EnvType.CLIENT)
    public class KeyBindingEntry implements EntryListWidget.Entry {
        private final C_23708450 keyBinding;
        private final String name;
        private final C_85125467 keyBindingButton;
        private final C_85125467 resetButton;

        private KeyBindingEntry(C_23708450 keyBinding) {
            this.keyBinding = keyBinding;
            this.name = C_16154270.m_56062593().m_77288988(keyBinding.f_54130288);
            this.keyBindingButton = new C_85125467(0, 0, 0, 75, 20, C_16154270.m_56062593().m_77288988(keyBinding.f_54130288));
            this.resetButton = new C_85125467(0, 0, 0, 50, 20, C_16154270.m_56062593().m_77288988("controls.reset"));
        }

        @Override
        public void render(int index, int x, int y, int width, int height, C_96603444 tesselator, int mouseX, int mouseY, boolean hovered) {
            boolean selected = ControlsListWidget.this.parent.selectedKeyBinding == this.keyBinding;
            ControlsListWidget.this.minecraft
                    .f_21497584
                    .m_72964882(
                            this.name,
                            x + 90 - ControlsListWidget.this.maxKeyNameLength,
                            y + height / 2 - 8 / 2,
                            16777215
                    );
            this.resetButton.f_99054304 = x + 190;
            this.resetButton.f_24716782 = y;
            this.resetButton.f_89460239 = this.keyBinding.f_57264828 != ((CustomKeyBinding)this.keyBinding).getDefault();
            this.resetButton.m_43811351(ControlsListWidget.this.minecraft, mouseX, mouseY);
            this.keyBindingButton.f_99054304 = x + 105;
            this.keyBindingButton.f_24716782 = y;
            this.keyBindingButton.f_35112386 = this.keyBinding.f_57264828 < 0 ? Mouse.getButtonName(this.keyBinding.f_57264828 + 101) : Keyboard.getKeyName(this.keyBinding.f_57264828);
            boolean conflict = false;
            if (this.keyBinding.f_57264828 != 0) {
                for (C_23708450 keyBinding : ControlsListWidget.this.minecraft.f_58088711.f_41636781) {
                    if (keyBinding != this.keyBinding
                            && keyBinding.f_57264828 == this.keyBinding.f_57264828
                            && !(((CustomKeyBinding)this.keyBinding).allowsConflicts()
                            || ((CustomKeyBinding)keyBinding).allowsConflicts())) {
                        conflict = true;
                        break;
                    }
                }
            }

            if (selected) {
                this.keyBindingButton.f_35112386 = "> §e" + this.keyBindingButton.f_35112386 + "§f <";
            } else if (conflict) {
                this.keyBindingButton.f_35112386 = "§c" + this.keyBindingButton.f_35112386;
            }

            this.keyBindingButton.m_43811351(ControlsListWidget.this.minecraft, mouseX, mouseY);
        }

        @Override
        public boolean mouseClicked(int index, int mouseX, int mouseY, int button, int entryMouseX, int entryMouseY) {
            if (this.keyBindingButton.m_07260289(ControlsListWidget.this.minecraft, mouseX, mouseY)) {
                ControlsListWidget.this.parent.selectedKeyBinding = this.keyBinding;
                return true;
            } else if (this.resetButton.m_07260289(ControlsListWidget.this.minecraft, mouseX, mouseY)) {
                this.keyBinding.f_57264828 = ((CustomKeyBinding)this.keyBinding).getDefault();
                return true;
            } else {
                return false;
            }
        }

        @Override
        public void mouseReleased(int index, int mouseX, int mouseY, int button, int entryMouseX, int entryMouseY) {
            this.keyBindingButton.m_77579459(mouseX, mouseY);
            this.resetButton.m_77579459(mouseX, mouseY);
        }
    }
}
