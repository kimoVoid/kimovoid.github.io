package io.github.kimovoid.moderncontrols;

import io.github.kimovoid.moderncontrols.mixinterface.CustomKeyBinding;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_23708450;
import net.ornithemc.osl.entrypoints.api.client.ClientModInitializer;
import net.ornithemc.osl.keybinds.api.KeybindEvents;
import net.ornithemc.osl.keybinds.api.KeybindRegistry;
import net.ornithemc.osl.keybinds.impl.access.KeyBindingAccess;
import net.ornithemc.osl.lifecycle.api.client.MinecraftClientEvents;
import org.lwjgl.input.Keyboard;

public class ModernControls implements ClientModInitializer {

	@Override
	public void initClient() {
		/* Register keys added by this mod */
		KeybindEvents.REGISTER_KEYBINDS.register(() -> {
			KeybindRegistry.register("key.debugOverlay", Keyboard.KEY_F3, "key.categories.misc");
			KeybindRegistry.register("key.screenshot", Keyboard.KEY_F2, "key.categories.misc");
			KeybindRegistry.register("key.smoothCamera", Keyboard.KEY_F8, "key.categories.misc");
			KeybindRegistry.register("key.fullscreen", Keyboard.KEY_F11, "key.categories.misc");
			KeybindRegistry.register("key.togglePerspective", Keyboard.KEY_F5, "key.categories.misc");

			for (int slot = 1; slot < 10; slot++) {
				KeybindRegistry.register("key.hotbar." + slot, slot + 1, "key.categories.inventory");
			}
		});

		/* Register proper vanilla categories */
		MinecraftClientEvents.READY.register(mc -> {
			registerCategory(mc.f_58088711.f_15607202, "key.categories.movement");
			registerCategory(mc.f_58088711.f_15607202, "key.categories.movement");
			registerCategory(mc.f_58088711.f_20678369, "key.categories.movement");
			registerCategory(mc.f_58088711.f_46759128, "key.categories.movement");
			registerCategory(mc.f_58088711.f_25268871, "key.categories.movement");
			registerCategory(mc.f_58088711.f_94470987, "key.categories.movement");
			registerCategory(mc.f_58088711.f_89071996, "key.categories.movement");
			registerCategory(mc.f_58088711.f_09184409, "key.categories.inventory");
			registerCategory(mc.f_58088711.f_53542110, "key.categories.gameplay");
			registerCategory(mc.f_58088711.f_69386559, "key.categories.misc");
			registerCategory(mc.f_58088711.f_02302636, "key.categories.multiplayer");
		});
	}

    /**
     * @param keyCode The vanilla keyCode.
     * @return A keyCode, including custom keybindings added by this mod or other mods.
     */
	public static int getKeyCodeByOriginal(int keyCode) {
		for (C_23708450 key : Minecraft.f_33079084.f_58088711.f_41636781) {
			CustomKeyBinding custom = ((CustomKeyBinding) key);
			if (custom.getDefault() == keyCode) {
				return key.f_57264828;
			}
		}

		return keyCode; // if there is no keybinding, return the default code.
	}

	/**
	 * @param name The name of the keybind.
	 * @param defaultKeyCode The default key code.
	 * @param allowsConflicts Whether keybind conflicts should be notified.
	 * @return A vanilla <i>KeyBinding</i> object.
	 * <p>
	 * Useful when you register keys through OSL
	 * in case you want your key to allow conflicts
	 * in the Controls screen.
	 */
	public static C_23708450 getCustomKey(String name, int defaultKeyCode, boolean allowsConflicts) {
		C_23708450 key = new C_23708450(name, defaultKeyCode);
		((CustomKeyBinding)key).setAllowsConflicts(allowsConflicts);
		return key;
	}

	/**
	 * @param key A vanilla <i>KeyBinding</i> object.
	 * @param category A category for the keybind.
	 *                 <p>
	 *                 A simple way to register categories via
	 *                 OSL keybinds.
	 */
	public static void registerCategory(C_23708450 key, String category) {
		KeybindRegistry.getCategories().add(category);
		((KeyBindingAccess)key).osl$keybinds$setCategory(category);
	}
}
