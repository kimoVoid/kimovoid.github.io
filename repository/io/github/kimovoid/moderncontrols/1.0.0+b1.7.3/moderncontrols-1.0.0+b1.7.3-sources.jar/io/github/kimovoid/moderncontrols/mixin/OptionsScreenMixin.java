package io.github.kimovoid.moderncontrols.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.kimovoid.moderncontrols.gui.ControlsScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_76792751;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_88528069;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(C_88528069.class)
public abstract class OptionsScreenMixin extends C_85740840 {

    @Shadow private C_76792751 options;

    @WrapOperation(
            method = "buttonClicked",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/Minecraft;openScreen(Lnet/minecraft/client/gui/screen/Screen;)V",
                    ordinal = 1
            )
    )
    private void replaceControlsScreen(Minecraft instance, C_85740840 screen, Operation<Void> original) {
        original.call(instance, new ControlsScreen(this, this.options));
    }
}
