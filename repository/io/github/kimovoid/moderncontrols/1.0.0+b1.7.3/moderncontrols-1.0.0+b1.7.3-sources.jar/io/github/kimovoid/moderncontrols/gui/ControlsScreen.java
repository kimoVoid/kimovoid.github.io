package io.github.kimovoid.moderncontrols.gui;

import io.github.kimovoid.moderncontrols.mixinterface.CustomKeyBinding;
import net.minecraft.unmapped.C_16154270;
import net.minecraft.unmapped.C_23708450;
import net.minecraft.unmapped.C_76792751;
import net.minecraft.unmapped.C_85125467;
import net.minecraft.unmapped.C_85740840;

public class ControlsScreen extends C_85740840 {

    private final C_85740840 parent;
    protected String title;
    private final C_76792751 options;
    public C_23708450 selectedKeyBinding = null;
    public long time;
    private ControlsListWidget controlsList;
    private C_85125467 resetAllButton;

    public ControlsScreen(C_85740840 parent, C_76792751 options) {
        this.parent = parent;
        this.options = options;
    }

    @Override
    public void m_41805697() {
        this.controlsList = new ControlsListWidget(this, this.f_78495264);
        this.f_78519977.add(new C_85125467(200, this.f_05230747 / 2 - 155, this.f_07021018 - 29, 150, 20, C_16154270.m_56062593().m_77288988("gui.done")));
        this.f_78519977.add(this.resetAllButton = new C_85125467(201, this.f_05230747 / 2 - 155 + 160, this.f_07021018 - 29, 150, 20, C_16154270.m_56062593().m_77288988("controls.resetAll")));
        this.title = C_16154270.m_56062593().m_77288988("controls.title");
    }

    @Override
    protected void m_30778170(C_85125467 button) {
        if (button.f_92999450 == 200) {
            this.options.m_18664673();
            this.f_78495264.m_52715402(this.parent);
        } else if (button.f_92999450 == 201) {
            for (C_23708450 keyBinding : this.f_78495264.f_58088711.f_41636781) {
                keyBinding.f_57264828 = ((CustomKeyBinding)keyBinding).getDefault();
            }
        }
    }

    @Override
    protected void m_23755539(int mouseX, int mouseY, int button) {
        /* TODO implement mouse keybinds
        if (this.selectedKeyBinding != null) {
            this.selectedKeyBinding.keyCode = -100 + button;
            this.selectedKeyBinding = null;
        }
         */

        if (button != 0 || !this.controlsList.mouseClicked(mouseX, mouseY, button)) {
            super.m_23755539(mouseX, mouseY, button);
        }
    }

    @Override
    protected void m_47537840(int mouseX, int mouseY, int button) {
        if (button != 0 || !this.controlsList.mouseReleased(mouseX, mouseY, button)) {
            super.m_47537840(mouseX, mouseY, button);
        }
    }

    @Override
    protected void m_29116903(char chr, int key) {
        if (this.selectedKeyBinding != null) {
            if (key == 1) {
                this.selectedKeyBinding.f_57264828 = 0;
            } else {
                this.selectedKeyBinding.f_57264828 = key;
            }

            this.selectedKeyBinding = null;
            this.time = System.currentTimeMillis();
        } else {
            super.m_29116903(chr, key);
        }
    }

    @Override
    public void m_93956703(int mouseX, int mouseY, float tickDelta) {
        this.m_34695786();
        this.controlsList.render(mouseX, mouseY, tickDelta);
        this.m_50067982(this.f_11884601, this.title, this.f_05230747 / 2, 16, 16777215);
        int i = 1;

        for (C_23708450 keyBinding : this.options.f_41636781) {
            if (keyBinding.f_57264828 != ((CustomKeyBinding)keyBinding).getDefault()) {
                i = 0;
                break;
            }
        }

        this.resetAllButton.f_89460239 = i == 0;
        super.m_93956703(mouseX, mouseY, tickDelta);
    }
}
