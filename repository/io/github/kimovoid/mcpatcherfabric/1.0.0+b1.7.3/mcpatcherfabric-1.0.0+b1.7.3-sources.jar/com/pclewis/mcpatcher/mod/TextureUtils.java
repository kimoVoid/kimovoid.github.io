package com.pclewis.mcpatcher.mod;

import io.github.kimovoid.mcpatcherfabric.mixin.accessors.FoliageColorsColorAccessor;
import io.github.kimovoid.mcpatcherfabric.mixin.accessors.GrassColorsColorAccessor;
import io.github.kimovoid.mcpatcherfabric.mixin.accessors.WaterColorsColorAccessor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.texture.*;
import net.minecraft.unmapped.C_11625250;
import net.minecraft.unmapped.C_11661111;
import net.minecraft.unmapped.C_19106855;
import net.minecraft.unmapped.C_23014920;
import net.minecraft.unmapped.C_43134216;
import net.minecraft.unmapped.C_54686545;
import net.minecraft.unmapped.C_59922537;
import net.minecraft.unmapped.C_74530968;
import net.minecraft.unmapped.C_76792751;
import net.minecraft.unmapped.C_77716298;
import net.minecraft.unmapped.C_82478746;
import net.minecraft.unmapped.C_82920792;
import net.minecraft.unmapped.C_84698437;
import net.minecraft.unmapped.C_85717331;
import net.ornithemc.osl.resource.loader.api.resource.manager.ResourceManager;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class TextureUtils {

	public static Minecraft minecraft;

	private static final boolean animatedFire;
	private static final boolean animatedLava;
	private static final boolean animatedWater;
	private static final boolean animatedPortal;
	private static final boolean customFire;
	private static final boolean customLava;
	private static final boolean customWater;
	private static final boolean customPortal;

	public static final int LAVA_STILL_TEXTURE_INDEX = 14 * 16 + 13;  // Block.lavaStill.blockIndexInTexture
	public static final int LAVA_FLOWING_TEXTURE_INDEX = LAVA_STILL_TEXTURE_INDEX + 1; // Block.lavaMoving.blockIndexInTexture
	public static final int WATER_STILL_TEXTURE_INDEX = 12 * 16 + 13; // Block.waterStill.blockIndexInTexture
	public static final int WATER_FLOWING_TEXTURE_INDEX = WATER_STILL_TEXTURE_INDEX + 1; // Block.waterMoving.blockIndexInTexture
	public static final int FIRE_E_W_TEXTURE_INDEX = 16 + 15; // Block.fire.blockIndexInTexture;
	public static final int FIRE_N_S_TEXTURE_INDEX = FIRE_E_W_TEXTURE_INDEX + 16;
	public static final int PORTAL_TEXTURE_INDEX = 14; // Block.portal.blockIndexInTexture

	private static final HashMap<String, Integer> expectedColumns = new HashMap<String, Integer>();

	static {
		animatedFire = true;
		animatedLava = true;
		animatedWater = true;
		animatedPortal = true;
		customFire = true;
		customLava = true;
		customWater = true;
		customPortal = true;

		expectedColumns.put("/terrain.png", 16);
		expectedColumns.put("/gui/items.png", 16);
		expectedColumns.put("/misc/dial.png", 1);
		expectedColumns.put("/custom_lava_still.png", 1);
		expectedColumns.put("/custom_lava_flowing.png", 1);
		expectedColumns.put("/custom_water_still.png", 1);
		expectedColumns.put("/custom_water_flowing.png", 1);
		expectedColumns.put("/custom_fire_n_s.png", 1);
		expectedColumns.put("/custom_fire_e_w.png", 1);
		expectedColumns.put("/custom_portal.png", 1);
	}

	public static boolean setTileSize() {
		int size = getTileSize();
		if (size == TileSize.int_size) {
			return false;
		} else {
			TileSize.setTileSize(size);
			return true;
		}
	}

	public static void setFontRenderer(Minecraft minecraft) {
		reInitializeTextRenderer(minecraft.f_58088711, "/font/default.png", minecraft.f_45465196);
	}

	public static void registerTextureFX(java.util.List<C_54686545> textureList, C_54686545 textureFX) {
		C_54686545 fx = refreshTextureFX(textureFX);
		if (fx != null) {
			textureList.add(fx);
			fx.m_47598203();
		}
	}

	private static C_54686545 refreshTextureFX(C_54686545 textureFX) {
		if (textureFX instanceof C_85717331 ||
			textureFX instanceof C_43134216 ||
			textureFX instanceof C_82478746 ||
			textureFX instanceof C_11661111 ||
			textureFX instanceof C_19106855 ||
			textureFX instanceof C_77716298 ||
			textureFX instanceof C_84698437 ||
			textureFX instanceof C_59922537 ||
			textureFX instanceof CustomAnimation) {
			return null;
		}
		Class<? extends C_54686545> textureFXClass = textureFX.getClass();
		for (int i = 0; i < 3; i++) {
			Constructor<? extends C_54686545> constructor;
			try {
				switch (i) {
					case 0:
						constructor = textureFXClass.getConstructor(Minecraft.class, Integer.TYPE);
						return constructor.newInstance(minecraft, TileSize.int_size);

					case 1:
						constructor = textureFXClass.getConstructor(Minecraft.class);
						return constructor.newInstance(minecraft);

					case 2:
						constructor = textureFXClass.getConstructor();
						return constructor.newInstance();

					default:
						break;
				}
			} catch (NoSuchMethodException | IllegalAccessException ignored) {
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (textureFX.f_01015158.length != TileSize.int_numBytes) {
			textureFX.f_01015158 = new byte[TileSize.int_numBytes];
		}
		return textureFX;
	}

	public static void refreshTextureFX(java.util.List<C_54686545> textureList) {
		ArrayList<C_54686545> savedTextureFX = new ArrayList<>();
		for (C_54686545 t : textureList) {
			C_54686545 fx = refreshTextureFX(t);
			if (fx != null) {
				savedTextureFX.add(fx);
			}
		}
		textureList.clear();

		textureList.add(new C_85717331(minecraft));
		textureList.add(new C_43134216(minecraft));

		C_74530968 selectedTexturePack = getSelectedTexturePack();
		boolean isDefault = (selectedTexturePack == null || selectedTexturePack instanceof C_11625250);

		if (!isDefault && customLava && (hasResource("/custom_lava_still.png") || hasResource("/custom_lava_flowing.png"))) {
			textureList.add(new CustomAnimation(LAVA_STILL_TEXTURE_INDEX, 0, 1, "lava_still", -1, -1));
			textureList.add(new CustomAnimation(LAVA_FLOWING_TEXTURE_INDEX, 0, 2, "lava_flowing", 3, 6));
		} else if (animatedLava) {
			textureList.add(new C_82478746());
			textureList.add(new C_11661111());
		}

		if (!isDefault && customWater && (hasResource("/custom_water_still.png") || hasResource("/custom_water_flowing.png"))) {
			textureList.add(new CustomAnimation(WATER_STILL_TEXTURE_INDEX, 0, 1, "water_still", -1, -1));
			textureList.add(new CustomAnimation(WATER_FLOWING_TEXTURE_INDEX, 0, 2, "water_flowing", 0, 0));
		} else if (animatedWater) {
			textureList.add(new C_19106855());
			textureList.add(new C_77716298());
		}

		if (!isDefault && customFire && hasResource("/custom_fire_e_w.png") && hasResource("/custom_fire_n_s.png")) {
			textureList.add(new CustomAnimation(FIRE_N_S_TEXTURE_INDEX, 0, 1, "fire_n_s", 2, 4));
			textureList.add(new CustomAnimation(FIRE_E_W_TEXTURE_INDEX, 0, 1, "fire_e_w", 2, 4));
		} else if (animatedFire) {
			textureList.add(new C_84698437(0));
			textureList.add(new C_84698437(1));
		}

		if (!isDefault && customPortal && hasResource("/custom_portal.png")) {
			textureList.add(new CustomAnimation(PORTAL_TEXTURE_INDEX, 0, 1, "portal", -1, -1));
		} else if (animatedPortal) {
			textureList.add(new C_59922537());
		}

        textureList.addAll(savedTextureFX);

		for (C_54686545 t : textureList) {
			t.m_47598203();
		}

		if (WaterColorsColorAccessor.getColors() != FoliageColorsColorAccessor.getColors()) {
			refreshColorizer(WaterColorsColorAccessor.getColors(), "/misc/watercolor.png");
		}
		refreshColorizer(GrassColorsColorAccessor.getColors(), "/misc/grasscolor.png");
		refreshColorizer(FoliageColorsColorAccessor.getColors(), "/misc/foliagecolor.png");

		System.gc();
	}

	public static C_74530968 getSelectedTexturePack() {
		return minecraft == null ? null :
			minecraft.f_20964140 == null ? null :
				minecraft.f_20964140.f_25140974;
	}

	public static InputStream getResourceAsStream(String resource) {
		InputStream is = null;
		try {
			is = ResourceManager.client().getResource(resource);
		} catch (IOException ignored) {
		}
		return is;
	}

	public static BufferedImage getResourceAsBufferedImage(String resource) throws IOException {
		BufferedImage image = null;

        InputStream is = getResourceAsStream(resource);
        if (is != null) {
            try {
                image = ImageIO.read(is);
            } finally {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        if (image == null) {
			throw new IOException(resource + " image is null");
		}

		Integer i = expectedColumns.get(resource);
		if (i != null && image.getWidth() != i * TileSize.int_size) {
			image = resizeImage(image, i * TileSize.int_size);
		}

		return image;
	}

	public static int getTileSize(C_74530968 texturePack) {
		int size = 0;
		for (Map.Entry<String, Integer> entry : expectedColumns.entrySet()) {
            try (InputStream is = getResourceAsStream(entry.getKey())) {
                if (is != null) {
                    BufferedImage bi = ImageIO.read(is);
                    int newSize = bi.getWidth() / entry.getValue();
                    size = Math.max(size, newSize);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
		}
		return size > 0 ? size : 16;
	}

	public static int getTileSize() {
		return getTileSize(getSelectedTexturePack());
	}

	public static boolean hasResource(String resource) {
		InputStream is = getResourceAsStream(resource);
		return is != null;
	}

	private static BufferedImage resizeImage(BufferedImage image, int width) {
		int height = image.getHeight() * width / image.getWidth();
		BufferedImage newImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		Graphics2D graphics2D = newImage.createGraphics();
		graphics2D.drawImage(image, 0, 0, width, height, null);
		return newImage;
	}

	private static void refreshColorizer(int[] colorBuffer, String resource) {
		try {
			BufferedImage bi = getResourceAsBufferedImage(resource);
			if (bi != null) {
				bi.getRGB(0, 0, 256, 256, colorBuffer, 0, 256);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void reInitializeTextRenderer(C_76792751 options, String fontPath, C_82920792 textureManager) {
		C_23014920 newRenderer = new C_23014920(options, fontPath, textureManager);
		int oldTex = TextureUtils.minecraft.f_21497584.f_70082797;
		for (Field declaredField : C_23014920.class.getDeclaredFields()) {
			declaredField.setAccessible(true);
			try {
				declaredField.set(TextureUtils.minecraft.f_21497584, declaredField.get(newRenderer));
			} catch (IllegalAccessException e) {
				throw new RuntimeException(e);
			}
		}
		TextureUtils.minecraft.f_45465196.m_20829820(oldTex);
	}

	public static void setMinecraft(Minecraft minecraft) {
		TextureUtils.minecraft = minecraft;
	}

	public static Minecraft getMinecraft() {
		return minecraft;
	}
}
