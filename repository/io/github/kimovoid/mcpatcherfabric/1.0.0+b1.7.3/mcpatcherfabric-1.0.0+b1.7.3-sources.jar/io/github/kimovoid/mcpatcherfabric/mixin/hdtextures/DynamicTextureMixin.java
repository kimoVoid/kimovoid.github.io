package io.github.kimovoid.mcpatcherfabric.mixin.hdtextures;

import com.pclewis.mcpatcher.mod.TileSize;
import net.minecraft.unmapped.C_54686545;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(C_54686545.class)
public class DynamicTextureMixin {
	@SuppressWarnings("unused")
	@Shadow
	public byte[] pixels = new byte[TileSize.int_numBytes];
}
