package io.github.kimovoid.mcpatcherfabric.mixin.hdtextures;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.pclewis.mcpatcher.mod.TileSize;
import net.minecraft.unmapped.C_54686545;
import net.minecraft.unmapped.C_59922537;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_59922537.class)
public abstract class NetherPortalSpriteMixin extends C_54686545 {

	@Shadow private byte[][] frames;

	public NetherPortalSpriteMixin(int sprite) {
		super(sprite);
	}

	@Inject(method = "<init>()V", at = @At(value = "INVOKE", target = "Ljava/util/Random;<init>(J)V"))
	private void fixByteArraySize(CallbackInfo ci) {
		this.f_01015158 = new byte[TileSize.int_size * TileSize.int_size * 4];
		this.frames = new byte[32][TileSize.int_size * TileSize.int_size * 4];
	}

	@ModifyExpressionValue(method = "<init>()V", at = @At(value = "CONSTANT", args = "intValue=16"))
	private int fixTextureSizeInt(int original) {
		return TileSize.int_size;
	}

	@ModifyExpressionValue(method = "<init>()V", at = @At(value = "CONSTANT", args = "floatValue=16.0f"))
	private float fixTextureSizeFloat(float original) {
		return TileSize.float_size;
	}

	@ModifyExpressionValue(method = "<init>()V", at = @At(value = "CONSTANT", args = "intValue=8"))
	private int fixInitLoop(int original) {
		return TileSize.int_size / 2;
	}

	@ModifyExpressionValue(method = "tick()V", at = @At(value = "CONSTANT", args = "intValue=256"))
	private int fixUpdateLoop(int original) {
		return TileSize.int_numPixels;
	}
}