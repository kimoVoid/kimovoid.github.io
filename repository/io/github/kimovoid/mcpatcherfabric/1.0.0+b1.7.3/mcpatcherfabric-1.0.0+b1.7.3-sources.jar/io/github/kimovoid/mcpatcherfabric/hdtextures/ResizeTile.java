package io.github.kimovoid.mcpatcherfabric.hdtextures;


import net.minecraft.client.Minecraft;

public interface ResizeTile {
	void mcpatcherfabric$setTileSize(Minecraft minecraft);
}
