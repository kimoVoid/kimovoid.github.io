package io.github.kimovoid.mcpatcherfabric.mixin.accessors;

import net.minecraft.unmapped.C_06587063;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(C_06587063.class)
public interface WaterColorsColorAccessor {
	@Accessor("colors")
    static int[] getColors() {
		throw new AssertionError();
	}
}
