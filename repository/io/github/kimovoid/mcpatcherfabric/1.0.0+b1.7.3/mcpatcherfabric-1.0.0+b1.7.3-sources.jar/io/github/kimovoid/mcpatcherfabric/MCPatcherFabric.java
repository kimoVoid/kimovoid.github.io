package io.github.kimovoid.mcpatcherfabric;

import net.ornithemc.osl.entrypoints.api.client.ClientModInitializer;
import net.ornithemc.osl.resource.loader.api.client.ClientResourceLoaderEvents;

public class MCPatcherFabric implements ClientModInitializer {

    public static boolean selectingPack = false;

    @Override
    public void initClient() {
        ClientResourceLoaderEvents.INIT_RESOURCE_MANAGER.register((manager) -> {
            manager.addReloader(new MCPatcherReloadListener());
        });
    }
}
