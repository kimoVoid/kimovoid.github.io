package io.github.kimovoid.mcpatcherfabric.mixin.hdtextures;

import io.github.kimovoid.mcpatcherfabric.MCPatcherFabric;
import net.minecraft.unmapped.C_18996072;
import net.minecraft.unmapped.C_74530968;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_18996072.class)
public class TexturePacksMixin {

	@Inject(method = "select(Lnet/minecraft/client/resource/pack/TexturePack;)Z", at = @At(value = "HEAD"))
	private void setTextureSize(C_74530968 pack, CallbackInfoReturnable<Boolean> cir) {
		MCPatcherFabric.selectingPack = true;
	}
}
