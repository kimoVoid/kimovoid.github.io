package io.github.kimovoid.mcpatcherfabric.mixin.hdtextures;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import com.pclewis.mcpatcher.mod.TextureUtils;
import com.pclewis.mcpatcher.mod.TileSize;
import io.github.kimovoid.mcpatcherfabric.hdtextures.ResizeTile;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_02041937;
import net.minecraft.unmapped.C_54686545;
import net.minecraft.unmapped.C_74530968;
import net.minecraft.unmapped.C_82920792;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.List;

@Mixin(C_82920792.class)
public abstract class TextureManagerMixin implements ResizeTile {
	
	@Shadow private ByteBuffer imageBuffer;
	@Shadow public abstract void reload();
	@Shadow private List<C_54686545> dynamicTextures;

	@Override
	public void mcpatcherfabric$setTileSize(Minecraft minecraft) {
		this.imageBuffer = C_02041937.m_00433401(TileSize.int_glBufferSize);
		this.reload();
		TextureUtils.refreshTextureFX(this.dynamicTextures);
	}

	@Inject(method = "<init>(Lnet/minecraft/client/resource/pack/TexturePacks;Lnet/minecraft/client/options/GameOptions;)V", at = @At(value = "TAIL"))
	private void fieldFix(CallbackInfo info) {
		imageBuffer = C_02041937.m_00433401(TileSize.int_glBufferSize);
	}

	@WrapOperation(method = "getColors(Ljava/lang/String;)[I", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/resource/pack/TexturePack;getResource(Ljava/lang/String;)Ljava/io/InputStream;"))
	private InputStream mcpatcherGetResourceStringColor(C_74530968 instance, String path, Operation<InputStream> original, @Share("resourcePath") LocalRef<String> resourcePath) {
		resourcePath.set(path);
		return new ByteArrayInputStream(new byte[0]);
	}

	@WrapOperation(method = "getColors(Ljava/lang/String;)[I", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/texture/TextureManager;readImage(Ljava/io/InputStream;)Ljava/awt/image/BufferedImage;"))
	private BufferedImage mcpatcherFixImageReadColor(C_82920792 instance, InputStream is, Operation<BufferedImage> original, @Share("resourcePath") LocalRef<String> resourcePath) throws IOException {
		return TextureUtils.getResourceAsBufferedImage(resourcePath.get());
	}

	@WrapOperation(method = "load(Ljava/lang/String;)I", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/resource/pack/TexturePack;getResource(Ljava/lang/String;)Ljava/io/InputStream;"))
	private InputStream mcpatcherGetResourceStringLoad(C_74530968 instance, String path, Operation<InputStream> original, @Share("resourcePath") LocalRef<String> resourcePath) {
		resourcePath.set(path);
		return new ByteArrayInputStream(new byte[0]);
	}

	@WrapOperation(method = "load(Ljava/lang/String;)I", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/texture/TextureManager;readImage(Ljava/io/InputStream;)Ljava/awt/image/BufferedImage;"))
	private BufferedImage mcpatcherFixImageReadLoad(C_82920792 instance, InputStream is, Operation<BufferedImage> original, @Share("resourcePath") LocalRef<String> resourcePath) throws IOException {
		return TextureUtils.getResourceAsBufferedImage(resourcePath.get());
	}

	@ModifyArg(method = "load(Ljava/lang/String;)I", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/texture/TextureManager;load(Ljava/awt/image/BufferedImage;I)V"), slice = @Slice(from = @At(value = "FIELD", target = "Lnet/minecraft/client/render/texture/TextureManager;image:Ljava/awt/image/BufferedImage;", ordinal = 0), to = @At(value = "FIELD", target = "Lnet/minecraft/client/render/texture/TextureManager;image:Ljava/awt/image/BufferedImage;", ordinal = 1)), index = 0)
	private BufferedImage mcpatcherFixImageReadGeneral(BufferedImage image, @Share("resourcePath") LocalRef<String> resourcePath) throws IOException {
		return TextureUtils.getResourceAsBufferedImage(resourcePath.get());
	}

	@WrapOperation(method = "reload()V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/resource/pack/TexturePack;getResource(Ljava/lang/String;)Ljava/io/InputStream;"))
	private InputStream mcpatcherGetResourceStringReload(C_74530968 instance, String path, Operation<InputStream> original, @Share("resourcePath") LocalRef<String> resourcePath) {
		resourcePath.set(path);
		return new ByteArrayInputStream(new byte[0]);
	}

	@WrapOperation(method = "reload()V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/texture/TextureManager;readImage(Ljava/io/InputStream;)Ljava/awt/image/BufferedImage;"))
	private BufferedImage mcpatcherFixImageReadReload(C_82920792 instance, InputStream is, Operation<BufferedImage> original, @Share("resourcePath") LocalRef<String> resourcePath) throws IOException {
		return TextureUtils.getResourceAsBufferedImage(resourcePath.get());
	}

	@Inject(method = {"load(Ljava/awt/image/BufferedImage;I)V", "bind([IIII)V"}, at = @At(value = "INVOKE", target = "java/nio/ByteBuffer.clear ()Ljava/nio/Buffer;", shift = At.Shift.AFTER, ordinal = 0))
	private void resizeTextureBufferBind(CallbackInfo ci, @Local(ordinal = 0) byte[] bs) {
		if (this.imageBuffer.capacity() != bs.length) this.imageBuffer = C_02041937.m_00433401(bs.length);
	}

	@Inject(method = "tick()V", at = @At(value = "INVOKE", target = "java/nio/ByteBuffer.clear ()Ljava/nio/Buffer;", shift = At.Shift.AFTER, ordinal = 0))
	private void resizeTextureBufferTick(CallbackInfo ci, @Local(ordinal = 0) C_54686545 dynamicTexture2) {
		if (this.imageBuffer.capacity() != dynamicTexture2.f_01015158.length)
			this.imageBuffer = C_02041937.m_00433401(dynamicTexture2.f_01015158.length);
	}

	@WrapOperation(method = "addDynamicTexture", at = @At(value = "INVOKE", target = "Ljava/util/List;add(Ljava/lang/Object;)Z"))
	private boolean mcpatcherRegisterSprite(List<C_54686545> instance, Object sprite, Operation<Boolean> original) {
		TextureUtils.registerTextureFX(instance, (C_54686545) sprite);
		return true;
	}

	@WrapOperation(method = "addDynamicTexture", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/texture/DynamicTexture;tick()V"))
	private void mcpatcherRemoveSpriteTick(C_54686545 instance, Operation<Void> original) {
	}

	@ModifyExpressionValue(method = "tick()V", at = {@At(value = "CONSTANT", args = "intValue=16", ordinal = 1), @At(value = "CONSTANT", args = "intValue=16", ordinal = 2), @At(value = "CONSTANT", args = "intValue=16", ordinal = 4), @At(value = "CONSTANT", args = "intValue=16", ordinal = 5), @At(value = "CONSTANT", args = "intValue=16", ordinal = 6), @At(value = "CONSTANT", args = "intValue=16", ordinal = 7), @At(value = "CONSTANT", args = "intValue=16", ordinal = 12), @At(value = "CONSTANT", args = "intValue=16", ordinal = 13)})
	private int useProperTileSize(int original) {
		return TileSize.int_size;
	}
}
