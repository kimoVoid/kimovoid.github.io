package io.github.kimovoid.mcpatcherfabric.mixin.hdtextures;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.pclewis.mcpatcher.mod.TileSize;
import net.minecraft.unmapped.C_11661111;
import net.minecraft.unmapped.C_19106855;
import net.minecraft.unmapped.C_77716298;
import net.minecraft.unmapped.C_82478746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value = {C_82478746.class, C_11661111.class, C_19106855.class, C_77716298.class})
public class LiquidSpriteMixin {
	@ModifyExpressionValue(method = "tick()V", at = @At(value = "CONSTANT", args = "intValue=16"))
	private int tileSize(int original){
		return TileSize.int_size;
	}
	@ModifyExpressionValue(method = "tick()V", at = @At(value = "CONSTANT", args = "intValue=15"))
	private int tileSizeMinusOne(int original){
		return TileSize.int_sizeMinus1;
	}
	@ModifyExpressionValue(method = "*", at = @At(value = "CONSTANT", args = "intValue=256"))
	private int fixImageAndLoopSize(int original){
		return TileSize.int_numPixels;
	}
}
