package io.github.kimovoid.mcpatcherfabric.mixin.hdtextures;

import com.pclewis.mcpatcher.mod.TextureUtils;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import net.minecraft.unmapped.C_23014920;
import net.minecraft.unmapped.C_76792751;

@Mixin(C_23014920.class)
public class TextRendererMixin {

	@Redirect(method = "<init>(Lnet/minecraft/client/options/GameOptions;Ljava/lang/String;Lnet/minecraft/client/render/texture/TextureManager;)V",
		at = @At(value = "INVOKE", target = "Ljavax/imageio/ImageIO;read(Ljava/io/InputStream;)Ljava/awt/image/BufferedImage;"))
	private BufferedImage useCachedFontImage(InputStream input, C_76792751 options, String fontPath) throws IOException {
		return TextureUtils.getResourceAsBufferedImage(fontPath);
	}
}
