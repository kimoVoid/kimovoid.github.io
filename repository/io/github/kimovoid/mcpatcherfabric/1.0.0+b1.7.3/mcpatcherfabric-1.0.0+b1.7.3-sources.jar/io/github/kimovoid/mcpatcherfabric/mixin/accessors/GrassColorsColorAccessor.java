package io.github.kimovoid.mcpatcherfabric.mixin.accessors;

import net.minecraft.unmapped.C_19632932;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(C_19632932.class)
public interface GrassColorsColorAccessor {
	@Accessor("colors")
    static int[] getColors() {
		throw new AssertionError();
	}
}
