package io.github.kimovoid.mcpatcherfabric.mixin.hdtextures;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.pclewis.mcpatcher.mod.TileSize;
import net.minecraft.unmapped.C_11661111;
import net.minecraft.unmapped.C_77716298;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value = {C_11661111.class, C_77716298.class})
public class LiquidSideSpriteMixin {
	@ModifyExpressionValue(method = "tick()V", at = @At(value = "CONSTANT", args = "intValue=255", ordinal = 0))
	private int pixelsMinusOne(int original) {
		return TileSize.int_numPixelsMinus1;
	}
}
