package io.github.kimovoid.mcpatcherfabric.mixin.hdtextures;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.pclewis.mcpatcher.mod.TextureUtils;
import io.github.kimovoid.mcpatcherfabric.hdtextures.ResizeTile;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_54686545;
import net.minecraft.unmapped.C_82920792;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class MinecraftMixin {
	@Shadow
	public C_82920792 textureManager;

	@Inject(method = "init()V", at = @At(value = "FIELD", target = "Lnet/minecraft/client/Minecraft;textureManager:Lnet/minecraft/client/render/texture/TextureManager;", ordinal = 0))
	public void beforeTextureManager(CallbackInfo info) {
		TextureUtils.setMinecraft((Minecraft) (Object) this);
	}

	@Inject(method = "init()V", at = @At(value = "FIELD", target = "Lnet/minecraft/client/Minecraft;textRenderer:Lnet/minecraft/client/render/TextRenderer;", ordinal = 0))
	private void afterTextureManager(CallbackInfo ci) {
		TextureUtils.setTileSize();
		((ResizeTile) this.textureManager).mcpatcherfabric$setTileSize((Minecraft) (Object) this);
	}

	@WrapOperation(method = "init()V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/texture/TextureManager;addDynamicTexture(Lnet/minecraft/client/render/texture/DynamicTexture;)V"))
	private void cancelAddSprite(C_82920792 instance, C_54686545 texture, Operation<Void> original) {
	}
}
