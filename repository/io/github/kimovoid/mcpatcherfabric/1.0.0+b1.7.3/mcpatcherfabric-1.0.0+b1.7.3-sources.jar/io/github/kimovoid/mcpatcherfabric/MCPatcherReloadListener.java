package io.github.kimovoid.mcpatcherfabric;

import com.pclewis.mcpatcher.mod.TextureUtils;
import io.github.kimovoid.mcpatcherfabric.hdtextures.ResizeTile;
import net.minecraft.client.Minecraft;
import net.ornithemc.osl.resource.loader.api.resource.manager.ResourceManager;
import net.ornithemc.osl.resource.loader.api.resource.reload.ResourceReloadListener;

public class MCPatcherReloadListener implements ResourceReloadListener {

    @Override
    public void resourcesReloaded(ResourceManager manager) {
        if (!MCPatcherFabric.selectingPack) {
            return;
        }

        MCPatcherFabric.selectingPack = false;

        Minecraft mc = TextureUtils.minecraft;
        TextureUtils.setTileSize();
        ((ResizeTile) mc.f_45465196).mcpatcherfabric$setTileSize(mc);
        TextureUtils.setFontRenderer(mc);
    }
}
