package io.github.kimovoid.mcpatcherfabric.mixin.accessors;

import net.minecraft.unmapped.C_82336779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(C_82336779.class)
public interface FoliageColorsColorAccessor {
	@Accessor("colors")
    static int[] getColors() {
		throw new AssertionError();
	}
}
