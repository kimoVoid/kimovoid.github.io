package io.github.kimovoid.silk.gui;

import io.github.kimovoid.silk.gui.entries.*;
import io.github.kimovoid.silk.gui.widgets.*;
import io.github.kimovoid.silk.gui.entries.*;
import io.github.kimovoid.silk.gui.widgets.*;
import net.ornithemc.osl.config.api.config.option.*;
import io.github.kimovoid.silk.option.StringCycleOption;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_16154270;
import io.github.kimovoid.silk.gui.widgets.backport.EntryListWidget;

import java.util.ArrayList;
import java.util.List;

public class ConfigEntryListWidget extends EntryListWidget {

    private final List<OptionEntry> entries = new ArrayList<>();
    private int nextId;

    public ConfigEntryListWidget(ConfigScreen parent, Minecraft minecraft, int width, int height, int yStart, int yEnd, int entryHeight, Option... options) {
        super(minecraft, width, height, yStart, yEnd, entryHeight);
        this.centerAlongY = false;
        this.initEntries(minecraft, parent, options);
    }

    public static OptionWidget createWidget(int id, int x, int y, Option option) {
        if (option instanceof BooleanOption) {
            return new BooleanButtonWidget(id, x, y, (BooleanOption) option);
        }
        if (option instanceof StringOption) {
            return new StringFieldWidget(x, y, (StringOption) option);
        }
        if (option instanceof IntegerOption) {
            return new IntegerFieldWidget(x, y, (IntegerOption) option);
        }
        if (option instanceof FloatOption) {
            return new FloatFieldWidget(x, y, (FloatOption) option);
        }
        if (option instanceof DoubleOption) {
            return new DoubleFieldWidget(x, y, (DoubleOption) option);
        }
        if (option instanceof StringCycleOption) {
            return new StringCycleButtonWidget(id, x, y, (StringCycleOption) option);
        }
        return null;
    }

    @Override
    public int getRowWidth() {
        return 300;
    }

    @Override
    protected int getScrollbarPosition() {
        return this.width - 6;
    }

    @Override
    public EntryListWidget.Entry getEntry(int i) {
        return this.entries.get(i);
    }

    @Override
    protected int size() {
        return this.entries.size();
    }

    @Override
    public boolean mouseClicked(int mouseX, int mouseY, int button) {
        for (OptionEntry entry : this.entries) {
            if (entry instanceof OptionFieldEntry)
                ((OptionFieldEntry) entry).unfocus();
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    public void initEntries(Minecraft mc, ConfigScreen parent, Option... options) {
        for (Option opt : options) {
            if (opt instanceof BooleanOption) {
                this.entries.add(new BooleanEntry(mc, nextId++, parent, (BooleanOption) opt));
            }
            if (opt instanceof StringOption || opt instanceof IntegerOption || opt instanceof FloatOption) {
                this.entries.add(new FieldEntry(mc, nextId++, parent, opt));
            }
            if (opt instanceof StringCycleOption) {
                this.entries.add(new StringCycleEntry(mc, nextId++, parent, (StringCycleOption) opt));
            }
        }
    }

    public void search(ConfigScreen parent, String query) {
        List<Option> opts = new ArrayList<>();
        for (Option opt : parent.getConfig().getGroup(parent.getCategory()).getOptions()) {
            String name = C_16154270.m_56062593().m_77288988(parent.getNamespace() + ".config." + opt.getName());
            if (name.toLowerCase().contains(query.toLowerCase())) {
                opts.add(opt);
            }
        }
        this.entries.clear();
        this.initEntries(Minecraft.f_33079084, parent, opts.toArray(new Option[0]));
    }

    public void tick() {
        for (OptionEntry entry : this.entries) {
            if (entry instanceof OptionFieldEntry)
                ((OptionFieldEntry) entry).tick();
        }
    }

    public void keyPressed(char c, int key) {
        for (OptionEntry entry : this.entries) {
            if (entry instanceof OptionFieldEntry)
                ((OptionFieldEntry) entry).keyPressed(c, key);
        }
    }

    public boolean isValid() {
        for (OptionEntry entry : this.entries) {
            if (!entry.isValid()) return false;
        }
        return true;
    }
}
