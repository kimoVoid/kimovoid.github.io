package io.github.kimovoid.silk.gui.entries;

import io.github.kimovoid.silk.gui.ConfigEntryListWidget;
import io.github.kimovoid.silk.gui.ConfigScreen;
import io.github.kimovoid.silk.gui.widgets.BooleanButtonWidget;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_96603444;
import net.ornithemc.osl.config.api.config.option.BooleanOption;

public class BooleanEntry extends OptionEntry {

    public BooleanEntry(Minecraft mc, int id, ConfigScreen parent, BooleanOption option) {
        super(mc, id, parent, option);
        this.btn = ConfigEntryListWidget.createWidget(id, 0, 0, option);
        this.resetBtn.setParent(btn);
    }

    @Override
    public void render(int index, int x, int y, int width, int height, C_96603444 bufferBuilder, int mouseX, int mouseY, boolean hovered) {
        this.getButton().f_99054304 = x + width - 132;
        this.getButton().f_24716782 = y;
        this.getButton().m_43811351(this.mc, mouseX, mouseY);
        super.render(index, x, y, width, height, bufferBuilder, mouseX, mouseY, hovered);
    }

    @Override
    public boolean mouseClicked(int index, int mouseX, int mouseY, int button, int entryMouseX, int entryMouseY) {
        if (this.getButton().m_07260289(mc, mouseX, mouseY)) {
            this.btn.toggle();
            this.resetBtn.update();
            mc.f_52467463.m_61706856("random.click", 1.0F, 1.0F);
            return true;
        }
        super.mouseClicked(index, mouseX, mouseY, button, entryMouseX, entryMouseY);
        return false;
    }

    @Override
    public void mouseReleased(int index, int mouseX, int mouseY, int button, int entryMouseX, int entryMouseY) {
        super.mouseReleased(index, mouseX, mouseY, button, entryMouseX, entryMouseY);
        this.getButton().m_77579459(mouseX, mouseY);
    }

    private BooleanButtonWidget getButton() {
        return (BooleanButtonWidget) this.btn;
    }
}
