package io.github.kimovoid.silk.option;

import net.ornithemc.osl.config.api.config.option.BaseOption;

import java.util.function.Predicate;

public class StringCycleOption extends BaseOption<String> {

    private final String[] options;

    public StringCycleOption(String name, String description, String defaultValue, String... options) {
        super(name, description, defaultValue);
        this.options = options;
    }

    public StringCycleOption(String name, String description, String defaultValue, Predicate<String> validator, String... options) {
        super(name, description, defaultValue, validator);
        this.options = options;
    }

    public String[] getOptions() {
        return this.options;
    }
}
