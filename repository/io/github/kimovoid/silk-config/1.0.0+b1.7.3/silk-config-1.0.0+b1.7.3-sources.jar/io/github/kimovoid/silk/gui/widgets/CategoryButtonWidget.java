package io.github.kimovoid.silk.gui.widgets;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_16154270;
import net.minecraft.unmapped.C_85125467;
import io.github.kimovoid.silk.gui.ConfigScreen;

public class CategoryButtonWidget extends C_85125467 {

    private final ConfigScreen parent;
    private final String category;

    public CategoryButtonWidget(int id, int x, int y, String category, ConfigScreen parent) {
        super(id, x, y, Minecraft.f_33079084.f_21497584.m_09235706(C_16154270.m_56062593().m_77288988(parent.getNamespace() + ".category." + category)) + 14, 20, C_16154270.m_56062593().m_77288988(parent.getNamespace() + ".category." + category));
        this.parent = parent;
        this.category = category;
        this.f_89460239 = !this.parent.getCategory().equals(category);
    }

    public void openCategoryScreen() {
        Minecraft.f_33079084.m_52715402(new ConfigScreen(parent.getConfig(), parent.getMainCategory(), this.category, this.parent.getParent()));
    }

    public int getWidth() {
        return this.f_64784750;
    }
}
