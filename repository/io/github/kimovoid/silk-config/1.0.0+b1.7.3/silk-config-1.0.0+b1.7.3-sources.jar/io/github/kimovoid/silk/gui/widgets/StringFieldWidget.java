package io.github.kimovoid.silk.gui.widgets;

import net.ornithemc.osl.config.api.config.option.StringOption;

public class StringFieldWidget extends OptionFieldWidget {

    private final StringOption option;

    public StringFieldWidget(int x, int y, StringOption opt) {
        super(x, y, opt);
        this.option = opt;
        this.m_31911570(opt.get());
    }

    @Override
    public boolean isValid() {
        return true;
    }

    @Override
    public void toggle() {
        this.option.set(this.m_79292215());
    }

    @Override
    public void updateMessage() {
        this.m_31911570(this.option.get());
    }
}
