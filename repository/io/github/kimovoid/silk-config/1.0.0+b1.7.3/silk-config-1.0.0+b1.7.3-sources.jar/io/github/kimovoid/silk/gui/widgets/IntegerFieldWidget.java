package io.github.kimovoid.silk.gui.widgets;

import net.ornithemc.osl.config.api.config.option.IntegerOption;
import io.github.kimovoid.silk.mixin.BaseOptionAccessor;

import java.util.function.Predicate;

public class IntegerFieldWidget extends OptionFieldWidget {

    public IntegerFieldWidget(int x, int y, IntegerOption opt) {
        super(x, y, opt);
    }

    @Override
    public void toggle() {
        super.toggle();
        if (this.isValid()) {
            int i = this.m_79292215().isEmpty() ? 0 : Integer.parseInt(this.m_79292215());
            this.getIntegerOption().set(i);
        }
    }

    @Override
    public void validate() {
        try {
            int i = Integer.parseInt(this.m_79292215());
            Predicate<Object> validator = ((BaseOptionAccessor)this.getIntegerOption()).getValidator();
            this.setValid(validator == null || validator.test(i));
        } catch (NumberFormatException ex) {
            this.setValid(false);
        }
        super.validate();
    }

    private IntegerOption getIntegerOption() {
        return (IntegerOption) this.getOption();
    }
}
