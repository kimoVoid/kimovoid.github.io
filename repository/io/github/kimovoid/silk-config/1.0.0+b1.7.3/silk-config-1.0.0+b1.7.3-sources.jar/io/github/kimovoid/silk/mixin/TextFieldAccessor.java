package io.github.kimovoid.silk.mixin;

import net.minecraft.unmapped.C_16178213;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(C_16178213.class)
public interface TextFieldAccessor {

    @Accessor("x")
    void setX(int x);

    @Accessor("y")
    void setY(int y);
}