package io.github.kimovoid.silk.mixin;

import net.ornithemc.osl.config.api.config.option.BaseOption;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.function.Predicate;

@Mixin(value = BaseOption.class, remap = false)
public interface BaseOptionAccessor {

    @Accessor("validator")
    Predicate<Object> getValidator();
}