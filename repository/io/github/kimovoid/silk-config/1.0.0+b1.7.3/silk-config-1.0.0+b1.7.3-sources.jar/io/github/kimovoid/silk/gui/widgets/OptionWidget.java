package io.github.kimovoid.silk.gui.widgets;

public interface OptionWidget {

    public boolean isValid();
    public void toggle();
    public void updateMessage();
}
