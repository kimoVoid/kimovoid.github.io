package io.github.kimovoid.silk;

import io.github.kimovoid.silk.gui.ConfigScreen;
import net.ornithemc.osl.config.api.config.BaseConfig;
import net.ornithemc.osl.config.api.serdes.config.option.JsonOptionSerializers;
import io.github.kimovoid.silk.option.StringCycleOption;
import io.github.kimovoid.silk.config.ExampleConfig;
import net.minecraft.unmapped.C_85740840;
import net.ornithemc.osl.config.api.ConfigManager;
import net.ornithemc.osl.entrypoints.api.ModInitializer;

public class SilkConfig implements ModInitializer {

    public static ExampleConfig CONFIG;

    @Override
    public void init() {
        CONFIG = new ExampleConfig();
        ConfigManager.register(CONFIG);

        /* Options */
        JsonOptionSerializers.register(StringCycleOption.class, String.class);
    }

    /**
     * @param config The OSL BaseConfig object.
     * @param initialCategory The initial category to start in.
     * @param parent Parent screen.
     * @return A <i>ConfigScreen</i> object.
     */
    public static ConfigScreen getScreen(BaseConfig config, String initialCategory, C_85740840 parent) {
        return new ConfigScreen(config, initialCategory, initialCategory, parent);
    }
}
