package io.github.kimovoid.silk.gui.entries;

public interface OptionFieldEntry {

    public void tick();
    public void unfocus();
    public void keyPressed(char ch, int key);
}
