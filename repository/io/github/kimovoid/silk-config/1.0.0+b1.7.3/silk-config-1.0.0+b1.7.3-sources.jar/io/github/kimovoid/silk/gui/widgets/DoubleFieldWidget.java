package io.github.kimovoid.silk.gui.widgets;

import io.github.kimovoid.silk.mixin.BaseOptionAccessor;
import net.ornithemc.osl.config.api.config.option.DoubleOption;

import java.util.function.Predicate;

public class DoubleFieldWidget extends OptionFieldWidget {

    public DoubleFieldWidget(int x, int y, DoubleOption opt) {
        super(x, y, opt);
    }

    @Override
    public void toggle() {
        super.toggle();
        if (this.isValid()) {
            double d = this.m_79292215().isEmpty() ? 0 : Double.parseDouble(this.m_79292215());
            this.getDoubleOption().set(d);
        }
    }

    @Override
    public void validate() {
        try {
            double d = Double.parseDouble(this.m_79292215());
            Predicate<Object> validator = ((BaseOptionAccessor)this.getDoubleOption()).getValidator();
            this.setValid(validator == null || validator.test(d));
        } catch (NumberFormatException ex) {
            this.setValid(false);
        }
        super.validate();
    }

    private DoubleOption getDoubleOption() {
        return (DoubleOption) this.getOption();
    }
}
