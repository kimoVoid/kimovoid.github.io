package io.github.kimovoid.silk.gui.entries;

import io.github.kimovoid.silk.gui.widgets.OptionFieldWidget;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_96603444;
import io.github.kimovoid.silk.gui.ConfigEntryListWidget;
import io.github.kimovoid.silk.gui.ConfigScreen;
import net.ornithemc.osl.config.api.config.option.BaseOption;
import net.ornithemc.osl.config.api.config.option.Option;

public class FieldEntry extends OptionEntry implements OptionFieldEntry {

    public FieldEntry(Minecraft mc, int id, ConfigScreen parent, Option option) {
        super(mc, id, parent, (BaseOption<?>) option);
        this.btn = ConfigEntryListWidget.createWidget(id, 0, 0, option);
        this.resetBtn.setParent(btn);
    }

    @Override
    public void render(int index, int x, int y, int width, int height, C_96603444 bufferBuilder, int mouseX, int mouseY, boolean hovered) {
        this.getButton().setPosition(x + width - 132, y);
        this.getButton().m_30049367();
        super.render(index, x, y, width, height, bufferBuilder, mouseX, mouseY, hovered);
    }

    @Override
    public boolean mouseClicked(int index, int mouseX, int mouseY, int button, int entryMouseX, int entryMouseY) {
        this.getButton().m_27301372(mouseX, mouseY, button);
        super.mouseClicked(index, mouseX, mouseY, button, entryMouseX, entryMouseY);
        return false;
    }

    @Override
    public void tick() {
        this.getButton().m_85307449();
    }

    @Override
    public void keyPressed(char c, int key) {
        this.getButton().m_47314154(c, key);
        this.btn.toggle();
        this.resetBtn.update();
    }

    @Override
    public void unfocus() {
        this.getButton().m_15958311(false);
    }

    private OptionFieldWidget getButton() {
        return (OptionFieldWidget) this.btn;
    }
}
