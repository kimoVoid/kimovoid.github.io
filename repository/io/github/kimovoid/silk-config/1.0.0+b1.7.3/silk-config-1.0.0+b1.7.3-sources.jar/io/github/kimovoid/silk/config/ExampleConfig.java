package io.github.kimovoid.silk.config;

import net.ornithemc.osl.config.api.config.option.FloatOption;
import net.ornithemc.osl.config.api.config.option.validator.IntegerValidators;
import net.ornithemc.osl.config.api.ConfigScope;
import net.ornithemc.osl.config.api.LoadingPhase;
import net.ornithemc.osl.config.api.config.BaseConfig;
import net.ornithemc.osl.config.api.config.option.BooleanOption;
import net.ornithemc.osl.config.api.config.option.IntegerOption;
import net.ornithemc.osl.config.api.config.option.StringOption;
import net.ornithemc.osl.config.api.serdes.FileSerializerType;
import net.ornithemc.osl.config.api.serdes.SerializerTypes;
import io.github.kimovoid.silk.option.StringCycleOption;

public class ExampleConfig extends BaseConfig {

    public final BooleanOption bool1 = new BooleanOption("bool1", "This is a boolean!", true);
    public final BooleanOption bool2 = new BooleanOption("bool2", "Another boolean!", false);

    public final StringOption text1 = new StringOption("text1", "Type anything!", "Aa");
    public final StringOption text2 = new StringOption("text2", "Type anything!", "Bb");
    public final StringOption text3 = new StringOption("text3", "Type anything!", "Cc");
    public final StringOption text4 = new StringOption("text4", "Type anything!", "Dd");
    public final StringOption text5 = new StringOption("text5", "Type anything!", "Ee");
    public final StringOption text6 = new StringOption("text6", "Type anything!", "Ff");
    public final StringOption text7 = new StringOption("text7", "Type anything!", "Gg");
    public final StringOption text8 = new StringOption("text8", "Type anything!", "Hh");

    public final IntegerOption int1 = new IntegerOption("int", "Type anything!", 1);
    public final IntegerOption int2 = new IntegerOption("ranged-int", "Type anything from 2-200!", 2, IntegerValidators.minmax(2, 200));
    public final FloatOption f = new FloatOption("float", "Type anything!", 3.0f);

    public final StringCycleOption cycle = new StringCycleOption("cycle", "Cycle through these options!", "1", "1", "2", "3", "4", "5");

    @Override
    public String getNamespace() {
        return "silk";
    }

    @Override
    public String getName() {
        return "Silk Example Settings";
    }

    @Override
    public String getSaveName() {
        return "silk.json";
    }

    @Override
    public ConfigScope getScope() {
        return ConfigScope.GLOBAL;
    }

    @Override
    public LoadingPhase getLoadingPhase() {
        return LoadingPhase.START;
    }

    @Override
    public FileSerializerType<?> getType() {
        return SerializerTypes.JSON;
    }

    @Override
    public int getVersion() {
        return 0;
    }

    @Override
    public void init() {
        registerOptions("booleans", bool1, bool2);
        registerOptions("text_fields", text1, text2, text3, text4, text5, text6, text7, text8);
        registerOptions("number_fields", int1, int2, f);
        registerOptions("cycles", cycle);
    }
}
