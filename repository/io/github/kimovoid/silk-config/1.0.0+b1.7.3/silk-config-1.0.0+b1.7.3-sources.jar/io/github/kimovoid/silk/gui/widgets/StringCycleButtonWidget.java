package io.github.kimovoid.silk.gui.widgets;

import io.github.kimovoid.silk.option.StringCycleOption;
import net.minecraft.unmapped.C_16154270;
import net.minecraft.unmapped.C_85125467;

public class StringCycleButtonWidget extends C_85125467 implements OptionWidget {

    private final StringCycleOption option;
    private String namespace;

    public StringCycleButtonWidget(int id, int x, int y, StringCycleOption opt) {
        super(id, x, y, 80, 20, "");
        this.option = opt;
        this.updateMessage();
    }

    @Override
    public boolean isValid() {
        return true;
    }

    @Override
    public void toggle() {
        this.cycle();
        this.updateMessage();
    }

    @Override
    public void updateMessage() {
        this.f_35112386 = C_16154270.m_56062593().m_77288988(this.namespace + ".config." + this.option.getName() + "." + this.option.get());
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
        this.updateMessage();
    }

    public void cycle() {
        int index = -1;
        for (int i = 0; i < this.option.getOptions().length; i++) {
            if (this.option.getOptions()[i].equals(this.option.get())) {
                index = i;
                break;
            }
        }

        index++;
        if (index >= this.option.getOptions().length) {
            index = 0;
        }
        this.option.set(this.option.getOptions()[index]);
    }
}
