package io.github.kimovoid.silk.gui.widgets;

import net.ornithemc.osl.config.api.config.option.BaseOption;
import io.github.kimovoid.silk.mixin.TextFieldAccessor;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_16178213;

public class OptionFieldWidget extends C_16178213 implements OptionWidget {

    private final BaseOption<?> option;
    private boolean valid = true;

    public OptionFieldWidget(int x, int y, BaseOption<?> opt) {
        super(null, Minecraft.f_33079084.f_21497584, x, y, 80, 20, "" + opt.get());
        this.option = opt;
        this.m_31911570(this.option.get().toString());
    }

    @Override
    public void toggle() {
        this.validate();
    }

    @Override
    public void updateMessage() {
        this.m_31911570(this.option.get().toString());
        this.validate();
    }

    @Override
    public boolean isValid() {
        return this.valid;
    }

    public void setValid(boolean b) {
        this.valid = b;
    }

    public BaseOption<?> getOption() {
        return this.option;
    }

    public void validate() {
        //this.updateColor();
    }

    /*
    public void updateColor() {
        if (!this.valid) {
            this.setEditableColor(-52686);
            this.setUneditableColor(-4967886);
        } else {
            this.setEditableColor(14737632);
            this.setUneditableColor(7368816);
        }
    }
     */

    public void setPosition(int x, int y) {
        ((TextFieldAccessor)this).setX(x);
        ((TextFieldAccessor)this).setY(y);
    }
}
