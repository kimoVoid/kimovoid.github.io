package io.github.kimovoid.silk.gui.widgets;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_85125467;
import net.minecraft.unmapped.C_96603444;
import org.lwjgl.opengl.GL11;

public class TexturedButtonWidget extends C_85125467 {

    protected String texture;
    protected final int u;
    protected final int v;
    protected final int vOff;
    protected final int textureWidth;
    protected final int textureHeight;

    public TexturedButtonWidget(int id, int x, int y, int width, int height, int u, int v, int hoveredVOffset, String texture, int textureWidth, int textureHeight) {
        super(id, x, y, width, height, "");
        this.texture = texture;
        this.u = u;
        this.v = v;
        this.vOff = hoveredVOffset;
        this.textureWidth = textureWidth;
        this.textureHeight = textureHeight;
    }

    @Override
    public void m_43811351(Minecraft minecraft, int mouseX, int mouseY) {
        if (this.f_59331544) {
            minecraft.f_45465196.m_72568250(minecraft.f_45465196.m_33729172(this.texture));
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            boolean hovered = mouseX >= this.f_99054304 && mouseY >= this.f_24716782 && mouseX < this.f_99054304 + this.f_64784750 && mouseY < this.f_24716782 + this.f_00173992;
            int u = this.u;
            int v = this.v;
            if (hovered) {
                v += this.vOff;
            }

            float invertedScaleU = 1.0f / textureWidth;
            float invertedScaleV = 1.0f / textureHeight;
            C_96603444 tesselator = C_96603444.f_99414865;
            tesselator.m_35940071();
            tesselator.m_75942980(f_99054304, f_24716782 + f_00173992, 0.0, u * invertedScaleU, (v + (float) f_00173992) * invertedScaleV);
            tesselator.m_75942980(f_99054304 + f_64784750, f_24716782 + f_00173992, 0.0, (u + (float) f_64784750) * invertedScaleU, (v + (float) f_00173992) * invertedScaleV);
            tesselator.m_75942980(f_99054304 + f_64784750, f_24716782, 0.0, (u + (float) f_64784750) * invertedScaleU, v * invertedScaleV);
            tesselator.m_75942980(f_99054304, f_24716782, 0.0, u * invertedScaleU, v * invertedScaleV);
            tesselator.m_70070273();
        }
    }

    public void setTexture(String texture) {
        this.texture = texture;
    }
}
