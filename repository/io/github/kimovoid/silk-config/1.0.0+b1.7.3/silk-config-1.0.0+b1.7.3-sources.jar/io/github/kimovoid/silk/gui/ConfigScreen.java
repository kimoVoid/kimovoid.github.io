package io.github.kimovoid.silk.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_16154270;
import net.minecraft.unmapped.C_16178213;
import net.minecraft.unmapped.C_85125467;
import net.minecraft.unmapped.C_85740840;
import net.ornithemc.osl.config.api.ConfigManager;
import net.ornithemc.osl.config.api.config.BaseConfig;
import net.ornithemc.osl.config.api.config.option.Option;
import net.ornithemc.osl.config.api.config.option.group.OptionGroup;
import org.lwjgl.input.Keyboard;
import io.github.kimovoid.silk.gui.widgets.CategoryButtonWidget;
import io.github.kimovoid.silk.gui.widgets.TexturedButtonWidget;

import java.util.ArrayList;
import java.util.List;

public class ConfigScreen extends C_85740840 {

    private static final String SEARCH_BUTTON_TEXTURE = "/assets/silk-config/textures/gui/search_button.png";
    private static final String X_BUTTON_TEXTURE = "/assets/silk-config/textures/gui/x_button.png";

    private final C_85740840 parent;
    private final BaseConfig config;
    private final String mainCategory;
    private final String category;
    private ConfigEntryListWidget list;
    private C_85125467 doneButton;
    private C_16178213 searchBar;
    private TexturedButtonWidget searchButton;
    private String searchQuery = "";

    public final List<String> tooltip = new ArrayList<>();
    public final String namespace;

    /**
     * @param config The OSL BaseConfig object.
     * @param mainCategory The main category of your config. Often "general".
     * @param category The selected category to display.
     * @param parent Parent screen.
     */
    public ConfigScreen(BaseConfig config, String mainCategory, String category, C_85740840 parent) {
        this.config = config;
        this.namespace = config.getNamespace();
        this.mainCategory = mainCategory;
        this.category = category;
        this.parent = parent;
    }

    @Override
    public void m_53520780() {
        super.m_53520780();
        this.list.tick();
        if (this.searchBar != null) {
            this.searchBar.m_85307449();
        }
    }

    @Override
    public void m_41805697() {
        Keyboard.enableRepeatEvents(true);

        Option[] opts = this.config.getGroup(category).getOptions().toArray(new Option[0]);
        this.list = new ConfigEntryListWidget(this, this.f_78495264, this.f_05230747, this.f_07021018, this.config.getGroups().size() > 1 ? 56 : 32, this.f_07021018 - 32, 25, opts);
        this.f_78519977.add(this.doneButton = new C_85125467(0, this.f_05230747 / 2 - 100, this.f_07021018 - 28, C_16154270.m_56062593().m_77288988("gui.done")));
        this.f_78519977.add(this.searchButton = new TexturedButtonWidget(1, this.f_05230747 / 2 - 10 + f_11884601.m_09235706(this.config.getName()) / 2, 3, 20, 20, 0, 0, 20, SEARCH_BUTTON_TEXTURE, 32, 64));
        this.searchBar = null; // resizing a window fucks this up so its best to just disable it

        if (this.config.getGroups().size() == 1) {
            return;
        }

        int w = 0;
        for (OptionGroup group : this.config.getGroups()) {
            w += Minecraft.f_33079084.f_21497584.m_09235706(C_16154270.m_56062593().m_77288988(this.config.getNamespace() + ".category." + group.getName())) + 14;
        }

        int x = 1;
        int id = 1;
        for (OptionGroup group : this.config.getGroups()) {
            CategoryButtonWidget btn = new CategoryButtonWidget(id++, f_05230747 / 2 - w / 2 + x, 34, group.getName(), this);
            this.f_78519977.add(btn);
            x += btn.getWidth();
        }
    }

    @Override
    public void m_47002234() {
        Keyboard.enableRepeatEvents(false);
    }

    @Override
    public void m_23755539(int mouseX, int mouseY, int button) {
        this.list.mouseClicked(mouseX, mouseY, button);
        if (this.searchBar != null) {
            this.searchBar.m_27301372(mouseX, mouseY, button);
        }
        super.m_23755539(mouseX, mouseY, button);
    }

    @Override
    public void m_30778170(C_85125467 btn) {
        if (btn.f_92999450 == 0) {
            ConfigManager.save(this.config);
            this.f_78495264.m_52715402(this.parent);
        }

        if (btn.f_92999450 == 1) {
            this.toggleSearchBar();
        }

        if (btn instanceof CategoryButtonWidget) {
            ((CategoryButtonWidget)btn).openCategoryScreen();
        }
    }

    @Override
    public void m_29116903(char c, int key) {
        super.m_29116903(c, key);
        this.list.keyPressed(c, key);
        if (this.searchBar != null) {
            this.searchBar.m_47314154(c, key);
        }
    }

    @Override
    public void m_93956703(int mouseX, int mouseY, float tickDelta) {
        this.m_34695786();
        this.tooltip.clear();
        this.list.render(mouseX, mouseY, tickDelta);
        if (this.searchBar != null) {
            this.searchBar.m_30049367();
        } else {
            this.m_50067982(this.f_11884601, this.config.getName(), (this.f_05230747 / 2) - 12, 9, 16777215);
        }

        if (!this.list.isValid()) {
            this.doneButton.f_35112386 = C_16154270.m_56062593().m_77288988("silk.button.invalid");
            this.doneButton.f_89460239 = false;
            this.m_50067982(this.f_11884601, C_16154270.m_56062593().m_77288988("silk.invalid"), this.f_05230747 / 2, 19, 16777215);
        } else {
            this.doneButton.f_35112386 = C_16154270.m_56062593().m_77288988("gui.done");
            this.doneButton.f_89460239 = true;
        }

        super.m_93956703(mouseX, mouseY, tickDelta);
        if (!this.tooltip.isEmpty()) {
            this.renderTooltip(this.tooltip, mouseX, mouseY);
        }
    }

    public void toggleSearchBar() {
        if (this.searchBar == null) {
            this.searchButton.f_99054304 = this.f_05230747 / 2 + 77 - 10;
            this.searchBar = new C_16178213(this.parent, this.f_78495264.f_21497584, this.f_05230747 / 2 - 75 - 10, 3, 150, 20, "") {
                @Override
                public void m_47314154(char chr, int key) {
                    super.m_47314154(chr, key);
                    searchQuery = this.m_79292215();
                    list.search(ConfigScreen.this, this.m_79292215());
                }
            };
            this.searchBar.f_03252369 = true;
            this.searchBar.m_31911570(this.searchQuery);
            this.searchButton.setTexture(X_BUTTON_TEXTURE);
        } else {
            this.searchButton.f_99054304 = this.f_05230747 / 2 - 10 + f_11884601.m_09235706(this.config.getName()) / 2;
            this.searchQuery = "";
            this.searchBar = null;
            list.search(ConfigScreen.this, "");
            this.searchButton.setTexture(SEARCH_BUTTON_TEXTURE);
        }
    }

    protected void renderTooltip(List<String> string, int i, int j) {
        if (string == null) {
            return;
        }
        int n = i + 12;
        int n2 = j - 12;
        int n3 = 0;
        for (String s : string) {
            int width = this.f_11884601.m_09235706(s);
            if (width > n3) n3 = width;
        }
        this.m_58083806(n - 3, n2 - 3, n + n3 + 3, n2 + 12 * string.size(), -1073741824, -1073741824);
        for (String s : string) {
            this.f_11884601.m_27673420(s, n, n2, -1);
            n2 += 12;
        }
    }

    public C_85740840 getParent() {
        return this.parent;
    }

    public BaseConfig getConfig() {
        return this.config;
    }

    public String getMainCategory() {
        return this.mainCategory;
    }

    public String getCategory() {
        return this.category;
    }

    public String getNamespace() {
        return this.namespace;
    }
}
