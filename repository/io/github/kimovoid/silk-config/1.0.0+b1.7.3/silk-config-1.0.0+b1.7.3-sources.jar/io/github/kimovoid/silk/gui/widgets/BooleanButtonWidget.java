package io.github.kimovoid.silk.gui.widgets;

import net.minecraft.unmapped.C_16154270;
import net.minecraft.unmapped.C_85125467;
import net.ornithemc.osl.config.api.config.option.BooleanOption;

public class BooleanButtonWidget extends C_85125467 implements OptionWidget {

    private final BooleanOption option;

    public BooleanButtonWidget(int id, int x, int y, BooleanOption opt) {
        super(id, x, y, 80, 20, "");
        this.option = opt;
        this.updateMessage();
    }

    @Override
    public boolean isValid() {
        return true;
    }

    @Override
    public void toggle() {
        this.option.set(!this.option.get());
        this.updateMessage();
    }

    @Override
    public void updateMessage() {
        this.f_35112386 = C_16154270.m_56062593().m_77288988(this.option.get() ? "silk.on" : "silk.off");
    }
}
