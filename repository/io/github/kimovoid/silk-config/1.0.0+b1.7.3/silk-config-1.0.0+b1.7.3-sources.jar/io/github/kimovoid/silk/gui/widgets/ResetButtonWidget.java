package io.github.kimovoid.silk.gui.widgets;

import net.minecraft.unmapped.C_85125467;
import net.ornithemc.osl.config.api.config.option.Option;

public class ResetButtonWidget extends C_85125467 {

    private final Option option;
    private OptionWidget parent = null;

    public ResetButtonWidget(int id, int x, int y, Option opt) {
        super(id, x, y, 50, 20, "Reset");
        this.option = opt;
        this.update();
    }

    public void reset() {
        this.option.reset();
        this.update();
        if (this.parent != null) this.parent.updateMessage();
    }

    public void update() {
        this.f_89460239 = !this.option.isDefault();
    }

    public void setParent(OptionWidget btn) {
        this.parent = btn;
    }
}
