package io.github.kimovoid.silk.gui.entries;

import io.github.kimovoid.silk.gui.ConfigScreen;
import io.github.kimovoid.silk.gui.widgets.OptionWidget;
import io.github.kimovoid.silk.gui.widgets.ResetButtonWidget;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_16154270;
import net.minecraft.unmapped.C_96603444;
import net.ornithemc.osl.config.api.config.option.BaseOption;
import io.github.kimovoid.silk.gui.widgets.backport.EntryListWidget;

public class OptionEntry implements EntryListWidget.Entry {

    final BaseOption<?> opt;
    OptionWidget btn;
    final ResetButtonWidget resetBtn;
    final ConfigScreen parent;
    final Minecraft mc;

    public OptionEntry(Minecraft mc, int id, ConfigScreen parent, BaseOption<?> option) {
        this.mc = mc;
        this.opt = option;
        this.parent = parent;
        this.resetBtn = new ResetButtonWidget(id, 0, 0, option);
    }

    @Override
    public void render(int index, int x, int y, int width, int height, C_96603444 bufferBuilder, int mouseX, int mouseY, boolean hovered) {
        this.resetBtn.f_99054304 = x + width - 50;
        this.resetBtn.f_24716782 = y;
        this.resetBtn.m_43811351(mc, mouseX, mouseY);

        String text = C_16154270.m_56062593().m_77288988(parent.namespace + ".config." + this.opt.getName());
        mc.f_21497584.m_27673420(text, x, y + 4, this.btn.isValid() ? 0xffffff : -52686);

        /* Tooltip */
        int textWidth = mc.f_21497584.m_09235706(text);
        if (mouseX >= x - 2 && mouseY >= y + 2 && mouseX < x + textWidth + 3 && mouseY < y + 14) {
            parent.tooltip.add("§e" + opt.getName());
            parent.tooltip.add(this.opt.getDescription());
            parent.tooltip.add(String.format("§7(Default: %s)", opt.getDefault()));
        }
    }

    @Override
    public boolean mouseClicked(int index, int mouseX, int mouseY, int button, int entryMouseX, int entryMouseY) {
        if (this.resetBtn.m_07260289(mc, mouseX, mouseY) && this.resetBtn.f_89460239) {
            this.resetBtn.reset();
            mc.f_52467463.m_61706856("random.click", 1.0F, 1.0F);
            return true;
        }
        return false;
    }

    @Override
    public void mouseReleased(int index, int mouseX, int mouseY, int button, int entryMouseX, int entryMouseY) {
        this.resetBtn.m_77579459(mouseX, mouseY);
    }

    public boolean isValid() {
        return this.btn.isValid();
    }
}
