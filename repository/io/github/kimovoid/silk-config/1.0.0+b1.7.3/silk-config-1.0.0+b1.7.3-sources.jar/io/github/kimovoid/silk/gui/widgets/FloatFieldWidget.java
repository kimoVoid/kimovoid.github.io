package io.github.kimovoid.silk.gui.widgets;

import net.ornithemc.osl.config.api.config.option.FloatOption;
import io.github.kimovoid.silk.mixin.BaseOptionAccessor;

import java.util.function.Predicate;

public class FloatFieldWidget extends OptionFieldWidget {

    public FloatFieldWidget(int x, int y, FloatOption opt) {
        super(x, y, opt);
    }

    @Override
    public void toggle() {
        super.toggle();
        if (this.isValid()) {
            float f = this.m_79292215().isEmpty() ? 0 : Float.parseFloat(this.m_79292215());
            this.getFloatOption().set(f);
        }
    }

    @Override
    public void validate() {
        try {
            float f = Float.parseFloat(this.m_79292215());
            Predicate<Object> validator = ((BaseOptionAccessor)this.getFloatOption()).getValidator();
            this.setValid(validator == null || validator.test(f));
        } catch (NumberFormatException ex) {
            this.setValid(false);
        }
        super.validate();
    }

    private FloatOption getFloatOption() {
        return (FloatOption) this.getOption();
    }
}
