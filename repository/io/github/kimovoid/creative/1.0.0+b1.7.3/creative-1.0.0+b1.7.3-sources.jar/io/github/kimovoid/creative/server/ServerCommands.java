package io.github.kimovoid.creative.server;

import com.periut.retrocommands.util.ServerUtil;
import com.periut.retrocommands.util.SharedCommandSource;
import io.github.kimovoid.creative.interfaces.CreativePlayer;
import net.minecraft.unmapped.C_40996800;

public class ServerCommands {

    public static void changePlayerGameMode(SharedCommandSource source, boolean creative, String targetName) {
        C_40996800 target = ServerUtil.getConnectionManager().m_77290284(targetName);
        if (target == null) {
            source.sendFeedback("Can't find user " + targetName + ".");
            return;
        }

        ((CreativePlayer)target).setCreative(creative);
        source.sendFeedback("Set " + target.f_59008391 + "'s game mode to " + (creative ? "Creative" : "Survival") + " Mode");
    }
}
