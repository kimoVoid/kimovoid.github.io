package io.github.kimovoid.creative.mixin.common;

import io.github.kimovoid.creative.interfaces.CreativePlayer;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_88708284;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_88708284.class)
public class ItemStackMixin {

	@Unique private static int count;
	@Shadow public int size;
	
	@Inject(method = "useOn", at = @At("HEAD"))
	private void beforeUseOnTile(C_40996800 player, C_64041439 world, int x, int y, int z, int face, CallbackInfoReturnable<Boolean> cir) {
		if (((CreativePlayer)player).isCreative()) count = size;
	}
	
	@Inject(method = "useOn", at = @At("RETURN"))
	private void afterUseOnTile(C_40996800 player, C_64041439 world, int x, int y, int z, int face, CallbackInfoReturnable<Boolean> cir) {
		if (((CreativePlayer)player).isCreative()) size = count;
	}

	@Inject(method = "takeDamageAndBreak", at = @At("HEAD"), cancellable = true)
	private void removeItemDamage(int amount, C_42232651 holder, CallbackInfo ci) {
		if (holder instanceof C_40996800 && ((CreativePlayer)holder).isCreative()) {
			ci.cancel();
		}
	}
}
