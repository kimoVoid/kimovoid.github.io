package io.github.kimovoid.creative.mixin.client;

import io.github.kimovoid.creative.interfaces.CreativePlayer;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_54765678;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_54765678.class)
public abstract class SurvivalInteractionManagerMixin {

    @Shadow private int miningCooldown;

    @Inject(method = "tickBlockMining", at = @At("HEAD"), cancellable = true)
    private void instantMine(int x, int y, int z, int face, CallbackInfo ci) {
        if (!((CreativePlayer) Minecraft.f_33079084.f_28396371).isCreative() || this.miningCooldown > 0) {
            return;
        }
        ci.cancel();
    }

    @Inject(method = "getReach", at = @At("RETURN"), cancellable = true)
    private void setCreativeReach(CallbackInfoReturnable<Float> cir) {
        if (((CreativePlayer) Minecraft.f_33079084.f_28396371).isCreative()) {
            cir.setReturnValue(cir.getReturnValue() + 1.0F);
        }
    }
}
