package io.github.kimovoid.creative.client.gui;

import io.github.kimovoid.creative.client.util.ITextRenderer;
import io.github.kimovoid.creative.client.util.TextFieldUtils;
import net.minecraft.unmapped.C_23014920;
import net.minecraft.unmapped.C_29058632;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_96603444;
import org.lwjgl.Sys;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class SearchTextFieldWidget extends C_29058632 {

    private final C_23014920 textRenderer;
    private final int x;
    private final int y;
    private final int width;
    private final int height;
    private int focusedTicks;
    private String text;
    private int maxLength = 32;
    public boolean editable = true;
    public boolean focused = false;

    private boolean hasBorder = true;
    private int firstCharacterIndex = 0;
    private int selectionStart = 0;
    private int selectionEnd = 0;
    private int editableColor = 14737632;
    private boolean visible = true;

    public SearchTextFieldWidget(C_23014920 textRenderer, int x, int y, int width, int height) {
        this.textRenderer = textRenderer;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void setText(String text) {
        if (text.length() > this.maxLength) {
            this.text = text.substring(0, this.maxLength);
        } else {
            this.text = text;
        }

        this.setCursorToEnd();
    }

    public String getText() {
        return this.text;
    }
    
    public boolean keyPressed(char chr, int code) {
        if (this.editable && this.focused) {
            /* LWJGL 2 uses char control codes */
            switch (chr) {
                case 1:
                    this.setCursorToEnd();
                    this.setSelectionEnd(0);
                    return true;
                case 3:
                    TextFieldUtils.setClipboard(this.getSelectedText());
                    return true;
                case 22:
                    this.write(C_85740840.m_38845775());
                    return true;
                case 24:
                    TextFieldUtils.setClipboard(this.getSelectedText());
                    this.write("");
                    return true;
            }

            /* So if LWJGL 3 is installed, we check for key codes instead */
            boolean lwjgl3 = Sys.getVersion().startsWith("3");
            if (lwjgl3 && TextFieldUtils.isControlDown()) {
                switch (code) {
                    case Keyboard.KEY_A:
                        this.setCursorToEnd();
                        this.setSelectionEnd(0);
                        return true;
                    case Keyboard.KEY_C:
                        TextFieldUtils.setClipboard(this.getSelectedText());
                        return true;
                    case Keyboard.KEY_V:
                        this.write(C_85740840.m_38845775());
                        return true;
                    case Keyboard.KEY_X:
                        TextFieldUtils.setClipboard(this.getSelectedText());
                        this.write("");
                        return true;
                }
            }

            switch (code) {
                case 14:
                    if (TextFieldUtils.isControlDown()) {
                        this.eraseWords(-1);
                    } else {
                        this.eraseCharacters(-1);
                    }
                    return true;

                case 199:
                    if (TextFieldUtils.isShiftDown()) {
                        this.setSelectionEnd(0);
                    } else {
                        this.setCursorToStart();
                    }
                    return true;

                case 203:
                    if (TextFieldUtils.isShiftDown()) {
                        if (TextFieldUtils.isControlDown()) {
                            this.setSelectionEnd(this.getWordSkipPosition(-1, this.getSelectionEnd()));
                        } else {
                            this.setSelectionEnd(this.getSelectionEnd() - 1);
                        }
                    } else if (TextFieldUtils.isControlDown()) {
                        this.setCursor(this.getWordSkipPosition(-1));
                    } else {
                        this.moveCursor(-1);
                    }
                    return true;

                case 205:
                    if (TextFieldUtils.isShiftDown()) {
                        if (TextFieldUtils.isControlDown()) {
                            this.setSelectionEnd(this.getWordSkipPosition(1, this.getSelectionEnd()));
                        } else {
                            this.setSelectionEnd(this.getSelectionEnd() + 1);
                        }
                    } else if (TextFieldUtils.isControlDown()) {
                        this.setCursor(this.getWordSkipPosition(1));
                    } else {
                        this.moveCursor(1);
                    }
                    return true;

                case 207:
                    if (TextFieldUtils.isShiftDown()) {
                        this.setSelectionEnd(this.text.length());
                    } else {
                        this.setCursorToEnd();
                    }
                    return true;

                case 211:
                    if (TextFieldUtils.isControlDown()) {
                        this.eraseWords(1);
                    } else {
                        this.eraseCharacters(1);
                    }
                    return true;

                default:
                    if (TextFieldUtils.isValidChatChar(chr)) {
                        this.write(Character.toString(chr));
                        return true;
                    } else {
                        return false;
                    }
            }
        }
        return false;
    }

    public void setFocused(boolean focused) {
        if (focused && !this.focused) {
            this.focusedTicks = 0;
        }

        this.focused = focused;
    }

    public void render() {
        if (this.isVisible()) {
            if (this.hasBorder()) {
                m_57734177(this.x - 1, this.y - 1, this.x + this.width + 1, this.y + this.height + 1, -6250336);
                m_57734177(this.x, this.y, this.x + this.width, this.y + this.height, -16777216);
            }

            int i = this.editableColor;
            int j = this.selectionStart - this.firstCharacterIndex;
            int k = this.selectionEnd - this.firstCharacterIndex;
            String string = ((ITextRenderer)this.textRenderer).trim(this.text.substring(this.firstCharacterIndex), this.getInnerWidth());
            int l = j >= 0 && j <= string.length() ? 1 : 0;
            int m = this.focused && this.focusedTicks / 6 % 2 == 0 && l != 0 ? 1 : 0;
            int n = this.hasBorder ? this.x + 4 : this.x;
            int o = this.hasBorder ? this.y + (this.height - 8) / 2 : this.y;
            int p = n;
            if (k > string.length()) {
                k = string.length();
            }

            if (!string.isEmpty()) {
                String string2 = l != 0 ? string.substring(0, j) : string;
                this.textRenderer.m_27673420(string2, p, o, i);
                p += this.textRenderer.m_09235706(string2) + 1;
            }

            int q = this.selectionStart >= this.text.length() && this.text.length() < this.getMaxLength() ? 0 : 1;
            int r = p;
            if (l == 0) {
                r = j > 0 ? n + this.width : n;
            } else if (q != 0) {
                r--;
                p--;
            }

            if (!string.isEmpty() && l != 0 && j < string.length()) {
                this.textRenderer.m_27673420(string.substring(j), p, o, i);
            }

            if (m != 0) {
                if (q != 0) {
                    this.m_57734177(r, o - 1, r + 1, o + 1 + 9, -3092272);
                } else {
                    this.textRenderer.m_27673420("_", r, o, i);
                }
            }

            if (k != j) {
                int s = n + this.textRenderer.m_09235706(string.substring(0, k));
                this.renderSelection(r, o - 1, s - 1, o + 1 + 9);
            }
        }
    }
    
    public String getSelectedText() {
        int i = Math.min(this.selectionStart, this.selectionEnd);
        int j = Math.max(this.selectionStart, this.selectionEnd);
        return this.text.substring(i, j);
    }
    
    public void write(String text) {
        String string = "";
        String string2 = TextFieldUtils.stripInvalidChars(text);
        int i = Math.min(this.selectionStart, this.selectionEnd);
        int j = Math.max(this.selectionStart, this.selectionEnd);
        int k = this.maxLength - this.text.length() - (i - this.selectionEnd);
        int l;
        if (!this.text.isEmpty()) {
            string = string + this.text.substring(0, i);
        }

        if (k < string2.length()) {
            string = string + string2.substring(0, k);
            l = k;
        } else {
            string = string + string2;
            l = string2.length();
        }

        if (!this.text.isEmpty() && j < this.text.length()) {
            string = string + this.text.substring(j);
        }

        this.text = string;
        this.moveCursor(i - this.selectionEnd + l);
    }
    
    public void eraseWords(int wordOffset) {
        if (!this.text.isEmpty()) {
            if (this.selectionEnd != this.selectionStart) {
                this.write("");
            } else {
                this.eraseCharacters(this.getWordSkipPosition(wordOffset) - this.selectionStart);
            }
        }
    }
    
    public void eraseCharacters(int characterOffset) {
        if (!this.text.isEmpty()) {
            if (this.selectionEnd != this.selectionStart) {
                this.write("");
            } else {
                int i = characterOffset < 0 ? 1 : 0;
                int j = i != 0 ? this.selectionStart + characterOffset : this.selectionStart;
                int k = i != 0 ? this.selectionStart : this.selectionStart + characterOffset;
                String string = "";
                if (j >= 0) {
                    string = this.text.substring(0, j);
                }

                if (k < this.text.length()) {
                    string = string + this.text.substring(k);
                }

                this.text = string;
                if (i != 0) {
                    this.moveCursor(characterOffset);
                }
            }
        }
    }

    public int getWordSkipPosition(int wordOffset) {
        return this.getWordSkipPosition(wordOffset, this.getCursor());
    }

    public int getWordSkipPosition(int wordOffset, int cursorPosition) {
        return this.getWordSkipPosition(wordOffset, this.getCursor(), true);
    }

    public int getWordSkipPosition(int wordOffset, int cursorPosition, boolean skipOverSpaces) {
        int i = cursorPosition;
        int j = wordOffset < 0 ? 1 : 0;
        int k = Math.abs(wordOffset);

        for (int l = 0; l < k; l++) {
            if (j == 0) {
                int m = this.text.length();
                i = this.text.indexOf(32, i);
                if (i == -1) {
                    i = m;
                } else {
                    while (skipOverSpaces && i < m && this.text.charAt(i) == ' ') {
                        i++;
                    }
                }
            } else {
                while (skipOverSpaces && i > 0 && this.text.charAt(i - 1) == ' ') {
                    i--;
                }

                while (i > 0 && this.text.charAt(i - 1) != ' ') {
                    i--;
                }
            }
        }

        return i;
    }

    public void moveCursor(int offset) {
        this.setCursor(this.selectionEnd + offset);
    }

    public void setCursor(int cursor) {
        this.selectionStart = cursor;
        int i = this.text.length();
        if (this.selectionStart < 0) {
            this.selectionStart = 0;
        }

        if (this.selectionStart > i) {
            this.selectionStart = i;
        }

        this.setSelectionEnd(this.selectionStart);
    }

    public void setCursorToStart() {
        this.setCursor(0);
    }

    public void setCursorToEnd() {
        this.setCursor(this.text.length());
    }

    public void renderSelection(int x1, int y1, int x2, int y2) {
        if (x1 < x2) {
            int i = x1;
            x1 = x2;
            x2 = i;
        }

        if (y1 < y2) {
            int j = y1;
            y1 = y2;
            y2 = j;
        }

        C_96603444 tesselator = C_96603444.f_99414865;
        GL11.glColor4f(0.0F, 0.0F, 255.0F, 255.0F);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_COLOR_LOGIC_OP);
        GL11.glLogicOp(GL11.GL_OR_REVERSE);
        tesselator.m_35940071();
        tesselator.m_51994127(x1, y2, 0.0);
        tesselator.m_51994127(x2, y2, 0.0);
        tesselator.m_51994127(x2, y1, 0.0);
        tesselator.m_51994127(x1, y1, 0.0);
        tesselator.m_70070273();
        GL11.glDisable(GL11.GL_COLOR_LOGIC_OP);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
    }

    public int getMaxLength() {
        return this.maxLength;
    }

    public int getCursor() {
        return this.selectionStart;
    }

    public int getInnerWidth() {
        return this.hasBorder() ? this.width - 8 : this.width;
    }

    public boolean hasBorder() {
        return this.hasBorder;
    }

    public void setHasBorder(boolean hasBorder) {
        this.hasBorder = hasBorder;
    }

    public void setEditableColor(int color) {
        this.editableColor = color;
    }

    public int getSelectionEnd() {
        return this.selectionEnd;
    }

    public void setSelectionEnd(int index) {
        int i = this.text.length();
        if (index > i) {
            index = i;
        }

        if (index < 0) {
            index = 0;
        }

        this.selectionEnd = index;
        if (this.textRenderer != null) {
            if (this.firstCharacterIndex > i) {
                this.firstCharacterIndex = i;
            }

            int j = this.getInnerWidth();
            String string = ((ITextRenderer)this.textRenderer).trim(this.text.substring(this.firstCharacterIndex), j);
            int k = string.length() + this.firstCharacterIndex;
            if (index == this.firstCharacterIndex) {
                this.firstCharacterIndex = this.firstCharacterIndex - ((ITextRenderer)this.textRenderer).trim(this.text, j, true).length();
            }

            if (index > k) {
                this.firstCharacterIndex += index - k;
            } else if (index <= this.firstCharacterIndex) {
                this.firstCharacterIndex = this.firstCharacterIndex - (this.firstCharacterIndex - index);
            }

            if (this.firstCharacterIndex < 0) {
                this.firstCharacterIndex = 0;
            }

            if (this.firstCharacterIndex > i) {
                this.firstCharacterIndex = i;
            }
        }
    }

    public boolean isVisible() {
        return this.visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public void setMaxLength(int maximumLength) {
        this.maxLength = maximumLength;
    }
}
