package io.github.kimovoid.creative.mixin.common;

import io.github.kimovoid.creative.interfaces.CreativePlayer;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_64104387;
import net.minecraft.unmapped.C_74425583;
import net.minecraft.unmapped.C_81592558;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_81592558.class)
public abstract class BlockMixin {

	@Inject(method = "getMiningSpeed", at = @At("HEAD"), cancellable = true)
	private void calcBlockBreakingDelta(C_40996800 player, CallbackInfoReturnable<Float> info) {
		if (((CreativePlayer) player).isCreative()) {
			boolean holdingSword = player.m_01577449() != null && player.m_01577449().m_23235460() instanceof C_64104387;
			info.setReturnValue(holdingSword ? 0F : 1.0F);
		}
	}

	@Inject(
			method = "afterMinedByPlayer",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/block/Block;dropItems(Lnet/minecraft/world/World;IIII)V"
			),
			cancellable = true
	)
	private void cancelBlockDrops(C_64041439 world, C_40996800 player, int x, int y, int z, int metadata, CallbackInfo ci) {
		if (((CreativePlayer) player).isCreative()) {
			ci.cancel();
		}
	}

	@Inject(method = "onPlaced", at = @At("TAIL"))
	private void fixMeta(C_64041439 world, int x, int y, int z, C_74425583 entity, CallbackInfo ci) {
		if (entity instanceof C_40996800 && ((CreativePlayer) entity).isCreative()) {
			C_40996800 pl = (C_40996800) entity;
			if (pl.m_01577449().f_59294634 != world.m_33234383(x, y, z) || pl.m_01577449().m_21098843() == 0) {
				return;
			}
			world.m_38188749(x, y, z, pl.m_01577449().m_21098843());
		}
	}
}
