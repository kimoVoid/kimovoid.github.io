package io.github.kimovoid.creative.mixin.client;

import io.github.kimovoid.creative.interfaces.CreativeWorldSaveInfo;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_87007645;
import net.minecraft.unmapped.C_96603444;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(targets = "net.minecraft.client.gui.screen.world.SelectWorldScreen$WorldListWidget")
public abstract class WorldListMixin {

	@Inject(
			method = "renderEntry",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/gui/screen/world/SelectWorldScreen;drawString(Lnet/minecraft/client/render/TextRenderer;Ljava/lang/String;III)V",
					ordinal = 2,
					shift = Shift.AFTER
			),
			locals = LocalCapture.CAPTURE_FAILSOFT
	)
	protected void renderEntry(int index, int x, int y, int height, C_96603444 tesselator, CallbackInfo ci, C_87007645 worldSaveInfo, String string7, String string8, long l, String string10) {
		boolean isCreative = ((CreativeWorldSaveInfo)worldSaveInfo).isCreative();
		String gameMode = isCreative ? "Creative Mode" : "Survival Mode";
		Minecraft.f_33079084.f_21497584.m_27673420(gameMode, x + 2, y + 12 + 10, 0x808080);
	}
}
