package io.github.kimovoid.creative.mixin.client;

import io.github.kimovoid.creative.interfaces.CreativeWorldData;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_64676926;
import net.minecraft.unmapped.C_74087615;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(C_64676926.class)
public class WorldDataMixin implements CreativeWorldData {

	@Unique private boolean isCreative;
	
	@Inject(method = "<init>(Lnet/minecraft/nbt/NbtCompound;)V", at = @At("TAIL"))
	private void onInit(C_74087615 nbt, CallbackInfo ci) {
		isCreative = nbt.m_35587574("GameType") == 1;
		if (!isCreative && nbt.m_97612750("Player")) {
			isCreative = nbt.m_81819352("Player").m_35587574("playerGameType") == 1;
		}
	}
	
	@Override
	public boolean isCreative() {
		return isCreative;
	}
	
	@Override
	public void setCreative(boolean creative) {
		isCreative = creative;
	}
}
