package io.github.kimovoid.creative.client.util;

public interface ITextRenderer {

    default int getWidth(char chr) {
        throw new UnsupportedOperationException();
    }
    default String trim(String text, int width) {
        throw new UnsupportedOperationException();
    }
    default String trim(String text, int width, boolean inverse) {
        throw new UnsupportedOperationException();
    }
}
