package io.github.kimovoid.creative.mixin.server;

import io.github.kimovoid.creative.server.FCreativeServer;
import io.github.kimovoid.creative.interfaces.CreativePlayer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_68019318;
import net.minecraft.unmapped.C_74087615;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.SERVER)
@Mixin(C_68019318.class)
public class AlphaWorldStorageMixin {

    @Unique
    private boolean changeMode;

    @Inject(
            method = "loadPlayerData(Lnet/minecraft/entity/mob/player/PlayerEntity;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/storage/AlphaWorldStorage;loadPlayerData(Ljava/lang/String;)Lnet/minecraft/nbt/NbtCompound;",
                    shift = At.Shift.AFTER
            )
    )
    private void loadPlayer(C_40996800 player, CallbackInfo ci) {
        if (this.changeMode) {
            ((CreativePlayer)player).setCreative(FCreativeServer.creativeServer);
        }
    }

    @Inject(method = "loadPlayerData(Ljava/lang/String;)Lnet/minecraft/nbt/NbtCompound;", at = @At("RETURN"))
    private void getPlayerData(String playerName, CallbackInfoReturnable<C_74087615> cir) {
        this.changeMode = cir.getReturnValue() == null;
    }
}
