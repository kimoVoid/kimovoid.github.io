package io.github.kimovoid.creative.interfaces;

import io.github.kimovoid.creative.tab.CreativeModeTab;

public interface CreativeItem {
    void setCreativeTab(CreativeModeTab tab);
    CreativeModeTab getCreativeTab();
}
