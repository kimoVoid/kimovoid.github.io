package io.github.kimovoid.creative.mixin.client;

import io.github.kimovoid.creative.interfaces.CreativePlayer;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_34267874;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_34267874.class)
public class ClientPlayerInteractionManagerMixin {

	@Final @Shadow protected Minecraft minecraft;
	
	@Inject(method = "hasStatusBars", at = @At("HEAD"), cancellable = true)
	private void renderHud(CallbackInfoReturnable<Boolean> info) {
		info.setReturnValue(!((CreativePlayer)minecraft.f_28396371).isCreative());
	}
}
