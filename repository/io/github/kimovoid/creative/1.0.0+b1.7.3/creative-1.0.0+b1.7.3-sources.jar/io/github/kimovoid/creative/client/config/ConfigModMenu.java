package io.github.kimovoid.creative.client.config;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import io.github.kimovoid.creative.client.FCreativeClient;
import io.github.kimovoid.silk.SilkConfig;

public class ConfigModMenu implements ModMenuApi {

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> SilkConfig.getScreen(FCreativeClient.CONFIG, "general", parent);
    }
}
