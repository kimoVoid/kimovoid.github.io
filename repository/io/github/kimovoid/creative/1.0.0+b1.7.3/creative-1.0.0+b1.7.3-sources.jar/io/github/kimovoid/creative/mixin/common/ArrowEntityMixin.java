package io.github.kimovoid.creative.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.kimovoid.creative.interfaces.CreativeArrow;
import io.github.kimovoid.creative.interfaces.CreativePlayer;
import net.minecraft.unmapped.C_29057998;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_87542771;
import net.minecraft.unmapped.C_88708284;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_29057998.class)
public class ArrowEntityMixin implements CreativeArrow {

    @Unique public boolean pickup = true;

    @Inject(method = "onPlayerCollision", at = @At("HEAD"), cancellable = true)
    private void tryPickUp(C_40996800 player, CallbackInfo ci) {
        if (!this.pickup && !((CreativePlayer)player).isCreative()) {
            ci.cancel();
        }
    }

    @WrapOperation(
            method = "onPlayerCollision",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/mob/player/PlayerInventory;addItem(Lnet/minecraft/item/ItemStack;)Z"
            )
    )
    private boolean removeCreativePickup(C_87542771 instance, C_88708284 item, Operation<Boolean> original) {
        if (((CreativePlayer)instance.f_31714243).isCreative()) {
            return true;
        }
        return original.call(instance, item);
    }

    @Override
    public boolean canPickUp() {
        return this.pickup;
    }

    @Override
    public void allowPickUp(boolean b) {
        this.pickup = b;
    }
}
