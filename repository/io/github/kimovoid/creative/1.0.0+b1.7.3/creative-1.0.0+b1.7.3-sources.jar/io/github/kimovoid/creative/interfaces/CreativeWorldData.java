package io.github.kimovoid.creative.interfaces;

public interface CreativeWorldData {
	boolean isCreative();
	void setCreative(boolean creative);
}
