package io.github.kimovoid.creative.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.kimovoid.creative.client.FCreativeClient;
import io.github.kimovoid.creative.interfaces.CreativeMobEntity;
import io.github.kimovoid.creative.interfaces.CreativePlayer;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_74425583;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_40996800.class)
public abstract class PlayerEntityMixin extends C_74425583 implements CreativePlayer {

	@Unique public final int IS_CREATIVE_ID = 17;
	@Unique public final int ALLOW_FLYING_ID = 18;
	@Unique public final int IS_FLYING_ID = 19;

	public PlayerEntityMixin(C_64041439 arg) {
		super(arg);
	}

	@Inject(method = "takeDamage", at = @At("HEAD"), cancellable = true)
	private void takeDamage(C_42232651 source, int amount, CallbackInfoReturnable<Boolean> info) {
		if (this.isCreative()) {
			info.setReturnValue(false);
			info.cancel();
		}
	}
	
	@Inject(method = "applyDamage", at = @At("HEAD"), cancellable = true)
	private void applyDamage(int amount, CallbackInfo info) {
		if (this.isCreative()) {
			info.cancel();
		}
	}
	
	@Inject(method = "writeCustomNbt", at = @At("HEAD"))
	private void writeCustomDataToTag(C_74087615 nbt, CallbackInfo info) {
		nbt.m_20318863("GameType", isCreative() ? 1 : 0);
		nbt.m_11270099("Flying", isFlying());
	}

	@Inject(method = "readCustomNbt", at = @At("HEAD"))
	private void readCustomDataFromTag(C_74087615 nbt, CallbackInfo info) {
		setCreative(nbt.m_35587574("GameType") == 1);
		setFlying(nbt.m_25255788("Flying"));
	}
	
	@Inject(method = "tick", at = @At("TAIL"))
	private void tick(CallbackInfo info) {
		if (!this.allowFlying() && this.isFlying()) {
			this.setFlying(false);
		}

		if (!this.allowFlying()) return;
		if (!this.isFlying()) return;
		
		if (this.m_18110524() || this.f_03824457 != null) {
			this.setFlying(false);
		}
	}

	@Inject(
			method = "registerSyncedData",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/entity/mob/MobEntity;registerSyncedData()V",
					shift = Shift.AFTER
			)
	)
	private void syncData(CallbackInfo info) {
		this.f_88296653.m_94812360(IS_CREATIVE_ID, (byte) 0);
		this.f_88296653.m_94812360(ALLOW_FLYING_ID, (byte) 0);
		this.f_88296653.m_94812360(IS_FLYING_ID, (byte) 0);
	}

	@WrapOperation(
			method = "moveRelative",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/entity/mob/MobEntity;moveRelative(FF)V"
			)
	)
	private void moveRelative(C_40996800 instance, float sideways, float forwards, Operation<Void> original) {
		if (this.isFlying()) {
			double veloY = this.f_35148123;
			float speedAir = ((CreativeMobEntity)this).getSpeedInAir();

			float flySpeed = 0.05F;
			if (FabricLoader.getInstance().getEnvironmentType().equals(EnvType.CLIENT)) {
				flySpeed = FCreativeClient.getClientFlyBoost(flySpeed);
			}
			((CreativeMobEntity)this).setSpeedInAir(flySpeed);

			original.call(instance, sideways, forwards);
			this.f_35148123 = veloY * 0.6;
			((CreativeMobEntity)this).setSpeedInAir(speedAir);
		} else {
			original.call(instance, sideways, forwards);
		}
	}

	@Inject(method = "takeFallDamage", at = @At("HEAD"), cancellable = true)
	private void removeFallDamage(float distance, CallbackInfo ci) {
		if (this.allowFlying()) {
			ci.cancel();
		}
	}

	@Override
	public boolean isCreative() {
		return this.toBool(f_88296653.m_26990188(IS_CREATIVE_ID));
	}

	@Override
	public void setCreative(boolean creative) {
		this.setAllowFlying(creative);
		this.f_88296653.m_52395024(IS_CREATIVE_ID, this.toByte(creative));
	}

	@Override
	public boolean allowFlying() {
		return this.toBool(f_88296653.m_26990188(ALLOW_FLYING_ID));
	}

	@Override
	public void setAllowFlying(boolean allow) {
		this.f_88296653.m_52395024(ALLOW_FLYING_ID, this.toByte(allow));
	}

	@Override
	public boolean isFlying() {
		return this.toBool(this.f_88296653.m_26990188(IS_FLYING_ID));
	}

	@Override
	public void setFlying(boolean flying) {
		this.f_88296653.m_52395024(IS_FLYING_ID, this.toByte(flying));
	}

	@Unique
	public byte toByte(boolean value) {
		return (byte) (value ? 1 : 0);
	}

	@Unique
	public boolean toBool(byte value) {
		return value > 0;
	}
}
