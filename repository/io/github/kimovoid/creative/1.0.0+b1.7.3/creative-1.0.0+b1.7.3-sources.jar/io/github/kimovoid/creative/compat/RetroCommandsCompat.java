package io.github.kimovoid.creative.compat;

import com.periut.retrocommands.api.Command;

public class RetroCommandsCompat {

    public static void register(Command c) {
        com.periut.retrocommands.api.CommandRegistry.add(c);
    }
}
