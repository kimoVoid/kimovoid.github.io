package io.github.kimovoid.creative.mixin.client;

import io.github.kimovoid.creative.client.gui.CreativeInventoryScreen;
import io.github.kimovoid.creative.tab.CreativeModeTab;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_10918870;
import net.minecraft.unmapped.C_57778754;
import net.minecraft.unmapped.C_75191757;
import net.minecraft.unmapped.C_88014908;
import net.minecraft.unmapped.C_88708284;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(C_88014908.class)
public abstract class ClientNetworkHandlerMixin extends C_10918870 {

    @Shadow private Minecraft minecraft;

    @Override
    public void m_77507581(C_75191757 packet) {
        C_57778754 localClientPlayerEntity = this.minecraft.f_28396371;
        if (packet.f_02223463 == -1) {
            localClientPlayerEntity.f_29439708.m_74385138(packet.f_00352698);
        } else {
            int i = 0;
            if (this.minecraft.f_70816363 instanceof CreativeInventoryScreen) {
                CreativeInventoryScreen creativeInventoryScreen = (CreativeInventoryScreen)this.minecraft.f_70816363;
                i = creativeInventoryScreen.getSelectedTab() != CreativeModeTab.INVENTORY.getId() ? 1 : 0;
            }

            if (packet.f_02223463 == 0 && packet.f_20923223 >= 36 && packet.f_20923223 < 45) {
                C_88708284 itemStack = localClientPlayerEntity.f_67740326.m_89372629(packet.f_20923223).m_96527510();
                if (packet.f_00352698 != null && (itemStack == null || itemStack.f_60602012 < packet.f_00352698.f_60602012)) {
                    packet.f_00352698.f_40714509 = 5;
                }

                localClientPlayerEntity.f_67740326.m_39704747(packet.f_20923223, packet.f_00352698);
            } else if (packet.f_02223463 == localClientPlayerEntity.f_25936683.f_66294390 && (packet.f_02223463 != 0 || i == 0)) {
                localClientPlayerEntity.f_25936683.m_39704747(packet.f_20923223, packet.f_00352698);
            }
        }
    }
}
