package io.github.kimovoid.creative.client;

import io.github.kimovoid.creative.client.config.Config;
import io.github.kimovoid.creative.client.keybinding.KeyBindingHandler;
import io.github.kimovoid.creative.client.keybinding.MCKeyBindingHandler;
import net.fabricmc.loader.api.FabricLoader;
import net.ornithemc.osl.config.api.ConfigManager;
import net.ornithemc.osl.entrypoints.api.client.ClientModInitializer;
import net.ornithemc.osl.keybinds.api.KeybindEvents;
import net.ornithemc.osl.keybinds.api.KeybindRegistry;
import org.lwjgl.input.Keyboard;

public class FCreativeClient implements ClientModInitializer {

    public static KeyBindingHandler KEYBINDS;
    public static Config CONFIG;

    @Override
    public void initClient() {
        CONFIG = new Config();
        ConfigManager.register(CONFIG);

        KEYBINDS = new KeyBindingHandler();
        if (FabricLoader.getInstance().isModLoaded("moderncontrols")) {
            KEYBINDS = new MCKeyBindingHandler();
        }

        KeybindEvents.REGISTER_KEYBINDS.register(() -> {
            KeybindRegistry.register(KEYBINDS.getKeybinding("key.flyBoost", Keyboard.KEY_LMENU), "key.categories.gameplay");
        });
    }

    public static float getClientFlyBoost(float base) {
        if (Keyboard.isKeyDown(KEYBINDS.getKeyByName("key.flyBoost"))) {
            return base * CONFIG.flyBoost.get();
        }
        return base;
    }
}
