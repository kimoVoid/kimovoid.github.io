package io.github.kimovoid.creative.mixin.common;

import io.github.kimovoid.creative.interfaces.CreativePlayer;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_90901456;
import net.minecraft.unmapped.C_98888256;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_90901456.class)
public abstract class BucketItemMixin extends C_98888256 {

	public BucketItemMixin(int id) {
		super(id);
	}
	
	@Inject(method = "startUsing", at = @At("RETURN"), cancellable = true)
	private void useBucket(C_88708284 stack, C_64041439 world, C_40996800 player, CallbackInfoReturnable<C_88708284> cir) {
		if (!((CreativePlayer) player).isCreative()) return;
		stack.f_59294634 = this.f_57562535;
		cir.setReturnValue(stack);
	}
}
