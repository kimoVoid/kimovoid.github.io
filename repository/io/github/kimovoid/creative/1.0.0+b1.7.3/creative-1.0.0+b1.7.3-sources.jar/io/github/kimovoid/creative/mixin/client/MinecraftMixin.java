package io.github.kimovoid.creative.mixin.client;

import io.github.kimovoid.creative.FCreative;
import io.github.kimovoid.creative.interfaces.CreativePlayer;
import io.github.kimovoid.creative.networking.SlotUpdatePayload;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_24654288;
import net.minecraft.unmapped.C_57778754;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_87542771;
import net.minecraft.unmapped.C_88708284;
import net.ornithemc.osl.networking.api.client.ClientPlayNetworking;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class MinecraftMixin {

	@Shadow public C_24654288 crosshairTarget;
	@Shadow public C_64041439 world;
	@Shadow private int attackCooldown;
	@Shadow public C_57778754 player;

	@Inject(method = "handlePickBlock", at = @At("HEAD"), cancellable = true)
	private void setMouseButtonItem(CallbackInfo ci) {
		if (!((CreativePlayer)player).isCreative() || this.crosshairTarget == null) return;
		
		int blockId = world.m_33234383(this.crosshairTarget.f_79497105, this.crosshairTarget.f_09533029, this.crosshairTarget.f_04223298);
		int meta = world.m_06541281(this.crosshairTarget.f_79497105, this.crosshairTarget.f_09533029, this.crosshairTarget.f_04223298);
		C_88708284 stack = new C_88708284(blockId, 1, meta);
		
		C_87542771 inventory = this.player.f_29439708;

		ci.cancel();
		
		int selectedSlot = inventory.f_13682807;
		boolean selectEmpty = true;
		
		for (byte slot = 0; slot < 9; slot++) {
			C_88708284 itemInv = inventory.m_87969967(slot);
			if (itemInv == null) {
				if (selectEmpty) {
					selectedSlot = slot;
					selectEmpty = false;
				}
			}
			else if (itemInv.f_59294634 == stack.f_59294634 && itemInv.m_30227787() == stack.m_30227787()) {
				inventory.f_13682807 = slot;
				return;
			}
		}

		inventory.f_13682807 = selectedSlot;
		inventory.m_33431716(selectedSlot, stack);
		int slot = this.player.f_67740326.f_84566804.size() - 9 + inventory.f_13682807;
		ClientPlayNetworking.send(FCreative.SLOT_UPDATE_CHANNEL, new SlotUpdatePayload(slot, stack));
	}

	@Inject(method = "handleMouseClick", at = @At("HEAD"))
	private void removeCooldown(int button, CallbackInfo ci) {
		if (!((CreativePlayer)player).isCreative()) {
			return;
		}
		this.attackCooldown = 0;
	}
}
