package io.github.kimovoid.creative.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.kimovoid.creative.interfaces.CreativeWorldData;
import io.github.kimovoid.creative.interfaces.CreativeWorldSaveInfo;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_64676926;
import net.minecraft.unmapped.C_72342472;
import net.minecraft.unmapped.C_87007645;
import net.minecraft.unmapped.C_92964787;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.io.File;
import java.util.ArrayList;

@Environment(EnvType.CLIENT)
@Mixin(C_92964787.class)
public abstract class RegionWorldStorageSourceMixin extends C_72342472 {

    public RegionWorldStorageSourceMixin(File dir) {
        super(dir);
    }

    @WrapOperation(method = "getAll",
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/util/ArrayList;add(Ljava/lang/Object;)Z"
            )
    )
    public boolean addCreativeInfo(ArrayList<Object> list, Object e, Operation<Boolean> original) {
        C_87007645 info = (C_87007645) e;
        C_64676926 data = m_18055305(info.m_07607595());
        if (data != null && ((CreativeWorldData)data).isCreative()) {
            ((CreativeWorldSaveInfo)info).setCreative(true);
        }
        list.add(info);
        return false;
    }
}
