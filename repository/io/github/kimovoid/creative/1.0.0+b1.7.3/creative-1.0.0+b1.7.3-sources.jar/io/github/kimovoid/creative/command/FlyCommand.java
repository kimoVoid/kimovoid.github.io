package io.github.kimovoid.creative.command;

import com.periut.retrocommands.api.Command;
import com.periut.retrocommands.util.SharedCommandSource;
import io.github.kimovoid.creative.interfaces.CreativePlayer;

public class FlyCommand implements Command {

    @Override
    public void command(SharedCommandSource source, String[] args) {
        if (source.getPlayer() == null) {
            source.sendFeedback("Can only be used by a player.");
            return;
        }

        boolean flight = !((CreativePlayer)source.getPlayer()).allowFlying();
        ((CreativePlayer)source.getPlayer()).setAllowFlying(flight);

        source.sendFeedback("Flight " + (flight ? "enabled" : "disabled"));
    }

    @Override
    public String name() {
        return "fly";
    }

    @Override
    public void manual(SharedCommandSource commandSource) {
        commandSource.sendFeedback("Usage: /fly");
        commandSource.sendFeedback("Info: toggles flight on/off");
    }
}
