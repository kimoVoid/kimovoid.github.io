package io.github.kimovoid.creative.mixin.client.item;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_18719811;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_89604096;
import org.spongepowered.asm.mixin.Mixin;

@Environment(EnvType.CLIENT)
@Mixin(C_18719811.class)
public abstract class GrassBlockMixin extends C_81592558 {

    protected GrassBlockMixin(int id, C_89604096 material) {
        super(id, material);
    }

    @Override
    public int m_07414817(int face, int metadata) {
        switch (face) {
            case 0:
                return 2;
            case 1:
                return 0;
        }
        return 3;
    }
}
