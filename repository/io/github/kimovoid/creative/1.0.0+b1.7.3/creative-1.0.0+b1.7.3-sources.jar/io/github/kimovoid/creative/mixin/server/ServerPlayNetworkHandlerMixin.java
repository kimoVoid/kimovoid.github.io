package io.github.kimovoid.creative.mixin.server;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.kimovoid.creative.interfaces.CreativePlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_99660737;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(C_99660737.class)
public class ServerPlayNetworkHandlerMixin {

    @Shadow
    private C_49202226 player;

    @WrapOperation(
            method = "handlePlayerMove",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/server/MinecraftServer;flightEnabled:Z",
                    opcode = Opcodes.GETFIELD
            )
    )
    private boolean allowFlight(MinecraftServer instance, Operation<Boolean> original) {
        if (((CreativePlayer)this.player).allowFlying()) {
            return true;
        }
        return original.call(instance);
    }
}
