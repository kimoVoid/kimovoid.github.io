package io.github.kimovoid.creative.client.util;

import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import net.minecraft.unmapped.C_77279411;

public class TextFieldUtils {

    public static boolean isValidChatChar(char chr) {
        return chr != 167 && (C_77279411.f_42800273.indexOf(chr) >= 0 || chr > ' ');
    }

    public static String stripInvalidChars(String s) {
        StringBuilder stringBuilder = new StringBuilder();

        for (int k : s.toCharArray()) {
            if (isValidChatChar((char)k)) {
                stringBuilder.append((char)k);
            }
        }

        return stringBuilder.toString();
    }

    public static void setClipboard(String text) {
        try {
            StringSelection stringSelection = new StringSelection(text);
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
        } catch (Exception ignored) {
        }
    }

    public static boolean isControlDown() {
        return Keyboard.isKeyDown(Keyboard.KEY_LCONTROL)
                || Keyboard.isKeyDown(Keyboard.KEY_RCONTROL)
                || Keyboard.isKeyDown(Keyboard.KEY_LMETA)
                || Keyboard.isKeyDown(Keyboard.KEY_RMETA);
    }

    public static boolean isShiftDown() {
        return Keyboard.isKeyDown(Keyboard.KEY_LSHIFT) || Keyboard.isKeyDown(Keyboard.KEY_RSHIFT);
    }
}
