package io.github.kimovoid.creative.mixin.client;

import io.github.kimovoid.creative.client.FCreativeClient;
import io.github.kimovoid.creative.interfaces.CreativePlayer;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_54206210;
import net.minecraft.unmapped.C_57778754;
import net.minecraft.unmapped.C_64041439;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_57778754.class)
public abstract class ClientPlayerEntityMixin extends C_40996800 {

    @Shadow public C_54206210 input;

    public ClientPlayerEntityMixin(C_64041439 world) {
        super(world);
    }

    @Inject(
            method = "mobTick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/mob/player/PlayerEntity;mobTick()V"
            )
    )
    private void upwardsFlightMovement(CallbackInfo ci) {
        if (((CreativePlayer)this).isFlying()) {
            float baseSpeed = 0.15F;
            if (FabricLoader.getInstance().getEnvironmentType().equals(EnvType.CLIENT)) {
                baseSpeed = FCreativeClient.getClientFlyBoost(baseSpeed);
            }

            if (this.input.f_28813338) {
                this.f_35148123 -= baseSpeed;
            }

            if (this.input.f_92317429) {
                this.f_35148123 += baseSpeed;
            }
        }
    }

    @Inject(method = "mobTick", at = @At("TAIL"))
    private void disableFly(CallbackInfo ci) {
        if (this.f_47825615 && ((CreativePlayer)this).isFlying()) {
            ((CreativePlayer)this).setFlying(false);
        }
    }
}
