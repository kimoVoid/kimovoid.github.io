package io.github.kimovoid.creative.tab;

import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;

public class TabRegistry {

    public static final TabRegistry INSTANCE = new TabRegistry();

    public void registerVanillaItems() {
        // Blocks
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_38442324);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_41096518);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_05581995);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_17981199);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_32493286);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_35695348);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_27446762);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_38177074);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_91577743);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_19757556);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_81094226);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_78280144, 2);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_36441950);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_32420701);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_83073694);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_99851615);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_94949418);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_12629815, 16);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_54760749);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_41428926);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_66929948, 4);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_73573195);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_22197047);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_87667057);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_38591135);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_31892463);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_35664400);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_95737061);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_38259672);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_68803305);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_28421768);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_51102006);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_86394960);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_94091898);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_14995882);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_84892602);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_19295217);
        addItem(CreativeModeTab.BUILDING_BLOCKS, C_81592558.f_49218653);

        // Decoration
        addItem(CreativeModeTab.DECORATIONS, C_81592558.f_77878473, 3);
        addItem(CreativeModeTab.DECORATIONS, C_81592558.f_00276986, 3);
        addItem(CreativeModeTab.DECORATIONS, C_81592558.f_88550428);
        addOneItem(CreativeModeTab.DECORATIONS, C_81592558.f_83907852, 1);
        addOneItem(CreativeModeTab.DECORATIONS, C_81592558.f_83907852, 2);
        addItem(CreativeModeTab.DECORATIONS, C_81592558.f_99121891);
        addItem(CreativeModeTab.DECORATIONS, C_81592558.f_38977206);
        addItem(CreativeModeTab.DECORATIONS, C_81592558.f_72900486);
        addItem(CreativeModeTab.DECORATIONS, C_81592558.f_55254929);
        addItem(CreativeModeTab.DECORATIONS, C_81592558.f_30894038);
        addItem(CreativeModeTab.DECORATIONS, C_81592558.f_23542568);
        addItem(CreativeModeTab.DECORATIONS, C_81592558.f_49828421);
        addItem(CreativeModeTab.DECORATIONS, C_81592558.f_30918233);
        addItem(CreativeModeTab.DECORATIONS, C_81592558.f_19785413);
        addItem(CreativeModeTab.DECORATIONS, C_81592558.f_51448992);
        addItem(CreativeModeTab.DECORATIONS, C_81592558.f_81695559);
        addItem(CreativeModeTab.DECORATIONS, C_81592558.f_94556547);
        addItem(CreativeModeTab.DECORATIONS, C_81592558.f_25017736);
        addItem(CreativeModeTab.DECORATIONS, C_81592558.f_98928673);
        addItem(CreativeModeTab.DECORATIONS, C_98888256.f_27056679);
        addItem(CreativeModeTab.DECORATIONS, C_98888256.f_97502738);
        addItem(CreativeModeTab.DECORATIONS, C_98888256.f_08856223);

        // Redstone
        addItem(CreativeModeTab.REDSTONE, C_81592558.f_58920251);
        addItem(CreativeModeTab.REDSTONE, C_81592558.f_82599628);
        addItem(CreativeModeTab.REDSTONE, C_81592558.f_85558300);
        addItem(CreativeModeTab.REDSTONE, C_81592558.f_65735585);
        addItem(CreativeModeTab.REDSTONE, C_81592558.f_69656505);
        addItem(CreativeModeTab.REDSTONE, C_81592558.f_82613228);
        addItem(CreativeModeTab.REDSTONE, C_81592558.f_90267132);
        addItem(CreativeModeTab.REDSTONE, C_81592558.f_58356112);
        addItem(CreativeModeTab.REDSTONE, C_81592558.f_78503403);
        addItem(CreativeModeTab.REDSTONE, C_81592558.f_40727126);
        addItem(CreativeModeTab.REDSTONE, C_81592558.f_79966048);
        addItem(CreativeModeTab.REDSTONE, C_98888256.f_92303073);
        addItem(CreativeModeTab.REDSTONE, C_98888256.f_40777991);
        addItem(CreativeModeTab.REDSTONE, C_98888256.f_52656331);
        addItem(CreativeModeTab.REDSTONE, C_98888256.f_98054602);

        // Transportation
        addItem(CreativeModeTab.TRANSPORTATION, C_81592558.f_27559703);
        addItem(CreativeModeTab.TRANSPORTATION, C_81592558.f_89685822);
        addItem(CreativeModeTab.TRANSPORTATION, C_81592558.f_86544900);
        addItem(CreativeModeTab.TRANSPORTATION, C_98888256.f_72559846);
        addItem(CreativeModeTab.TRANSPORTATION, C_98888256.f_07293363);
        addItem(CreativeModeTab.TRANSPORTATION, C_98888256.f_67114151);
        addItem(CreativeModeTab.TRANSPORTATION, C_98888256.f_20481988);
        addItem(CreativeModeTab.TRANSPORTATION, C_98888256.f_49490949);

        // Miscellaneous
        addItem(CreativeModeTab.MISC, C_98888256.f_91599154);
        addItem(CreativeModeTab.MISC, C_98888256.f_94313583);
        addItem(CreativeModeTab.MISC, C_98888256.f_32467447);
        addItem(CreativeModeTab.MISC, C_98888256.f_10659101);
        addItem(CreativeModeTab.MISC, C_98888256.f_62954975);
        addItem(CreativeModeTab.MISC, C_98888256.f_90966147);
        addItem(CreativeModeTab.MISC, C_98888256.f_32576217);
        addItem(CreativeModeTab.MISC, C_98888256.f_46317332);
        addItem(CreativeModeTab.MISC, C_98888256.f_51993064);
        addItem(CreativeModeTab.MISC, C_98888256.f_69447318);
        addItem(CreativeModeTab.MISC, C_98888256.f_30116592);
        addItem(CreativeModeTab.MISC, C_98888256.f_33926157);

        // Food
        addItem(CreativeModeTab.FOOD, C_98888256.f_57144513);
        addItem(CreativeModeTab.FOOD, C_98888256.f_94828714);
        addItem(CreativeModeTab.FOOD, C_98888256.f_94155714);
        addItem(CreativeModeTab.FOOD, C_98888256.f_70512792);
        addItem(CreativeModeTab.FOOD, C_98888256.f_40838509);
        addItem(CreativeModeTab.FOOD, C_98888256.f_18291365);
        addItem(CreativeModeTab.FOOD, C_98888256.f_87025895);
        addItem(CreativeModeTab.FOOD, C_98888256.f_87709655);
        addItem(CreativeModeTab.FOOD, C_98888256.f_59726285);
        addItem(CreativeModeTab.FOOD, C_98888256.f_91086089);

        // Tools
        addItem(CreativeModeTab.TOOLS, C_98888256.f_80805461);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_98306436);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_89785708);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_96370468);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_38813183);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_50174679);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_27888996);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_18708761);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_88921834);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_02912756);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_04770191);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_43932574);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_45386391);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_50429169);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_68090982);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_08977302);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_03688690);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_98142733);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_57678723);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_35880850);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_31038121);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_53864758);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_57012528);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_10956141);
        addItem(CreativeModeTab.TOOLS, C_98888256.f_18374421);

        // Combat
        addItem(CreativeModeTab.COMBAT, C_98888256.f_59992682);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_67660833);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_32125146);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_96913276);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_13344738);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_29490209);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_56140732);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_92705060);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_60255230);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_78687479);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_65686175);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_20484061);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_92537726);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_24275834);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_67341244);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_84448376);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_56682976);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_64671240);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_96568531);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_00953201);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_54219088);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_42239243);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_21328201);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_06326883);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_58467061);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_20229887);
        addItem(CreativeModeTab.COMBAT, C_98888256.f_08730706);

        // Cursed
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_91830957);
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_12152349);
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_63585395);
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_42662644);
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_18320492);
        addOneItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_65735585, 6);
        addOneItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_65735585, 7);
        addOneItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_85558300, 6);
        addOneItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_85558300, 7);
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_83907852);
        addItem(CreativeModeTab.UNOBTAINABLE, 36);
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_39350323, 5);
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_48624188);
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_50662990);
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_08141062);
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_09380838);
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_95757196);
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_78357199);
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_30518711);
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_13293967);
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_19964067);
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_35874681);
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_98529173);
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_69293475);
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_77070700);
        addItem(CreativeModeTab.UNOBTAINABLE, C_81592558.f_02852022);

        // Materials
        addItem(CreativeModeTab.MATERIALS, C_98888256.f_58154723, 2);
        addItem(CreativeModeTab.MATERIALS, C_98888256.f_18976102);
        addItem(CreativeModeTab.MATERIALS, C_98888256.f_80480869);
        addItem(CreativeModeTab.MATERIALS, C_98888256.f_73771168);
        addItem(CreativeModeTab.MATERIALS, C_98888256.f_70868303);
        addItem(CreativeModeTab.MATERIALS, C_98888256.f_21498627);
        addItem(CreativeModeTab.MATERIALS, C_98888256.f_94759491);
        addItem(CreativeModeTab.MATERIALS, C_98888256.f_56704454);
        addItem(CreativeModeTab.MATERIALS, C_98888256.f_32150368);
        addItem(CreativeModeTab.MATERIALS, C_98888256.f_84974010);
        addItem(CreativeModeTab.MATERIALS, C_98888256.f_60617725);
        addItem(CreativeModeTab.MATERIALS, C_98888256.f_08935226);
        addItem(CreativeModeTab.MATERIALS, C_98888256.f_08971169);
        addItem(CreativeModeTab.MATERIALS, C_98888256.f_21279732);
        addItem(CreativeModeTab.MATERIALS, C_98888256.f_39465979);
        addItem(CreativeModeTab.MATERIALS, C_98888256.f_55275152);
        addItem(CreativeModeTab.MATERIALS, C_98888256.f_03970011);
        addItem(CreativeModeTab.MATERIALS, C_98888256.f_88723374);
        addItem(CreativeModeTab.MATERIALS, C_98888256.f_09260276, 16);
        addItem(CreativeModeTab.MATERIALS, C_98888256.f_79588801);
    }

    public void addItem(CreativeModeTab tab, Object item) {
        if (item instanceof C_81592558) {
            tab.register(new C_88708284((C_81592558) item));
        }
        if (item instanceof C_98888256) {
            tab.register(new C_88708284((C_98888256) item));
        }
    }

    public void addItem(CreativeModeTab tab, Object item, int meta) {
        for (byte i = 0; i < meta; i++) {
            if (item instanceof C_81592558) {
                tab.register(new C_88708284((C_81592558) item, 1, i));
            }
            if (item instanceof C_98888256) {
                tab.register(new C_88708284((C_98888256) item, 1, i));
            }
        }
    }

    public void addOneItem(CreativeModeTab tab, Object item, int meta) {
        if (item instanceof C_81592558) {
            tab.register(new C_88708284((C_81592558) item, 1, meta));
        }
        if (item instanceof C_98888256) {
            tab.register(new C_88708284((C_98888256) item, 1, meta));
        }
    }
}
