package io.github.kimovoid.creative.mixin.common;

import io.github.kimovoid.creative.interfaces.CreativePlayer;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_42232651.class)
public class EntityMixin {

    @Shadow public float walkDistance;
    @Shadow private int blocksWalkedOn;

    @Inject(method = "move", at = @At(
            value = "FIELD",
            target = "Lnet/minecraft/entity/Entity;walkDistance:F",
            shift = At.Shift.AFTER,
            ordinal = 1
    ))
    private void assign(double dx, double dy, double dz, CallbackInfo info) {
        C_42232651 entity = C_42232651.class.cast(this);
        if (!(entity instanceof C_40996800)) return;
        C_40996800 pl = (C_40996800) entity;
        if (!((CreativePlayer)pl).isFlying()) return;
        this.blocksWalkedOn = (int) (this.walkDistance + 2);
    }
}
