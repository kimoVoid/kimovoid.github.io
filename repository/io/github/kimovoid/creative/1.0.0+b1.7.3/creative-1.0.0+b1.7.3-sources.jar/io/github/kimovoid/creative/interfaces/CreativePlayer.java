package io.github.kimovoid.creative.interfaces;

public interface CreativePlayer {

	boolean isCreative();
	void setCreative(boolean creative);
	
	boolean isFlying();
	void setFlying(boolean flying);

	boolean allowFlying();
	void setAllowFlying(boolean flying);
}
