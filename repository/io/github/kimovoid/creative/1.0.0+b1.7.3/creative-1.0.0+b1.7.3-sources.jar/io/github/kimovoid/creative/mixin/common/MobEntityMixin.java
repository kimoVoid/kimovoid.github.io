package io.github.kimovoid.creative.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.kimovoid.creative.interfaces.CreativeMobEntity;
import io.github.kimovoid.creative.interfaces.CreativePlayer;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_74425583;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(C_74425583.class)
public abstract class MobEntityMixin extends C_42232651 implements CreativeMobEntity {

    @Unique public float speedInAir = 0.02F;

    public MobEntityMixin(C_64041439 world) {
        super(world);
    }

    @ModifyConstant(method = "moveRelative", constant = @Constant(floatValue = 0.02F, ordinal = 2))
    private float setAirSpeed(float constant) {
        return this.speedInAir;
    }

    @WrapOperation(method = "moveRelative", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/mob/MobEntity;isInWater()Z"))
    private boolean removeWaterSlowdown(C_74425583 instance, Operation<Boolean> original) {
        if (((C_74425583) (Object) this) instanceof C_40996800 && ((CreativePlayer)this).isFlying()) {
            return false;
        }
        return original.call(instance);
    }

    @WrapOperation(method = "moveRelative", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/mob/MobEntity;isInLava()Z"))
    private boolean removeLavaSlowdown(C_74425583 instance, Operation<Boolean> original) {
        if (((C_74425583) (Object) this) instanceof C_40996800 && ((CreativePlayer)this).isFlying()) {
            return false;
        }
        return original.call(instance);
    }

    @Override
    public float getSpeedInAir() {
        return this.speedInAir;
    }

    @Override
    public void setSpeedInAir(float f) {
        this.speedInAir = f;
    }
}
