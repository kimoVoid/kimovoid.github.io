package io.github.kimovoid.creative.client.item;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_71827890;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_82336779;
import net.minecraft.unmapped.C_88708284;

public class PlantBlockItem extends C_71827890 {

    private final C_81592558 plant = C_81592558.f_44428008[this.f_03056041];
    private String[] names;

    public PlantBlockItem(int id, boolean stackable) {
        super(id);
        if (stackable) {
            this.m_83617391(0);
            this.m_56494446(true);
        }
    }

    @Environment(EnvType.CLIENT)
    public int m_73217034(int metadata) {
        return C_82336779.m_42257471();
    }

    @Environment(EnvType.CLIENT)
    @Override
    public int m_27460772(int metadata) {
        return this.plant.m_07414817(0, metadata);
    }

    @Override
    public int m_65403122(int metadata) {
        return metadata;
    }

    public PlantBlockItem setNames(String[] names) {
        this.names = names;
        return this;
    }

    @Override
    public String m_81802680(C_88708284 stack) {
        if (this.names == null) {
            return super.m_81802680(stack);
        }

        int i = stack.m_21098843();
        return i >= 0 && i < this.names.length ? super.m_81802680(stack) + "." + this.names[i] : super.m_81802680(stack);
    }
}
