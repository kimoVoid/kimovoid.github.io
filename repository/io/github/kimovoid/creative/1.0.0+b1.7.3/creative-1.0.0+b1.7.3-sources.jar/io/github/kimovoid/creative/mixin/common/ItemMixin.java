package io.github.kimovoid.creative.mixin.common;

import io.github.kimovoid.creative.interfaces.CreativeItem;
import io.github.kimovoid.creative.tab.CreativeModeTab;
import net.minecraft.unmapped.C_98888256;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_98888256.class)
public class ItemMixin implements CreativeItem {

    @Unique private CreativeModeTab tab;

    @Override
    public void setCreativeTab(CreativeModeTab tab) {
        this.tab = tab;
    }

    @Override
    public CreativeModeTab getCreativeTab() {
        return this.tab;
    }
}
