package io.github.kimovoid.creative.mixin.client;

import io.github.kimovoid.creative.FCreative;
import io.github.kimovoid.creative.interfaces.CreativePlayer;
import io.github.kimovoid.creative.networking.SlotUpdatePayload;
import net.minecraft.unmapped.C_12356698;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_87542771;
import net.minecraft.unmapped.C_87711245;
import net.minecraft.unmapped.C_88708284;
import net.ornithemc.osl.networking.api.client.ClientPlayNetworking;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_87711245.class)
public abstract class InventoryMenuScreenMixin extends C_85740840 {

    @Shadow public abstract C_12356698 getSlot(int x, int y);

    @Inject(
            method = "mouseClicked",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/screen/Screen;mouseClicked(III)V"
            ),
            cancellable = true
    )
    private void creativeMiddleClick(int mouseX, int mouseY, int button, CallbackInfo ci) {
        if (!((CreativePlayer)this.f_78495264.f_28396371).isCreative() || button != 2) {
            return;
        }

        C_12356698 clickedSlot = this.getSlot(mouseX, mouseY);
        if (clickedSlot == null) {
            return;
        }

        C_87542771 playerInventory = this.f_78495264.f_28396371.f_29439708;
        C_88708284 cursorItem = playerInventory.m_54140007();
        C_88708284 slotItem = clickedSlot.m_96527510();

        if (slotItem != null && (cursorItem == null || cursorItem.m_52048659(slotItem))) {
            playerInventory.m_74385138(slotItem.m_73216943());
            cursorItem = playerInventory.m_54140007();
            cursorItem.f_60602012 = cursorItem.m_02549920();
            ClientPlayNetworking.send(FCreative.SLOT_UPDATE_CHANNEL, new SlotUpdatePayload(-2, cursorItem));
            ci.cancel();
        }
    }
}
