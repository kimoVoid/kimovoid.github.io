package io.github.kimovoid.creative.mixin.common;

import io.github.kimovoid.creative.interfaces.CreativePlayer;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(targets = {
		"net.minecraft.entity.mob.monster.MonsterEntity",
		"net.minecraft.entity.mob.monster.SpiderEntity"
})
public class MonsterEntityMixin {

	@Inject(method = "findTarget", at = @At("RETURN"), cancellable = true)
	private void noTarget(CallbackInfoReturnable<C_42232651> cir) {
		C_42232651 entity = cir.getReturnValue();
		if (entity instanceof C_40996800 && ((CreativePlayer) entity).isCreative()) {
            cir.setReturnValue(null);
        }
	}
}
