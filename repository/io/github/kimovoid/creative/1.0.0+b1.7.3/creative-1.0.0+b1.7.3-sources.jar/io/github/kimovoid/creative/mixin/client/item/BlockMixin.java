package io.github.kimovoid.creative.mixin.client.item;

import io.github.kimovoid.creative.client.item.PlantBlockItem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_98888256;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(C_81592558.class)
public class BlockMixin {

    @Inject(method = "<clinit>", at = @At("TAIL"))
    private static void registerItems(CallbackInfo ci) {
        C_98888256.f_38445253[C_81592558.f_83907852.f_84602679] = new PlantBlockItem(C_81592558.f_83907852.f_84602679 - 256, true).setNames(new String[]{"shrub", "grass", "fern"});
    }
}
