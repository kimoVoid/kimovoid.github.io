package io.github.kimovoid.creative.mixin.client;

import io.github.kimovoid.creative.interfaces.CreativeWorldSaveInfo;
import net.minecraft.unmapped.C_87007645;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_87007645.class)
public class WorldSaveInfoMixin implements CreativeWorldSaveInfo {

	@Unique private boolean isCreative;

	@Override
	public boolean isCreative() {
		return isCreative;
	}
	
	@Override
	public void setCreative(boolean creative) {
		isCreative = creative;
	}
}
