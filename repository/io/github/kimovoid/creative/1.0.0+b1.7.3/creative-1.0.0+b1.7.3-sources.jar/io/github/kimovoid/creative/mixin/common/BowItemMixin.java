package io.github.kimovoid.creative.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.kimovoid.creative.interfaces.CreativeArrow;
import io.github.kimovoid.creative.interfaces.CreativePlayer;
import net.minecraft.unmapped.C_29057998;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_76154632;
import net.minecraft.unmapped.C_87542771;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(C_76154632.class)
public class BowItemMixin {

    @WrapOperation(
            method = "startUsing",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/mob/player/PlayerInventory;removeOne(I)Z"
            )
    )
    private boolean alwaysShootArrow(C_87542771 instance, int item, Operation<Boolean> original) {
        if (((CreativePlayer)instance.f_31714243).isCreative()) {
            return true;
        }
        return original.call(instance, item);
    }

    @WrapOperation(
            method = "startUsing",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/World;addEntity(Lnet/minecraft/entity/Entity;)Z"
            )
    )
    private boolean creativeArrows(C_64041439 instance, C_42232651 entity, Operation<Boolean> original, @Local(argsOnly = true) C_40996800 player) {
        if (((CreativePlayer)player).isCreative()) {
            C_29057998 arrow = (C_29057998) entity;
            ((CreativeArrow)arrow).allowPickUp(false);
        }
        return original.call(instance, entity);
    }
}
