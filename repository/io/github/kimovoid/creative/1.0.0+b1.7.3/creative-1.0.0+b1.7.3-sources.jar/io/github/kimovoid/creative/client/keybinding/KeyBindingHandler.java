package io.github.kimovoid.creative.client.keybinding;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_23708450;

public class KeyBindingHandler {

    /* Dummy method for Modern Controls support */
    public int getKeyFromCode(int code) {
        return code;
    }

    /* Returns -1 if key wasn't found */
    public int getKeyByName(String name) {
        int code = -1;
        for (C_23708450 key : Minecraft.f_33079084.f_58088711.f_41636781) {
            if (key.f_54130288.equals(name)) code = key.f_57264828;
        }
        return code;
    }

    public C_23708450 getKeybinding(String name, int keyCode) {
        return new C_23708450(name, keyCode);
    }
}
