package io.github.kimovoid.creative.mixin.client;

import io.github.kimovoid.creative.client.gui.CreativeInventoryScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_45175654;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(C_45175654.class)
public class MultiplayerInteractionManagerMixin {

    @ModifyArg(
            method = "clickSlot",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/network/packet/InventoryMenuClickSlotPacket;<init>(IIIZLnet/minecraft/item/ItemStack;S)V"
            ),
            index = 1
    )
    private int setSlot(int slot) {
        if (Minecraft.f_33079084.f_70816363 instanceof CreativeInventoryScreen && slot > 44) {
            // this makes inventory transactions compatible with mods like
            // inventory tweaks and hopefully any other mods that do
            // something similar
            return slot - 9;
        }
        return slot;
    }
}
