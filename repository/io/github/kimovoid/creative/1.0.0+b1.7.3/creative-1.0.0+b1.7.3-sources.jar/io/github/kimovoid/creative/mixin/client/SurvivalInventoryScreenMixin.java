package io.github.kimovoid.creative.mixin.client;

import io.github.kimovoid.creative.client.gui.CreativeInventoryScreen;
import io.github.kimovoid.creative.interfaces.CreativePlayer;
import net.minecraft.unmapped.C_46053237;
import net.minecraft.unmapped.C_85589673;
import net.minecraft.unmapped.C_87711245;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_85589673.class)
public abstract class SurvivalInventoryScreenMixin extends C_87711245 {

    public SurvivalInventoryScreenMixin(C_46053237 menu) {
        super(menu);
    }

    @Override
    public void m_53520780() {
        if (((CreativePlayer)f_78495264.f_28396371).isCreative()) {
            f_78495264.m_52715402(new CreativeInventoryScreen(f_78495264.f_28396371));
        }
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void onInit(CallbackInfo ci) {
        if (((CreativePlayer)f_78495264.f_28396371).isCreative()) {
            f_78495264.m_52715402(new CreativeInventoryScreen(f_78495264.f_28396371));
        }
    }
}
