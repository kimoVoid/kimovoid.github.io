package io.github.kimovoid.creative.client.keybinding;

import io.github.kimovoid.moderncontrols.ModernControls;
import net.minecraft.unmapped.C_23708450;

public class MCKeyBindingHandler extends KeyBindingHandler {

    @Override
    public int getKeyFromCode(int code) {
        return ModernControls.getKeyCodeByOriginal(code);
    }

    @Override
    public C_23708450 getKeybinding(String name, int keyCode) {
        return ModernControls.getCustomKey(name, keyCode, true);
    }
}
