package io.github.kimovoid.creative.networking;

import net.minecraft.unmapped.C_88708284;
import net.ornithemc.osl.networking.api.PacketBuffer;
import net.ornithemc.osl.networking.api.PacketPayload;

public class SlotUpdatePayload implements PacketPayload {

    public int slot;
    public C_88708284 stack;

    public SlotUpdatePayload() {
    }

    public SlotUpdatePayload(int slot, C_88708284 stack) {
        this.slot = slot;
        this.stack = stack;
    }

    @Override
    public void read(PacketBuffer buffer) {
        stack = null;
        slot = buffer.readShort();
        int count = Byte.toUnsignedInt(buffer.readByte());
        if (count > 0) {
            int id = buffer.readInt();
            int damage = buffer.readInt();
            stack = new C_88708284(id, count, damage);
        }
    }

    @Override
    public void write(PacketBuffer buffer) {
        buffer.writeShort((short) slot);
        if (stack == null) {
            buffer.writeByte(0);
            return;
        }
        buffer.writeByte((byte) stack.f_60602012);
        if (stack.f_60602012 > 0) {
            buffer.writeInt(stack.f_59294634);
            buffer.writeInt(stack.m_30227787());
        }
    }
}
