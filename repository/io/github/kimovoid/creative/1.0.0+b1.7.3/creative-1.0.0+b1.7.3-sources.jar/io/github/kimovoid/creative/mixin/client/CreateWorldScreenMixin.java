package io.github.kimovoid.creative.mixin.client;

import io.github.kimovoid.creative.interfaces.CreativePlayer;
import net.minecraft.unmapped.C_16154270;
import net.minecraft.unmapped.C_85125467;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_90716798;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_90716798.class)
public abstract class CreateWorldScreenMixin extends C_85740840 {

	@Unique private static final String CREATIVE_KEY_SURVIVAL = "title.selectWorld.survival";
	@Unique private static final String CREATIVE_KEY_CREATIVE = "title.selectWorld.creative";
	@Unique private boolean creative = false;

	@Inject(method = "init", at = @At("TAIL"))
	private void addButtons(CallbackInfo info) {
		C_85125467 cancelButton = this.f_78519977.get(1);
		this.f_78519977.add(1, new C_85125467(2, this.f_05230747 / 2 - 100, cancelButton.f_24716782, getButtonName()));
		cancelButton.f_24716782 = this.f_07021018 / 4 + 144 + 12;
	}
	
	@Inject(method = "buttonClicked", at = @At("TAIL"))
	protected void buttonClicked(C_85125467 button, CallbackInfo info) {
		if (button.f_92999450 == 2) {
			creative = !creative;
			button.f_35112386 = getButtonName();
		}
		else if (button.f_92999450 == 0) {
			if (f_78495264.f_28396371 != null) {
				((CreativePlayer)f_78495264.f_28396371).setCreative(creative);
			}
		}
	}
	
	@Unique
	private String getButtonName() {
		C_16154270 storage = C_16154270.m_56062593();
		return storage.m_77288988(creative ? CREATIVE_KEY_CREATIVE : CREATIVE_KEY_SURVIVAL);
	}
}
