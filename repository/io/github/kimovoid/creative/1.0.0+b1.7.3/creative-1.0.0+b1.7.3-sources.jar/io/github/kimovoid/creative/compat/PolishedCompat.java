package io.github.kimovoid.creative.compat;

import io.github.kimovoid.polished.client.PolishedClient;
import io.github.kimovoid.polished.client.feature.inventorytweaks.InventoryTweaks;
import net.minecraft.unmapped.C_87711245;

public class PolishedCompat {

    public static void setInventoryTweaks(C_87711245 screen, boolean b) {
        ((InventoryTweaks)screen).inventoryTweaks_enableTweaks(b);
    }

    public static boolean hasInventoryTweaks() {
        return PolishedClient.CONFIG.enableInventoryTweaks.get();
    }

    public static boolean hasHotkeySwap() {
        return hasInventoryTweaks() && PolishedClient.CONFIG.hotkeySwap.get();
    }

    public static boolean hasDropKey() {
        return hasInventoryTweaks() && PolishedClient.CONFIG.dropKeyInv.get();
    }

    public static boolean hasCtrlDropStack() {
        return hasInventoryTweaks() && PolishedClient.CONFIG.ctrlDropStack.get();
    }
}
