package io.github.kimovoid.creative.mixin.client;

import io.github.kimovoid.creative.client.util.ITextRenderer;
import net.minecraft.unmapped.C_23014920;
import net.minecraft.unmapped.C_77279411;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@SuppressWarnings("AddedMixinMembersNamePattern")
@Mixin(C_23014920.class)
public abstract class TextRendererMixin implements ITextRenderer {

    @Shadow private int[] characterWidths;

    @Override
    public int getWidth(char chr) {
        if (chr == '§') {
            return -1;
        }
        int index = C_77279411.f_42800273.indexOf(chr);
        if (index >= 0) {
            return this.characterWidths[index + 32];
        }
        return 0;
    }

    @Override
    public String trim(String text, int width) {
        return this.trim(text, width, false);
    }

    @Override
    public String trim(String text, int width, boolean inverse) {
        StringBuilder sb = new StringBuilder();
        int n = 0;
        int n2 = inverse ? text.length() - 1 : 0;
        int n3 = inverse ? -1 : 1;
        boolean bl = false;
        boolean bl2 = false;
        for (int i = n2; i >= 0 && i < text.length() && n < width; i += n3) {
            char c = text.charAt(i);
            int n4 = this.getWidth(c);
            if (bl) {
                bl = false;
                if (c == 'l' || c == 'L') {
                    bl2 = true;
                } else if (c == 'r' || c == 'R') {
                    bl2 = false;
                }
            } else if (n4 < 0) {
                bl = true;
            } else {
                n += n4;
                if (bl2) {
                    ++n;
                }
            }
            if (n > width)
                break;
            if (inverse) {
                sb.insert(0, c);
                continue;
            }
            sb.append(c);
        }
        return sb.toString();
    }
}
