package io.github.kimovoid.creative;

import io.github.kimovoid.creative.compat.RetroCommandsCompat;
import io.github.kimovoid.creative.command.FlyCommand;
import io.github.kimovoid.creative.command.GamemodeCommand;
import io.github.kimovoid.creative.tab.TabRegistry;
import net.fabricmc.loader.api.FabricLoader;
import net.ornithemc.osl.core.api.util.NamespacedIdentifier;
import net.ornithemc.osl.networking.api.ChannelIdentifiers;
import net.ornithemc.osl.networking.api.ChannelRegistry;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import net.ornithemc.osl.entrypoints.api.ModInitializer;

public class FCreative implements ModInitializer {

	public static final Logger LOGGER = LogManager.getLogger("FCreative");
	public static final NamespacedIdentifier FLIGHT_CHANNEL =
			ChannelRegistry.register(ChannelIdentifiers.from("creative", "flying"), false, true);
	public static final NamespacedIdentifier SLOT_UPDATE_CHANNEL =
			ChannelRegistry.register(ChannelIdentifiers.from("creative", "update_slot"), false, true);

	@Override
	public void init() {
		TabRegistry.INSTANCE.registerVanillaItems();
		if (FabricLoader.getInstance().isModLoaded("retrocommands")) {
			RetroCommandsCompat.register(new GamemodeCommand());
			RetroCommandsCompat.register(new FlyCommand());
		}
	}
}
