package io.github.kimovoid.creative.tab;

import java.util.ArrayList;
import java.util.List;

import io.github.kimovoid.creative.interfaces.CreativeItem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_16154270;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;

public class CreativeModeTab {

    public static final CreativeModeTab[] ALL = new CreativeModeTab[12];

    public static final CreativeModeTab BUILDING_BLOCKS = new CreativeModeTab(0, "buildingBlocks") {
        @Environment(EnvType.CLIENT)
        @Override
        public int getIconItem() {
            return C_81592558.f_73573195.f_84602679;
        }
    };

    public static final CreativeModeTab DECORATIONS = new CreativeModeTab(1, "decorations") {
        @Environment(EnvType.CLIENT)
        @Override
        public int getIconItem() {
            return C_81592558.f_72900486.f_84602679;
        }
    };

    public static final CreativeModeTab REDSTONE = new CreativeModeTab(2, "redstone") {
        @Environment(EnvType.CLIENT)
        @Override
        public int getIconItem() {
            return C_98888256.f_52656331.f_57562535;
        }
    };

    public static final CreativeModeTab TRANSPORTATION = new CreativeModeTab(3, "transportation") {
        @Environment(EnvType.CLIENT)
        @Override
        public int getIconItem() {
            return C_81592558.f_27559703.f_84602679;
        }
    };

    public static final CreativeModeTab MISC = new CreativeModeTab(4, "misc") {
        @Environment(EnvType.CLIENT)
        @Override
        public int getIconItem() {
            return C_98888256.f_32467447.f_57562535;
        }
    };

    public static final CreativeModeTab SEARCH = (new CreativeModeTab(5, "search") {
        @Environment(EnvType.CLIENT)
        @Override
        public int getIconItem() {
            return C_98888256.f_53864758.f_57562535;
        }
    }).setTexture("tab_item_search.png");

    public static final CreativeModeTab FOOD = new CreativeModeTab(6, "food") {
        @Environment(EnvType.CLIENT)
        @Override
        public int getIconItem() {
            return C_98888256.f_57144513.f_57562535;
        }
    };

    public static final CreativeModeTab TOOLS = new CreativeModeTab(7, "tools") {
        @Environment(EnvType.CLIENT)
        @Override
        public int getIconItem() {
            return C_98888256.f_89785708.f_57562535;
        }
    };

    public static final CreativeModeTab COMBAT = new CreativeModeTab(8, "combat") {
        @Environment(EnvType.CLIENT)
        @Override
        public int getIconItem() {
            return C_98888256.f_56140732.f_57562535;
        }
    };

    public static final CreativeModeTab UNOBTAINABLE = new CreativeModeTab(9, "unobtainable") {
        @Environment(EnvType.CLIENT)
        @Override
        public int getIconItem() {
            return C_81592558.f_18320492.f_84602679;
        }
    };

    public static final CreativeModeTab MATERIALS = new CreativeModeTab(10, "materials") {
        @Environment(EnvType.CLIENT)
        @Override
        public int getIconItem() {
            return C_98888256.f_70868303.f_57562535;
        }
    };

    public static final CreativeModeTab INVENTORY = (new CreativeModeTab(11, "inventory") {
        @Environment(EnvType.CLIENT)
        @Override
        public int getIconItem() {
            return C_81592558.f_49828421.f_84602679;
        }
    }).setTexture("tab_inventory.png").hideScrollbar().hideTooltips();

    private final int id;
    private final String name;
    private String texture = "tab_items.png";
    private boolean scrollbar = true;
    private boolean tooltips = true;
    private final List<C_88708284> items = new ArrayList<>();

    public CreativeModeTab(int id, String name) {
        this.id = id;
        this.name = name;
        ALL[id] = this;
    }

    @Environment(EnvType.CLIENT)
    public int getId() {
        return this.id;
    }

    @Environment(EnvType.CLIENT)
    public String getName() {
        return this.name;
    }

    @Environment(EnvType.CLIENT)
    public String getDisplayName() {
        return C_16154270.m_56062593().m_77288988("itemGroup." + this.getName());
    }

    @Environment(EnvType.CLIENT)
    public C_98888256 getIcon() {
        return C_98888256.f_38445253[this.getIconItem()];
    }

    @Environment(EnvType.CLIENT)
    public int getIconItem() {
        return 1;
    }

    @Environment(EnvType.CLIENT)
    public String getTexture() {
        return this.texture;
    }

    public CreativeModeTab setTexture(String texture) {
        this.texture = texture;
        return this;
    }

    @Environment(EnvType.CLIENT)
    public boolean hasTooltips() {
        return this.tooltips;
    }

    public CreativeModeTab hideTooltips() {
        this.tooltips = false;
        return this;
    }

    public void register(C_88708284 stack) {
        ((CreativeItem)stack.m_23235460()).setCreativeTab(this);
        this.items.add(stack);
    }

    public List<C_88708284> getItems() {
        return this.items;
    }

    @Environment(EnvType.CLIENT)
    public boolean hasScrollbar() {
        return this.scrollbar;
    }

    public CreativeModeTab hideScrollbar() {
        this.scrollbar = false;
        return this;
    }

    @Environment(EnvType.CLIENT)
    public int getColumn() {
        return this.id % 6;
    }

    @Environment(EnvType.CLIENT)
    public boolean isTopRow() {
        return this.id < 6;
    }

    @Environment(EnvType.CLIENT)
    public void addItems(List<C_88708284> inventory) {
        inventory.addAll(this.items);
    }
}
