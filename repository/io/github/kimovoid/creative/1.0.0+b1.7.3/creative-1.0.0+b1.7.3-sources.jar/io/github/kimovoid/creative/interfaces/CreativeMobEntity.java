package io.github.kimovoid.creative.interfaces;

public interface CreativeMobEntity {
    float getSpeedInAir();
    void setSpeedInAir(float f);
}
