package io.github.kimovoid.creative.server;

import io.github.kimovoid.creative.FCreative;
import io.github.kimovoid.creative.interfaces.CreativePlayer;
import io.github.kimovoid.creative.networking.FlightPayload;
import io.github.kimovoid.creative.networking.SlotUpdatePayload;
import net.minecraft.unmapped.C_87542771;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.ornithemc.osl.entrypoints.api.server.ServerModInitializer;
import net.ornithemc.osl.networking.api.server.ServerPlayNetworking;

public class FCreativeServer implements ServerModInitializer {

    public static boolean creativeServer;

    @Override
    public void initServer() {
        ServerPlayNetworking.registerListener(FCreative.FLIGHT_CHANNEL, FlightPayload::new, (context, payload) -> {
            ((CreativePlayer) context.player()).setFlying(payload.flying);
        });

        ServerPlayNetworking.registerListener(FCreative.SLOT_UPDATE_CHANNEL, SlotUpdatePayload::new, (context, payload) -> {
            C_88708284 itemStack = payload.stack;
            boolean hasSlot = payload.slot >= 1 && payload.slot < 36 + C_87542771.m_54256725();
            boolean invalidItem = itemStack != null && (itemStack.f_59294634 >= C_98888256.f_38445253.length || itemStack.f_59294634 < 0 || C_98888256.f_38445253[itemStack.f_59294634] == null);
            boolean invalidMeta = itemStack != null && (itemStack.m_21098843() < 0 || itemStack.f_60602012 > 64 || itemStack.f_60602012 <= 0);
            if (invalidItem || invalidMeta) {
                return;
            }

            switch (payload.slot) {
                case -2: { // cursor
                    context.player().f_29439708.m_74385138(itemStack);
                    break;
                }
                case -1: { // drop cursor item
                    context.player().m_78441799(itemStack);
                    break;
                }
                default: {
                    if (hasSlot) {
                        context.player().f_67740326.m_89372629(payload.slot).m_06487241(itemStack);
                        context.player().f_67740326.m_69398743(context.player(), true);
                    }
                }
            }

            /*
            if (payload.stack == null) {
                return;
            }

            Creative.LOGGER.info("set {}'s slot {} to item {}:{}",
                    context.player().name,
                    payload.slot,
                    payload.stack.id,
                    payload.stack.getDamage()
            );
             */
        });
    }
}
