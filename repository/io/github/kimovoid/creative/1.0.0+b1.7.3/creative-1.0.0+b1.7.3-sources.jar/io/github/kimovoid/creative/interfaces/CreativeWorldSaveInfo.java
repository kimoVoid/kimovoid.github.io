package io.github.kimovoid.creative.interfaces;

public interface CreativeWorldSaveInfo {
    boolean isCreative();
    void setCreative(boolean creative);
}
