package io.github.kimovoid.creative.mixin.client;

import io.github.kimovoid.creative.FCreative;
import io.github.kimovoid.creative.interfaces.CreativePlayer;
import io.github.kimovoid.creative.networking.FlightPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_08381405;
import net.ornithemc.osl.networking.api.client.ClientPlayNetworking;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_08381405.class)
public class KeyboardInputMixin {

    @Unique private long timeout;
    @Unique private long count;

    @Inject(method = "handleKeyEvent", at = @At("HEAD"))
    public void onKeyPress(int key, boolean state, CallbackInfo info) {
        if (key != Minecraft.f_33079084.f_58088711.f_94470987.f_57264828) return;
        if (!((CreativePlayer) Minecraft.f_33079084.f_28396371).allowFlying()) return;

        if (state) {
            long time = System.currentTimeMillis();
            timeout = time - timeout;
            if (count > 0 && timeout < 250) {
                boolean flying = !((CreativePlayer) Minecraft.f_33079084.f_28396371).isFlying();
                ((CreativePlayer) Minecraft.f_33079084.f_28396371).setFlying(flying);
                ClientPlayNetworking.send(FCreative.FLIGHT_CHANNEL, new FlightPayload(flying));
                count = 0;
            }
            timeout = System.currentTimeMillis();
            count = 0;
        }
        else {
            count++;
        }
    }
}
