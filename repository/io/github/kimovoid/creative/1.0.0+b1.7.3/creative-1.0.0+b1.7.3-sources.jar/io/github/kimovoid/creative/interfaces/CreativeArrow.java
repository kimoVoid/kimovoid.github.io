package io.github.kimovoid.creative.interfaces;

public interface CreativeArrow {
    boolean canPickUp();
    void allowPickUp(boolean b);
}
