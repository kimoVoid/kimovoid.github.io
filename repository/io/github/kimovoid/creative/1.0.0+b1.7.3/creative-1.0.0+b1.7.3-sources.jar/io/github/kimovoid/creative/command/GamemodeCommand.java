package io.github.kimovoid.creative.command;

import com.periut.retrocommands.api.Command;
import com.periut.retrocommands.util.ParameterSuggestUtil;
import com.periut.retrocommands.util.SharedCommandSource;
import io.github.kimovoid.creative.interfaces.CreativePlayer;
import io.github.kimovoid.creative.server.ServerCommands;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;

import java.util.ArrayList;

public class GamemodeCommand implements Command {

    @Override
    public void command(SharedCommandSource source, String[] args) {
        if (args.length < 1) {
            manual(source);
            return;
        }

        boolean creative = args[1].charAt(0) == 'c' || args[1].charAt(0) == '1';
        if (args.length == 3 && FabricLoader.getInstance().getEnvironmentType().equals(EnvType.SERVER)) {
            ServerCommands.changePlayerGameMode(source, creative, args[2]);
            return;
        }

        if (source.getPlayer() == null) {
            source.sendFeedback("Can only be used by a player.");
            return;
        }

        ((CreativePlayer)source.getPlayer()).setCreative(creative);
        source.sendFeedback("Set game mode to " + (creative ? "Creative" : "Survival") + " Mode");
    }

    @Override
    public String name() {
        return "gamemode";
    }

    @Override
    public void manual(SharedCommandSource commandSource) {
        commandSource.sendFeedback("Usage: /gamemode {mode} [player]");
        commandSource.sendFeedback("Info: changes player's gamemode");
        commandSource.sendFeedback("mode can be 0/s/survival for survival mode");
        commandSource.sendFeedback("mode can be 1/c/creative for creative mode");
    }

    @Override
    public String[] suggestion(SharedCommandSource source, int parameterNum, String currentInput, String totalInput) {
        switch (parameterNum) {
            case 1: {
                String[] options = {"survival", "creative"};
                ArrayList<String> output = new ArrayList<>();
                for (String option : options) {
                    if (option.startsWith(currentInput)) {
                        output.add(option.substring(currentInput.length()));
                    }
                }
                return output.toArray(new String[0]);
            }
            case 2: {
                return ParameterSuggestUtil.suggestPlayerName(currentInput);
            }
        }
        return new String[0];
    }
}
