package io.github.kimovoid.creative.networking;

import net.ornithemc.osl.networking.api.PacketBuffer;
import net.ornithemc.osl.networking.api.PacketPayload;

public class FlightPayload implements PacketPayload {

    public boolean flying;

    public FlightPayload() {
    }

    public FlightPayload(boolean flying) {
        this.flying = flying;
    }

    @Override
    public void read(PacketBuffer buffer) {
        this.flying = buffer.readBoolean();
    }

    @Override
    public void write(PacketBuffer buffer) {
        buffer.writeBoolean(this.flying);
    }
}
