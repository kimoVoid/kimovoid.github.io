package io.github.kimovoid.creative.client.config;

import net.ornithemc.osl.config.api.ConfigScope;
import net.ornithemc.osl.config.api.LoadingPhase;
import net.ornithemc.osl.config.api.config.BaseConfig;
import net.ornithemc.osl.config.api.config.option.FloatOption;
import net.ornithemc.osl.config.api.serdes.FileSerializerType;
import net.ornithemc.osl.config.api.serdes.SerializerTypes;

public class Config extends BaseConfig {

    public final FloatOption flyBoost = new FloatOption("fly-boost", "Fly speed multiplier", 2.0F, value -> value >= 1.0F & value <= 10.0F);

    @Override
    public String getNamespace() {
        return "creative";
    }

    @Override
    public String getName() {
        return "Creative";
    }

    @Override
    public String getSaveName() {
        return "creative.json";
    }

    @Override
    public ConfigScope getScope() {
        return ConfigScope.GLOBAL;
    }

    @Override
    public LoadingPhase getLoadingPhase() {
        return LoadingPhase.START;
    }

    @Override
    public FileSerializerType<?> getType() {
        return SerializerTypes.JSON;
    }

    @Override
    public int getVersion() {
        return 1;
    }

    @Override
    public void init() {
        registerOptions("general", flyBoost);
    }
}
