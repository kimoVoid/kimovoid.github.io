package io.github.kimovoid.creative.client.gui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import io.github.kimovoid.creative.FCreative;
import io.github.kimovoid.creative.client.FCreativeClient;
import io.github.kimovoid.creative.compat.PolishedCompat;
import io.github.kimovoid.creative.interfaces.CreativePlayer;
import io.github.kimovoid.creative.networking.SlotUpdatePayload;
import io.github.kimovoid.creative.tab.CreativeModeTab;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.unmapped.C_12356698;
import net.minecraft.unmapped.C_14999373;
import net.minecraft.unmapped.C_15891356;
import net.minecraft.unmapped.C_16154270;
import net.minecraft.unmapped.C_22967193;
import net.minecraft.unmapped.C_32232284;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_43616774;
import net.minecraft.unmapped.C_46053237;
import net.minecraft.unmapped.C_66796240;
import net.minecraft.unmapped.C_85125467;
import net.minecraft.unmapped.C_85589673;
import net.minecraft.unmapped.C_87542771;
import net.minecraft.unmapped.C_87711245;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_95236836;
import net.minecraft.unmapped.C_97645581;
import net.ornithemc.osl.networking.api.client.ClientPlayNetworking;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

@Environment(EnvType.CLIENT)
public class CreativeInventoryScreen extends C_87711245 {

    private static final C_22967193 INVENTORY = new C_22967193("tmp", 45);
    private static int selectedTab = CreativeModeTab.BUILDING_BLOCKS.getId();
    private float scrollPosition = 0.0F;
    private boolean hasScrollBar = false;
    private boolean isMouseButtonDown;
    private SearchTextFieldWidget searchField;
    private List<C_12356698> slots;
    private C_12356698 trashSlot = null;
    private boolean scrolling = false;
    private int x;
    private int y;
    private int mouseX;
    private int mouseY;

    public CreativeInventoryScreen(C_40996800 player) {
        super(new CreativePlayerMenu(player));
        player.f_25936683 = this.f_76651046;
        this.f_51596313 = true;
        player.m_04336590(C_95236836.f_71183985, 1);
        this.f_73003637 = 136;
        this.f_99871233 = 195;
    }

    @Override
    public void m_53520780() {
        if (!((CreativePlayer) f_78495264.f_28396371).isCreative()) {
            this.f_78495264.m_52715402(new C_85589673(this.f_78495264.f_28396371));
        }
    }

    private boolean handleClickSlot(C_12356698 clickedSlot, int button, boolean quickMove) {
        this.scrolling = true;

        // clicked outside of inventory - drop cursor
        if (clickedSlot == null) {
            C_87542771 playerInventory = this.f_78495264.f_28396371.f_29439708;
            C_88708284 cursorItem = playerInventory.m_54140007();
            if (cursorItem != null) {
                if (button == 0) {
                    this.f_78495264.f_28396371.m_78441799(cursorItem);
                    this.addItemToCreativeMenu(cursorItem, -1);
                    playerInventory.m_74385138(null);
                    this.addItemToCreativeMenu(null, -2);
                } else if (button == 1) {
                    C_88708284 dropped = cursorItem.m_67861752(1);
                    this.f_78495264.f_28396371.m_78441799(dropped);
                    this.addItemToCreativeMenu(dropped, -1);
                    if (cursorItem.f_60602012 == 0) playerInventory.m_74385138(null);
                    this.addItemToCreativeMenu(cursorItem, -2);
                }
                return true;
            }
            return false;
        }

        // handle trash slot
        if (clickedSlot == this.trashSlot) {
            if (quickMove) {
                for (int i = 0; i < this.f_78495264.f_28396371.f_67740326.f_84566804.size(); i++) {
                    this.f_78495264.f_28396371.f_67740326.m_39704747(i, null);
                    this.addItemToCreativeMenu(null, i);
                }
            } else {
                this.f_78495264.f_28396371.f_29439708.m_74385138(null);
                this.addItemToCreativeMenu(null, -2);
            }
            return true;
        }

        C_87542771 playerInventory = this.f_78495264.f_28396371.f_29439708;
        C_88708284 cursorItem = playerInventory.m_54140007();
        C_88708284 slotItem = clickedSlot.m_96527510();

        // handle survival inventory
        if (selectedTab == CreativeModeTab.INVENTORY.getId()) {
            if (quickMove && (slotItem != null && slotItem.m_23235460() instanceof C_97645581)) {
                return true;
            }
        }

        // handle creative inventory
        if (clickedSlot.f_76989145 == INVENTORY) {
            if (cursorItem != null && slotItem != null && cursorItem.m_52048659(slotItem)) {
                if (button == 0) {
                    cursorItem.f_60602012 = quickMove ? cursorItem.m_02549920() : Math.min(cursorItem.f_60602012 + 1, cursorItem.m_02549920());
                } else if (cursorItem.f_60602012 <= 1) {
                    playerInventory.m_74385138(null);
                } else {
                    cursorItem.f_60602012--;
                }
            } else if (slotItem != null && cursorItem == null) {
                playerInventory.m_74385138(slotItem.m_73216943());
                cursorItem = playerInventory.m_54140007();
                if (quickMove || button == 2) cursorItem.f_60602012 = cursorItem.m_02549920();
                this.addItemToCreativeMenu(cursorItem, -2);
            } else {
                playerInventory.m_74385138(null);
                this.addItemToCreativeMenu(null, -2);
            }
            return true;
        }

        return false;
    }

    @Override
    public void m_41805697() {
        this.x = (this.f_05230747 - this.f_99871233) / 2;
        this.y = (this.f_07021018 - this.f_73003637) / 2;

        if (((CreativePlayer) f_78495264.f_28396371).isCreative()) {
            super.m_41805697();
            this.f_78519977.clear();
            Keyboard.enableRepeatEvents(true);
            this.searchField = new SearchTextFieldWidget(this.f_11884601, this.x + 82, this.y + 6, 89, 8);
            this.searchField.setMaxLength(15);
            this.searchField.setHasBorder(false);
            this.searchField.setVisible(false);
            this.searchField.setEditableColor(16777215);
            int prevTab = selectedTab;
            selectedTab = -1;
            this.setSelectedTab(CreativeModeTab.ALL[prevTab]);
        } else {
            this.f_78495264.m_52715402(new C_85589673(this.f_78495264.f_28396371));
        }
    }

    @Override
    public void m_47002234() {
        super.m_47002234();
        Keyboard.enableRepeatEvents(false);
    }

    @Override
    protected void m_29116903(char chr, int key) {
        // handle keys inside creative inventory
        if (this.handleKeyPress(key)) {
            return;
        }

        if (selectedTab != CreativeModeTab.SEARCH.getId()) {
            if (Keyboard.isKeyDown(this.f_78495264.f_58088711.f_02302636.f_57264828)) {
                this.setSelectedTab(CreativeModeTab.SEARCH);
            } else {
                super.m_29116903(chr, key);
            }
        } else {
            if (this.scrolling) {
                this.scrolling = false;
                this.searchField.setText("");
            }

            if (this.searchField.keyPressed(chr, key)) {
                this.search();
            } else {
                super.m_29116903(chr, key);
            }
        }
    }

    private void search() {
        CreativePlayerMenu creativeMenu = (CreativePlayerMenu) this.f_76651046;
        creativeMenu.items.clear();

        for (CreativeModeTab tab : CreativeModeTab.ALL) {
            creativeMenu.items.addAll(tab.getItems());
        }

        String query = this.searchField.getText().toLowerCase();
        Iterator<C_88708284> iterator = creativeMenu.items.iterator();
        while (iterator.hasNext()) {
            C_88708284 stack = iterator.next();
            boolean matches = C_16154270.m_56062593()
                    .m_36441695(stack.m_27822537())
                    .trim()
                    .toLowerCase()
                    .contains(query);
            if (!matches) iterator.remove();
        }

        this.scrollPosition = 0.0F;
        creativeMenu.scrollItems(0.0F);
    }

    @Override
    protected void m_22745008() {
        CreativeModeTab tab = CreativeModeTab.ALL[selectedTab];
        if (tab.hasTooltips()) {
            this.f_11884601.m_72964882(tab.getDisplayName(), 8, 6, 4210752);
        }
    }

    @Override
    protected void m_23755539(int mouseX, int mouseY, int button) {
        if (button == 0) {
            int relX = mouseX - this.x;
            int relY = mouseY - this.y;
            for (CreativeModeTab tab : CreativeModeTab.ALL) {
                if (this.isInRow(tab, relX, relY)) {
                    this.setSelectedTab(tab);
                    return;
                }
            }
        }

        if (button == 0 || button == 1 || button == 2) {
            C_12356698 inventorySlot = this.m_06972709(mouseX, mouseY);
            boolean inside = mouseX >= this.x && mouseY >= this.y && mouseX < this.x + this.f_99871233 && mouseY < this.y + this.f_73003637;
            int index = -1;
            if (inventorySlot != null) {
                index = inventorySlot.f_00184299;
            }

            if (!inside) {
                index = -999;
            }

            if (index != -1) {
                boolean b = index == -999 || !Keyboard.isKeyDown(42) && !Keyboard.isKeyDown(54);
                if (!this.handleClickSlot(inventorySlot, button, !b)) {
                    super.m_23755539(mouseX, mouseY, button);
                }
            }
        }
    }

    private boolean hasScrollbar() {
        return selectedTab != CreativeModeTab.INVENTORY.getId()
                && CreativeModeTab.ALL[selectedTab].hasScrollbar()
                && ((CreativePlayerMenu) this.f_76651046).isMaxTabsReached();
    }

    private void setSelectedTab(CreativeModeTab tab) {
        int prevTab = selectedTab;
        selectedTab = tab.getId();
        CreativePlayerMenu creativeMenu = (CreativePlayerMenu) this.f_76651046;
        creativeMenu.f_19073099.clear();
        tab.addItems(creativeMenu.f_19073099);

        if (tab == CreativeModeTab.INVENTORY) {
            C_46053237 playerMenu = this.f_78495264.f_28396371.f_67740326;
            if (this.slots == null) this.slots = creativeMenu.f_84566804;
            creativeMenu.f_84566804 = new ArrayList<>();

            for (int i = 0; i < playerMenu.f_84566804.size(); i++) {
                CreativeInventorySlot creativeSlot = new CreativeInventorySlot(playerMenu.f_84566804.get(i), i);
                //InventorySlot creativeSlot = new CreativeInventorySlot(playerMenu.slots.get(i), i).slot;
                creativeMenu.f_84566804.add(creativeSlot);

                if (i >= 5 && i < 9) {
                    int armorIndex = i - 5;
                    creativeSlot.f_95205544 = 9 + (armorIndex / 2) * 54;
                    creativeSlot.f_40293340 = 6 + (armorIndex % 2) * 27;
                } else if (i < 5) {
                    creativeSlot.f_95205544 = -2000;
                    creativeSlot.f_40293340 = -2000;
                } else if (i < playerMenu.f_84566804.size()) {
                    int gridIndex = i - 9;
                    creativeSlot.f_95205544 = 9 + (gridIndex % 9) * 18;
                    creativeSlot.f_40293340 = i >= 36 ? 112 : 54 + (gridIndex / 9) * 18;
                }
            }

            this.trashSlot = new C_12356698(INVENTORY, 0, 173, 112);
            creativeMenu.f_84566804.add(this.trashSlot);
        } else if (prevTab == CreativeModeTab.INVENTORY.getId()) {
            creativeMenu.f_84566804 = this.slots;
            this.slots = null;
        }

        if (this.searchField != null) {
            boolean isSearch = tab == CreativeModeTab.SEARCH;
            this.searchField.setVisible(isSearch);
            this.searchField.setFocused(isSearch);
            if (isSearch) {
                this.searchField.setText("");
                this.search();
            }
        }

        this.scrollPosition = 0.0F;
        creativeMenu.scrollItems(0.0F);
    }

    @Override
    public void m_29921564() {
        super.m_29921564();
        int scroll = Mouse.getEventDWheel();
        if (scroll != 0 && this.hasScrollbar()) {
            int rows = ((CreativePlayerMenu) this.f_76651046).f_19073099.size() / 9 - 5 + 1;
            int scrollDir = scroll > 0 ? 1 : -1;
            this.scrollPosition = Math.max(0.0F, Math.min(1.0F, this.scrollPosition - (float) scrollDir / rows));
            ((CreativePlayerMenu) this.f_76651046).scrollItems(this.scrollPosition);
        }
    }

    @Override
    public void m_93956703(int mouseX, int mouseY, float tickDelta) {
        boolean mouseDown = Mouse.isButtonDown(0);
        int scrollBarX = this.x + 175;
        int scrollBarTop = this.y + 18;
        int scrollBarRight = scrollBarX + 14;
        int scrollBarBottom = scrollBarTop + 112;

        if (!this.isMouseButtonDown && mouseDown && mouseX >= scrollBarX && mouseY >= scrollBarTop && mouseX < scrollBarRight && mouseY < scrollBarBottom) {
            this.hasScrollBar = this.hasScrollbar();
        }
        if (!mouseDown) this.hasScrollBar = false;
        this.isMouseButtonDown = mouseDown;

        if (this.hasScrollBar) {
            this.scrollPosition = Math.max(0.0F, Math.min(1.0F, (mouseY - scrollBarTop - 7.5F) / (scrollBarBottom - scrollBarTop - 15.0F)));
            ((CreativePlayerMenu) this.f_76651046).scrollItems(this.scrollPosition);
        }

        boolean hasInvTweaks = true;
        C_12356698 slot = m_06972709(mouseX, mouseY);

        if (slot != null && this.getSelectedTab() != CreativeModeTab.INVENTORY.getId()) {
            if (slot.f_00184299 < this.f_76651046.f_84566804.size() - 9) {
                hasInvTweaks = false;
            }
        }

        if (FabricLoader.getInstance().isModLoaded("polished")) {
            PolishedCompat.setInventoryTweaks(this, hasInvTweaks);
        }

        super.m_93956703(mouseX, mouseY, tickDelta);
        this.mouseX = mouseX;
        this.mouseY = mouseY;

        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glDisable(32826);
        C_14999373.m_94129982();
        GL11.glDisable(GL11.GL_LIGHTING);
        GL11.glDisable(2929);

        for (CreativeModeTab tab : CreativeModeTab.ALL) {
            if (this.renderTabTooltipIfHovered(tab, mouseX, mouseY)) break;
        }

        if (this.trashSlot != null && selectedTab == CreativeModeTab.INVENTORY.getId() && this.isMouseInRegion(this.trashSlot.f_95205544, this.trashSlot.f_40293340, 16, 16, mouseX, mouseY)) {
            this.renderTooltip(C_16154270.m_56062593().m_77288988("inventory.binSlot"), mouseX, mouseY);
        }
    }

    @Override
    protected void m_98661498(float tickDelta) {
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glPushMatrix();
        GL11.glRotatef(120.0F, 1.0F, 0.0F, 0.0F);
        C_14999373.m_00064778();
        GL11.glPopMatrix();

        int allItemsTex = this.f_78495264.f_45465196.m_33729172("/assets/creative/textures/tabs.png");
        CreativeModeTab activeTab = CreativeModeTab.ALL[selectedTab];
        int tabTex = this.f_78495264.f_45465196.m_33729172("/assets/creative/textures/" + activeTab.getTexture());

        for (CreativeModeTab tab : CreativeModeTab.ALL) {
            this.f_78495264.f_45465196.m_72568250(allItemsTex);
            if (tab.getId() != selectedTab) this.renderTabIcon(tab);
        }

        this.f_78495264.f_45465196.m_72568250(tabTex);
        this.m_66359748(this.x, this.y, 0, 0, this.f_99871233, this.f_73003637);
        this.searchField.render();
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);

        int scrollBarX = this.x + 175;
        int scrollBarTop = this.y + 18;
        int scrollBarBottom = scrollBarTop + 112;
        this.f_78495264.f_45465196.m_72568250(allItemsTex);
        if (activeTab.hasScrollbar()) {
            this.m_66359748(scrollBarX, scrollBarTop + (int) ((scrollBarBottom - scrollBarTop - 17) * this.scrollPosition), 232 + (this.hasScrollbar() ? 0 : 12), 0, 12, 15);
        }

        this.renderTabIcon(activeTab);
        if (activeTab == CreativeModeTab.INVENTORY) {
            this.renderEntity(this.x + 43, this.y + 45, this.x + 43 - this.mouseX, this.y + 45 - 30 - this.mouseY);
        }
    }

    protected void renderEntity(int x, int y, float yaw, float pitch) {
        GL11.glEnable(GL11.GL_COLOR_MATERIAL);
        GL11.glPushMatrix();
        GL11.glTranslatef(x, y, 50.0F);
        GL11.glScalef(-20, 20, 20);
        GL11.glRotatef(180.0F, 0.0F, 0.0F, 1.0F);
        float f = f_78495264.f_28396371.f_21972499;
        float g = f_78495264.f_28396371.f_80130373;
        float h = f_78495264.f_28396371.f_03549461;
        GL11.glRotatef(135.0F, 0.0F, 1.0F, 0.0F);
        C_14999373.m_00064778();
        GL11.glRotatef(-135.0F, 0.0F, 1.0F, 0.0F);
        GL11.glRotatef(-((float) Math.atan(pitch / 40.0F)) * 20.0F, 1.0F, 0.0F, 0.0F);
        f_78495264.f_28396371.f_21972499 = (float) Math.atan(yaw / 40.0F) * 20.0F;
        f_78495264.f_28396371.f_80130373 = (float) Math.atan(yaw / 40.0F) * 40.0F;
        f_78495264.f_28396371.f_03549461 = -((float) Math.atan(pitch / 40.0F)) * 20.0F;
        f_78495264.f_28396371.f_34411248 = 1.0F;
        GL11.glTranslatef(0.0F, f_78495264.f_28396371.f_85480687, 0.0F);
        C_32232284.f_14776289.f_72637476 = 180.0F;
        C_32232284.f_14776289.m_81887182(f_78495264.f_28396371, 0.0, 0.0, 0.0, 0.0F, 1.0F);
        f_78495264.f_28396371.f_34411248 = 0.0F;
        f_78495264.f_28396371.f_21972499 = f;
        f_78495264.f_28396371.f_80130373 = g;
        f_78495264.f_28396371.f_03549461 = h;
        GL11.glPopMatrix();
        C_14999373.m_94129982();
        GL11.glDisable(32826);
    }

    protected boolean isInRow(CreativeModeTab tab, int x, int y) {
        int col = tab.getColumn();
        int tabX = col == 5 ? this.f_99871233 - 28 + 2 : 28 * col + (Math.max(col, 0));
        int tabY = tab.isTopRow() ? -32 : this.f_73003637;
        return x >= tabX && x <= tabX + 28 && y >= tabY && y <= tabY + 32;
    }

    protected boolean renderTabTooltipIfHovered(CreativeModeTab tab, int mouseX, int mouseY) {
        int col = tab.getColumn();
        int tabX = col == 5 ? this.f_99871233 - 28 + 2 : 28 * col + (Math.max(col, 0));
        int tabY = tab.isTopRow() ? -32 : this.f_73003637;
        if (this.isMouseInRegion(tabX + 3, tabY + 3, 23, 27, mouseX, mouseY)) {
            this.renderTooltip(tab.getDisplayName(), mouseX, mouseY);
            return true;
        }
        return false;
    }

    protected void renderTabIcon(CreativeModeTab tab) {
        boolean isSelected = tab.getId() == selectedTab;
        boolean isTopRow = tab.isTopRow();
        int col = tab.getColumn();
        int tabX = col == 5 ? this.x + this.f_99871233 - 28 : this.x + col * 28 + (Math.max(col, 0));
        int tabY = isTopRow ? this.y - 28 : this.y + this.f_73003637 - 4;
        int texV = (isSelected ? 32 : 0) + (isTopRow ? 0 : 64);

        GL11.glDisable(GL11.GL_LIGHTING);
        this.m_66359748(tabX, tabY, col * 28, texV, 28, 32);

        GL11.glEnable(GL11.GL_LIGHTING);
        GL11.glEnable(32826);
        int iconX = tabX + 6;
        int iconY = tabY + 8 + (isTopRow ? 1 : -1);
        C_88708284 icon = new C_88708284(tab.getIcon());
        f_57528231.m_28591838(this.f_11884601, this.f_78495264.f_45465196, icon, iconX, iconY);
        f_57528231.m_87954625(this.f_11884601, this.f_78495264.f_45465196, icon, iconX, iconY);
        GL11.glDisable(GL11.GL_LIGHTING);
    }

    @Override
    protected void m_30778170(C_85125467 button) {
        if (button.f_92999450 == 0) this.f_78495264.m_52715402(new C_15891356(this.f_78495264.f_25215102));
        if (button.f_92999450 == 1) this.f_78495264.m_52715402(new C_66796240(this, this.f_78495264.f_25215102));
    }

    public int getSelectedTab() {
        return selectedTab;
    }

    private boolean isMouseInRegion(int x, int y, int sizeX, int sizeY, int mouseX, int mouseY) {
        int i = (this.f_05230747 - this.f_99871233) / 2;
        int j = (this.f_07021018 - this.f_73003637) / 2;
        mouseX -= i;
        mouseY -= j;
        return mouseX >= x - 1 && mouseX < x + sizeX + 1 && mouseY >= y - 1 && mouseY < y + sizeY + 1;
    }

    private void renderTooltip(String string, int mouseX, int mouseY) {
        if (string == null) {
            return;
        }
        int n = mouseX + 12;
        int n2 = mouseY - 12;
        int width = this.f_11884601.m_09235706(string);
        this.m_58083806(n - 3, n2 - 3, n + width + 3, n2 + 11, -1073741824, -1073741824);
        this.f_11884601.m_27673420(string, n, n2, -1);
    }

    public void addItemToCreativeMenu(C_88708284 item, int slot) {
        if (((CreativePlayer) f_78495264.f_28396371).isCreative()) {
            ClientPlayNetworking.send(FCreative.SLOT_UPDATE_CHANNEL, new SlotUpdatePayload(slot, item));
        }
    }

    private boolean handleKeyPress(int keyCode) {
        if (!FabricLoader.getInstance().isModLoaded("polished") || selectedTab == CreativeModeTab.INVENTORY.getId()) {
            return false;
        }

        C_12356698 slot = this.m_06972709(this.mouseX, this.mouseY);
        if (slot == null || slot.m_96527510() == null || slot.f_76989145 != INVENTORY) {
            return false;
        }

        // drop items
        if (PolishedCompat.hasDropKey() && keyCode == this.f_78495264.f_58088711.f_53542110.f_57264828) {
            C_88708284 item = slot.m_96527510().m_73216943();
            if (PolishedCompat.hasCtrlDropStack() && Keyboard.isKeyDown(Keyboard.KEY_LCONTROL)) {
                item.f_60602012 = item.m_02549920();
            }
            this.f_78495264.f_28396371.m_78441799(item);
            this.addItemToCreativeMenu(item, -1);
            return true;
        }

        // hotkey swap
        if (PolishedCompat.hasHotkeySwap()) {
            for (int i = 1; i < 10; i++) {
                int hotkey = FCreativeClient.KEYBINDS.getKeyFromCode(i + 1);
                if (hotkey == keyCode) {
                    C_88708284 item = slot.m_96527510().m_73216943();
                    item.f_60602012 = item.m_02549920();
                    int s = i + 36 - 1;
                    this.f_78495264.f_28396371.f_67740326.m_39704747(s, item);
                    this.addItemToCreativeMenu(item, s);
                    return true;
                }
            }
        }
        return false;
    }

    @Environment(EnvType.CLIENT)
    public static class CreativeInventorySlot extends C_12356698 {
        public final C_12356698 slot;

        public CreativeInventorySlot(C_12356698 slot, int id) {
            super(slot.f_76989145, id, 0, 0);
            this.slot = slot;
            this.f_00184299 = slot.f_00184299;
        }

        @Override
        public void m_04379969(C_88708284 item) {
            this.slot.m_04379969(item);
        }

        @Override
        public boolean m_74355745(C_88708284 item) {
            return this.slot.m_74355745(item);
        }

        @Override
        public C_88708284 m_96527510() {
            return this.slot.m_96527510();
        }

        @Override
        public boolean m_66326040() {
            return this.slot.m_66326040();
        }

        @Override
        public void m_06487241(C_88708284 item) {
            this.slot.m_06487241(item);
        }

        @Override
        public void m_64457805() {
            this.slot.m_64457805();
        }

        @Override
        public int m_72821612() {
            return this.slot.m_72821612();
        }

        @Override
        public int m_24076806() {
            return this.slot.m_24076806();
        }

        @Override
        public C_88708284 m_96468135(int amount) {
            return this.slot.m_96468135(amount);
        }

        @Override
        public boolean m_80837470(C_43616774 inventory, int slot) {
            return this.slot.m_80837470(inventory, slot);
        }
    }

    @Environment(EnvType.CLIENT)
    public static class CreativePlayerMenu extends C_46053237 {
        public List<C_88708284> f_19073099 = new ArrayList<>();

        public CreativePlayerMenu(C_40996800 player) {
            C_87542771 playerInventory = player.f_29439708;
            for (int row = 0; row < 5; row++) {
                for (int col = 0; col < 9; col++) {
                    this.m_97138749(new C_12356698(CreativeInventoryScreen.INVENTORY, row * 9 + col, 9 + col * 18, 18 + row * 18));
                }
            }
            for (int col = 0; col < 9; col++) {
                this.m_97138749(new C_12356698(playerInventory, col, 9 + col * 18, 112));
            }
            this.scrollItems(0.0F);
        }

        @Override
        public boolean m_85465282(C_40996800 player) {
            return true;
        }

        public void scrollItems(float position) {
            int rows = this.f_19073099.size() / 9 - 5 + 1;
            int startRow = Math.max(0, (int) (position * rows + 0.5));
            for (int row = 0; row < 5; row++) {
                for (int col = 0; col < 9; col++) {
                    int itemIndex = col + (row + startRow) * 9;
                    C_88708284 item = (itemIndex >= 0 && itemIndex < this.f_19073099.size()) ? this.f_19073099.get(itemIndex) : null;
                    CreativeInventoryScreen.INVENTORY.m_33431716(col + row * 9, item);
                }
            }
        }

        public boolean isMaxTabsReached() {
            return this.f_19073099.size() > 45;
        }

        @Override
        public C_88708284 m_36051996(int slot) {
            if (slot >= this.f_84566804.size() - 9 && slot < this.f_84566804.size()) {
                C_12356698 inventorySlot = this.f_84566804.get(slot);
                if (inventorySlot != null && inventorySlot.m_66326040()) inventorySlot.m_06487241(null);
            }
            return null;
        }
    }
}
