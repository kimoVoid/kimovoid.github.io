package io.github.kimovoid.creative.mixin.client.item;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.awt.*;
import net.minecraft.unmapped.C_03670941;
import net.minecraft.unmapped.C_19632932;
import net.minecraft.unmapped.C_81592558;

@Mixin(C_03670941.class)
public class BlockRendererMixin {

    @Shadow public boolean updateColor;

    @WrapOperation(
            method = "renderAsItem",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/block/BlockRenderer;tesselateTopFace(Lnet/minecraft/block/Block;DDDI)V",
                    ordinal = 0
            )
    )
    public void renderTopFace(C_03670941 instance, C_81592558 block, double x, double y, double z, int sprite, Operation<Void> original, @Local(argsOnly = true) float brightness) {
        if (block == C_81592558.f_41096518) {
            Color color = new Color(C_19632932.m_60771122(0.5F, 1.0F));
            if (this.updateColor) {
                int grassColor = C_19632932.m_60771122(0.5F, 1.0F);
                float r = 0.4862745F;
                float g = 0.7411765F;
                float b = 0.41960785F;

                if (grassColor != -8602261) {
                    r = (float) (grassColor >> 16 & 255) / 255.0F;
                    g = (float) (grassColor >> 8 & 255) / 255.0F;
                    b = (float) (grassColor & 255) / 255.0F;
                }

                GL11.glColor4f(r * brightness, g * brightness, b * brightness, 1.0F);
            } else {
                GL11.glColor3f(color.getRed() / 255F, color.getGreen() / 255F, color.getBlue() / 255F);
            }
        }

        original.call(instance, block, x, y, z, sprite);
    }

    @Inject(
            method = "renderAsItem",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/vertex/Tesselator;begin()V",
                    ordinal = 2,
                    shift = At.Shift.AFTER
            )
    )
    public void render(C_81592558 block, int metadata, float brightness, CallbackInfo ci) {
        if (block == C_81592558.f_41096518) {
            if (this.updateColor) {
                int blockColor = block.m_51470331(metadata);
                float r = (float) (blockColor >> 16 & 255) / 255.0F;
                float g = (float) (blockColor >> 8 & 255) / 255.0F;
                float b = (float) (blockColor & 255) / 255.0F;
                GL11.glColor4f(r * brightness, g * brightness, b * brightness, 1.0F);
            } else {
                GL11.glColor3f(1.0F, 1.0F, 1.0F);
            }
        }
    }
}
