package io.github.kimovoid.creative.mixin.server;

import io.github.kimovoid.creative.server.FCreativeServer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.unmapped.C_68604032;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MinecraftServer.class)
public class MinecraftServerMixin {

    @Shadow public C_68604032 properties;

    @Inject(
            method = "init",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/server/MinecraftServer;flightEnabled:Z",
                    opcode = Opcodes.PUTFIELD
            )
    )
    private void onServerStart(CallbackInfoReturnable<Boolean> cir) {
        int gamemode = this.properties.m_19563303("default-gamemode", 0);
        FCreativeServer.creativeServer = gamemode > 0;
    }
}
