package io.github.kimovoid.polished.client.feature.gui.multiplayer;

import io.github.kimovoid.polished.client.feature.gui.CallbackButtonWidget;
import net.minecraft.unmapped.C_16154270;
import net.minecraft.unmapped.C_16178213;
import net.minecraft.unmapped.C_85125467;
import net.minecraft.unmapped.C_85740840;
import org.lwjgl.input.Keyboard;

public class EditServerScreen extends C_85740840 {

    private final ServerData server;
    private C_85125467 button;
    private final MultiplayerScreen parent;
    private C_16178213 nameTextField;
    private C_16178213 ipTextField;
    private boolean showIp = true;
    private boolean ping = false;

    public EditServerScreen(MultiplayerScreen parent, ServerData server) {
        this.parent = parent;
        this.server = server;
    }

    public void m_53520780() {
        this.nameTextField.m_85307449();
        this.ipTextField.m_85307449();
    }

    public void m_41805697() {
        Keyboard.enableRepeatEvents(true);
        C_16154270 translations = C_16154270.m_56062593();
        if (this.server != null) {
            this.showIp = this.server.showIp;
            this.ping = this.server.canPing;
        }
        this.f_78519977.add(new CallbackButtonWidget(this.f_05230747 / 2 - 100, 140, 98, 20, translations.m_77288988("multiplayer.showIp") + (this.showIp ? " ON" : " OFF"), button -> {
            this.showIp = !this.showIp;
            button.f_35112386 = translations.m_77288988("multiplayer.showIp") + (this.showIp ? " ON" : " OFF");
        }));
        this.f_78519977.add(new CallbackButtonWidget(this.f_05230747 / 2 + 2, 140, 98, 20, translations.m_77288988("multiplayer.ping") + (this.ping ? " ON" : " OFF"), button -> {
            this.ping = !this.ping;
            button.f_35112386 = translations.m_77288988("multiplayer.ping") + (this.ping ? " ON" : " OFF");
        }));
        this.f_78519977.add(this.button = new CallbackButtonWidget(this.f_05230747 / 2 - 100, this.f_07021018 / 4 + 120 + 12, this.server == null ? translations.m_77288988("multiplayer.addServer") : translations.m_77288988("multiplayer.edit"), button -> {
            if (this.server != null) {
                this.server.name = this.nameTextField.m_79292215();
                this.server.ip = this.ipTextField.m_79292215();
                this.server.showIp = this.showIp;
                this.server.canPing = this.ping;
            } else {
                this.parent.getServersList().add(new ServerData(this.nameTextField.m_79292215(), this.ipTextField.m_79292215(), this.showIp, this.ping));
            }

            this.parent.saveServers();
            this.f_78495264.m_52715402(this.parent);
        }));
        this.f_78519977.add(new CallbackButtonWidget(this.f_05230747 / 2 - 100, this.f_07021018 / 4 + 144 + 12, translations.m_77288988("gui.cancel"), button -> {
            this.f_78495264.m_52715402(this.parent);
        }));

        this.nameTextField = new C_16178213(this, this.f_11884601, this.f_05230747 / 2 - 100, 60, 200, 20, this.server == null ? "" : this.server.name);
        this.nameTextField.m_59977312(32);
        this.ipTextField = new C_16178213(this, this.f_11884601, this.f_05230747 / 2 - 100, 106, 200, 20, this.server == null ? "" : this.server.ip);
        this.ipTextField.m_59977312(32);
        this.updateButton();
    }

    private void updateButton() {
        this.button.f_89460239 = !this.nameTextField.m_79292215().trim().isEmpty() && !this.ipTextField.m_79292215().trim().isEmpty();
    }

    public void m_47002234() {
        Keyboard.enableRepeatEvents(false);
    }

    @Override
    protected void m_29116903(char character, int keyCode) {
        this.nameTextField.m_47314154(character, keyCode);
        this.ipTextField.m_47314154(character, keyCode);
        this.updateButton();
        if (character == Keyboard.KEY_RETURN) {
            this.m_30778170(this.button);
        }
    }

    protected void m_23755539(int mouseX, int mouseY, int varbutton) {
        super.m_23755539(mouseX, mouseY, varbutton);
        this.nameTextField.m_27301372(mouseX, mouseY, varbutton);
        this.ipTextField.m_27301372(mouseX, mouseY, varbutton);
    }

    public void m_93956703(int mouseX, int mouseY, float delta) {
        this.m_34695786();
        C_16154270 translations = C_16154270.m_56062593();

        this.m_50067982(this.f_11884601, (this.server == null ? translations.m_77288988("multiplayer.addServer") : translations.m_77288988("multiplayer.editServerInfo")), this.f_05230747 / 2, 20, 16777215);
        this.m_62884682(this.f_11884601, translations.m_77288988("multiplayer.serverName"), this.f_05230747 / 2 - 100, 47, 10526880);
        this.m_62884682(this.f_11884601, translations.m_77288988("multiplayer.serverAddress"), this.f_05230747 / 2 - 100, 94, 10526880);
        this.nameTextField.m_30049367();
        this.ipTextField.m_30049367();

        if (this.ping) {
            m_50067982(this.f_78495264.f_21497584, translations.m_77288988("multiplayer.pingWarning"), this.f_05230747 / 2, 170, 0x808080);
        }

        super.m_93956703(mouseX, mouseY, delta);
    }
}