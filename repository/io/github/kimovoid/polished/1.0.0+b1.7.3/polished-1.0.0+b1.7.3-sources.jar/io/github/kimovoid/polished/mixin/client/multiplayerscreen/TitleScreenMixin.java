package io.github.kimovoid.polished.mixin.client.multiplayerscreen;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.kimovoid.polished.client.feature.gui.multiplayer.MultiplayerScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_95462098;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(C_95462098.class)
public class TitleScreenMixin extends C_85740840 {

    @WrapOperation(method = "buttonClicked", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Minecraft;openScreen(Lnet/minecraft/client/gui/screen/Screen;)V", ordinal = 2))
    private void onNewGuiMainMenu(Minecraft instance, C_85740840 screen, Operation<Void> original) {
        instance.m_52715402(new MultiplayerScreen(this));
    }
}
