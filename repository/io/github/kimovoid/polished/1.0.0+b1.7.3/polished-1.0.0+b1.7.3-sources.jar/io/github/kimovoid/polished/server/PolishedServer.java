package io.github.kimovoid.polished.server;

import io.github.kimovoid.polished.Polished;
import io.github.kimovoid.polished.networking.PlayerInfoPayload;
import io.github.kimovoid.polished.server.feature.ping.PlayerPing;
import io.github.kimovoid.polished.server.feature.ping.ServerPingPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_49202226;
import net.ornithemc.osl.entrypoints.api.server.ServerModInitializer;
import net.ornithemc.osl.lifecycle.api.server.MinecraftServerEvents;
import net.ornithemc.osl.networking.api.server.ServerConnectionEvents;
import net.ornithemc.osl.networking.api.server.ServerPlayNetworking;

public class PolishedServer implements ServerModInitializer {

    public static PolishedServer INSTANCE;
    public static MinecraftServer SERVER;
    public PolishedServerProperties properties;

    @Override
    public void initServer() {
        INSTANCE = this;

        /* Events */
        MinecraftServerEvents.PREPARE_WORLD.register(server -> {
            SERVER = server;
            this.properties = new PolishedServerProperties(SERVER);
            C_03562565.m_06518219(254, false, true, ServerPingPacket.class);
        });
        ServerConnectionEvents.PLAY_READY.register((server, player) -> this.sendPlayerInfo(player));
    }

    public void sendPlayerInfo(String username, boolean online, int ping) {
        SERVER.f_65897993.f_62748363.forEach(on -> ServerPlayNetworking.send(on, Polished.PLAYER_INFO_CHANNEL, new PlayerInfoPayload(username, online, ping)));
    }

    public void sendPlayerInfo(C_49202226 to) {
        for (C_49202226 on : SERVER.f_65897993.f_62748363) {
            ServerPlayNetworking.send(to, Polished.PLAYER_INFO_CHANNEL, new PlayerInfoPayload(
                    on.f_59008391,
                    true,
                    ((PlayerPing)on).getPing()));
        }
    }
}
