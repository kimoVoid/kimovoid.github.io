package io.github.kimovoid.polished.mixin.client.ghosttnt;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_36401657;
import net.minecraft.unmapped.C_64041439;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(C_36401657.class)
public class TntBlockMixin {

    @Inject(method = "onExploded", at = @At("HEAD"), cancellable = true)
    private void fixGhostTnt(C_64041439 world, int x, int y, int z, CallbackInfo ci) {
        if (world.f_50876584) {
            ci.cancel();
        }
    }
}
