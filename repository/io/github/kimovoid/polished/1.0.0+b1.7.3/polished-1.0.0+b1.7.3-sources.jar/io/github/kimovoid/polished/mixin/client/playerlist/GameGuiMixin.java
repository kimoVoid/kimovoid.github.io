package io.github.kimovoid.polished.mixin.client.playerlist;

import io.github.kimovoid.polished.client.PolishedClient;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_29058632;
import net.minecraft.unmapped.C_43718703;
import net.minecraft.unmapped.C_97866173;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Mixin(C_97866173.class)
public abstract class GameGuiMixin extends C_29058632 {

    @Shadow private Minecraft minecraft;

    @Inject(method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lorg/lwjgl/opengl/GL11;glEnable(I)V",
                    ordinal = 6,
                    remap = false
            )
    )
    public void injectTab(CallbackInfo ci) {
        if (!this.minecraft.f_92501186) {
            return;
        }

        if (Keyboard.isKeyDown(PolishedClient.INSTANCE.keyBindingHandler.getKeyByName("key.playerlist", Keyboard.KEY_TAB))) {
            if (PolishedClient.INSTANCE.playerList.isEmpty()) {
                return;
            }
            this.renderTabList(this.minecraft);
        }
    }

    @Unique
    private void renderTabList(Minecraft mc) {
        C_43718703 scaled = new C_43718703(mc.f_58088711, mc.f_31800787, mc.f_74192110);
        List<PlayerInfo> players = new ArrayList<>();
        int rowWidth = 0;
        for (Map.Entry<String, Integer> entry : PolishedClient.INSTANCE.playerList.entrySet()) {
            int stringWidth = mc.f_21497584.m_09235706(entry.getKey()) + 14;
            players.add(new PlayerInfo(entry.getKey(), entry.getValue()));
            if (stringWidth > rowWidth) rowWidth = stringWidth;
        }

        int playerCount;
        int size = playerCount = players.size();
        int columns = 1;
        while (size > 20) {
            size = (playerCount + ++columns - 1) / columns;
        }
        int x = (scaled.m_39119333() - columns * rowWidth) / 2;
        int y = 10;
        this.m_57734177(x - 1, y - 1, x + rowWidth * columns, y + 9 * size, Integer.MIN_VALUE);

        for (int i = 0; i < playerCount; ++i) {
            int n2 = x + i % columns * rowWidth;
            int n = y + i / columns * 9;
            this.m_57734177(n2, n, n2 + rowWidth - 1, n + 8, 0x20FFFFFF);
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            GL11.glEnable(3008);
            if (i >= players.size()) continue;
            PlayerInfo playerInfo = players.get(i);
            mc.f_21497584.m_27673420(playerInfo.playerName, n2, n, 0xFFFFFF);
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            mc.f_45465196.m_72568250(mc.f_45465196.m_33729172("/assets/polished/textures/tablist/icons.png"));
            int posY = playerInfo.ping < 0 ? 5 : (playerInfo.ping < 150 ? 0 : (playerInfo.ping < 300 ? 1 : (playerInfo.ping < 600 ? 2 : (playerInfo.ping < 1000 ? 3 : 4))));
            this.f_02657644 += 100.0f;
            this.m_66359748(n2 + rowWidth - 12, n, 0, 176 + posY * 8, 10, 8);
            this.f_02657644 -= 100.0f;
        }
    }

    @Unique
    private static class PlayerInfo {
        public String playerName;
        public int ping;
        public PlayerInfo(String playerName, int ping) {
            this.playerName = playerName;
            this.ping = ping;
        }
    }
}
