package io.github.kimovoid.polished.mixin.client.entityjitter;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_74425583;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Environment(EnvType.CLIENT)
@Mixin(C_42232651.class)
public class EntityMixin {

    @WrapOperation(method = "move", at = @At(value = "FIELD", target = "Lnet/minecraft/entity/Entity;x:D", opcode = Opcodes.PUTFIELD))
    private void fixX(C_42232651 entity, double value, Operation<Void> original) {
        if (!entity.f_94306729.f_50876584 || entity instanceof C_40996800 || !(entity instanceof C_74425583)) {
            entity.f_78826675 = value;
        }
    }

    @WrapOperation(method = "move", at = @At(value = "FIELD", target = "Lnet/minecraft/entity/Entity;y:D", opcode = Opcodes.PUTFIELD))
    private void fixY(C_42232651 entity, double value, Operation<Void> original) {
        if (!entity.f_94306729.f_50876584 || entity instanceof C_40996800 || !(entity instanceof C_74425583)) {
            entity.f_31030949 = value;
        }
    }

    @WrapOperation(method = "move", at = @At(value = "FIELD", target = "Lnet/minecraft/entity/Entity;z:D", opcode = Opcodes.PUTFIELD))
    private void fixZ(C_42232651 entity, double value, Operation<Void> original) {
        if (!entity.f_94306729.f_50876584 || entity instanceof C_40996800 || !(entity instanceof C_74425583)) {
            entity.f_97691941 = value;
        }
    }
}
