package io.github.kimovoid.polished.client.feature.gui.multiplayer;

import io.github.kimovoid.polished.Polished;
import io.github.kimovoid.polished.client.PolishedClient;
import io.github.kimovoid.polished.client.feature.gui.CallbackButtonWidget;
import io.github.kimovoid.polished.client.feature.gui.CallbackConfirmScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_08565163;
import net.minecraft.unmapped.C_16154270;
import net.minecraft.unmapped.C_23014920;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_77279411;
import net.minecraft.unmapped.C_85125467;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_95462098;
import org.lwjgl.input.Keyboard;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MultiplayerScreen extends C_85740840 {

    private final C_85740840 parent;
    private String title;
    private boolean joining;

    private ServerData selectedServer;
    private List<ServerData> serversList;
    private MultiplayerServerListWidget serverListWidget;

    private C_85125467 buttonEdit;
    private C_85125467 buttonConnect;
    private C_85125467 buttonDelete;

    public String tooltipText = null;
    public Object lock = new Object();
    public int serverCount = 0;

    public MultiplayerScreen() {
        this(new C_95462098());
    }

    public MultiplayerScreen(C_85740840 parent) {
        this.parent = parent;
    }

    public void m_41805697() {
        this.title = C_16154270.m_56062593().m_77288988("multiplayer.title");
        this.loadServers();
        this.serverListWidget = new MultiplayerServerListWidget(this);
        this.initButtons();
    }

    private void loadServers() {
        this.selectedServer = null;

        try {
            File serversFile = new File(Minecraft.m_06605904(), "servers.dat");
            if (serversFile.exists()) {
                C_74087615 nbt = C_08565163.m_07155133(new DataInputStream(Files.newInputStream(serversFile.toPath())));
                this.serversList = ServerData.load(nbt.m_95654166("servers"));
            } else {
                this.serversList = new ArrayList<>();
                this.saveServers();
            }
        } catch (IOException e) {
            Polished.LOGGER.error("Unable to load servers.dat file!");
        }
    }

    public void initButtons() {
        C_16154270 translationStorage = C_16154270.m_56062593();
        this.f_78519977.add(this.buttonConnect = new CallbackButtonWidget(this.f_05230747 / 2 - 150 - 4, this.f_07021018 - 52, 100, 20, translationStorage.m_77288988("multiplayer.connect"),
                button -> this.joinServer(this.selectedServer)));
        this.f_78519977.add(new CallbackButtonWidget(this.f_05230747 / 2 - 50, this.f_07021018 - 52, 100, 20, translationStorage.m_77288988("multiplayer.directConnect"),
                button -> this.f_78495264.m_52715402(new DirectConnectScreen(this))));
        this.f_78519977.add(new CallbackButtonWidget(this.f_05230747 / 2 + 50 + 4, this.f_07021018 - 52, 100, 20, translationStorage.m_77288988("multiplayer.addServer"),
                button -> this.f_78495264.m_52715402(new EditServerScreen(this, null))));
        this.f_78519977.add(this.buttonEdit = new CallbackButtonWidget(this.f_05230747 / 2 - 154, this.f_07021018 - 28, 74, 20, translationStorage.m_77288988("multiplayer.edit"),
                button -> this.f_78495264.m_52715402(new EditServerScreen(this, this.selectedServer))));
        this.f_78519977.add(this.buttonDelete = new CallbackButtonWidget(this.f_05230747 / 2 - 154 + (78), this.f_07021018 - 28, 74, 20, translationStorage.m_77288988("selectWorld.delete"), button -> {
            this.f_78495264.m_52715402(new CallbackConfirmScreen(this,
                    translationStorage.m_77288988("multiplayer.deleteConfirm"),
                    "'" + this.selectedServer.name + "' " + translationStorage.m_77288988("selectWorld.deleteWarning"),
                    translationStorage.m_77288988("selectWorld.deleteButton"),
                    translationStorage.m_77288988("gui.cancel"),
                    (result) -> {
                        if (result) {
                            this.deleteServer(this.selectedServer);
                        }

                        this.f_78495264.m_52715402(this);
                    }));
        }));
        this.f_78519977.add(new CallbackButtonWidget(this.f_05230747 / 2 - 154 + (78 * 2), this.f_07021018 - 28, 74, 20, translationStorage.m_77288988("multiplayer.refresh"),
                button -> this.f_78495264.m_52715402(new MultiplayerScreen(this.parent))));
        this.f_78519977.add(new CallbackButtonWidget(this.f_05230747 / 2 - 154 + (78 * 3), this.f_07021018 - 28, 74, 20, translationStorage.m_77288988("gui.cancel"),
                button -> this.f_78495264.m_52715402(this.parent)));
        this.buttonConnect.f_89460239 = false;
        this.buttonEdit.f_89460239 = false;
        this.buttonDelete.f_89460239 = false;
    }

    @Override
    protected void m_30778170(C_85125467 button) {
        this.serverListWidget.m_40864930(button);
    }

    public void selectServer(int slot, boolean join) {
        selectedServer = serversList.get(slot);
        boolean selected = selectedServer != null;

        buttonEdit.f_89460239 = selected;
        buttonDelete.f_89460239 = selected;
        buttonConnect.f_89460239 = selected;

        if (selected && join) {
            joinServer(selectedServer);
        }
    }

    public void joinServer(ServerData server) {
        this.f_78495264.m_52715402(null);
        if (!this.joining) {
            this.joining = true;
            DirectConnectScreen.connect(this.f_78495264, server.ip);
        }
    }

    public void deleteServer(ServerData server) {
        this.serversList.remove(server);
        this.saveServers();
    }

    public void saveServers() {
        try {
            C_74087615 compound = new C_74087615();
            compound.m_21770494("servers", ServerData.save(serversList));
            C_08565163.m_94300398(compound, new DataOutputStream(Files.newOutputStream(new File(Minecraft.m_06605904(), "servers.dat").toPath())));
        } catch (IOException e) {
            Polished.LOGGER.error("Unable to save servers.dat file!");
        }
    }

    public List<ServerData> getServersList() {
        return this.serversList;
    }

    @Override
    public void m_93956703(int mouseX, int mouseY, float delta) {
        this.tooltipText = null;
        this.serverListWidget.m_60498464(mouseX, mouseY, delta);
        this.m_50067982(this.f_11884601, this.title, this.f_05230747 / 2, 20, 16777215);
        super.m_93956703(mouseX, mouseY, delta);
        if (this.tooltipText != null) {
            this.drawTooltip(this.tooltipText, mouseX, mouseY);
        }
    }

    @Override
    protected void m_29116903(char chr, int key) {
        super.m_29116903(chr, key);

        /* Refresh */
        if (key == Keyboard.KEY_F5) {
            this.f_78495264.m_52715402(new MultiplayerScreen(this.parent));
        }

        /* Move servers with SHIFT + (UP/DOWN) */
        if ((key == Keyboard.KEY_UP || key == Keyboard.KEY_DOWN)
                && Keyboard.isKeyDown(PolishedClient.INSTANCE.keyBindingHandler.getKeyFromCode(Keyboard.KEY_LSHIFT))
                && this.selectedServer != null) {
            int i = this.serversList.indexOf(this.selectedServer);
            int pos = key == Keyboard.KEY_UP ? -1 : 1;
            if (pos == -1 && i > 0 || pos == 1 && i+pos < this.serversList.size()) {
                Collections.swap(this.serversList, i, i+pos);
                this.saveServers();
            }
        }
    }

    protected void drawTooltip(String string, int i, int j) {
        if (string == null) {
            return;
        }
        int n = i + 12;
        int n2 = j - 12;
        int n3 = this.f_11884601.m_09235706(string);
        this.m_58083806(n - 3, n2 - 3, n + n3 + 3, n2 + 8 + 3, -1073741824, -1073741824);
        this.f_11884601.m_27673420(string, n, n2, -1);
    }

    public Minecraft getMinecraft() {
        return this.f_78495264;
    }

    public C_23014920 getFontRenderer() {
        return this.f_11884601;
    }

    public ServerData getSelectedServer() {
        return this.selectedServer;
    }

    public void pingServer(ServerData server) throws IOException {
        String string = server.ip;
        String[] stringArray = string.split(":");
        if (stringArray.length > 2) {
            stringArray = new String[]{string};
        }
        String address = stringArray[0];
        int port = stringArray.length > 1 ? this.getPort(stringArray[1]) : 25565;
        DataInputStream filterInputStream = null;
        FilterOutputStream filterOutputStream = null;
        Socket sock = new Socket();

        try {
            sock.setSoTimeout(3000);
            sock.setTcpNoDelay(true);
            sock.setTrafficClass(18);
            sock.connect(new InetSocketAddress(address, port), 3000);
            filterInputStream = new DataInputStream(sock.getInputStream());
            filterOutputStream = new DataOutputStream(sock.getOutputStream());
            filterOutputStream.write(254);
            filterOutputStream.write(1);
            if (filterInputStream.read() != 255) {
                throw new IOException("Bad message");
            }

            String resp = C_03562565.m_86150294(filterInputStream, 256);
            char[] cArray = resp.toCharArray();
            for (int i = 0; i < cArray.length; i++) {
                if (cArray[i] != 167 && cArray[i] != 0 && C_77279411.f_42800273.indexOf(cArray[i]) < 0) {
                    cArray[i] = '?';
                }
            }

            String motd = new String(cArray);
            if (motd.startsWith("§")) { // allows color codes
                stringArray = motd.substring(1).split("\u0000");
                if (this.parseInt(stringArray[0], 0) == 1) {
                    server.description = stringArray[1];

                    int players = 0;
                    int maxPlayers = 0;
                    try {
                        players = Integer.parseInt(stringArray[2]);
                        maxPlayers = Integer.parseInt(stringArray[3]);
                    } catch (Exception ignored) {
                    }

                    if (players >= 0 && maxPlayers >= 0) {
                        server.onlinePlayers = "§7" + players + "§8/§7" + maxPlayers;
                    } else {
                        server.onlinePlayers = "§8" + "???";
                    }
                } else {
                    server.description = "§8" + "???";
                    server.onlinePlayers = "§8" + "???";
                }
            } else { // old betatweaks format
                stringArray = motd.split("§");
                motd = stringArray[0];

                int players = -1;
                int maxPlayers = -1;
                try {
                    players = Integer.parseInt(stringArray[1]);
                    maxPlayers = Integer.parseInt(stringArray[2]);
                } catch (Exception ignored) {
                }

                server.description = "§7" + motd;
                server.onlinePlayers = players >= 0 && maxPlayers > 0 ? "§7" + players + "§8/§7" + maxPlayers : "§8???";
            }
        } finally {
            try {
                if (filterInputStream != null) {
                    filterInputStream.close();
                }
            } catch (Throwable ignored) {}
            try {
                if (filterOutputStream != null) {
                    filterOutputStream.close();
                }
            } catch (Throwable ignored) {}
            try {
                (sock).close();
            } catch (Throwable ignored) {}
        }
    }

    private int getPort(String string) {
        try {
            return Integer.parseInt(string.trim());
        } catch (Exception exception) {
            return 25565;
        }
    }

    private int parseInt(String s, int def) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException ex) {
            return def;
        }
    }

    private String translateColor(String text) {
        char[] b = text.toCharArray();
        for (int i = 0; i < b.length - 1; i++) {
            if (b[i] == '&' && "0123456789AaBbCcDdEeFfKkLlMmNnOoRr".indexOf(b[i+1]) > -1) {
                b[i] = '§';
                b[i+1] = Character.toLowerCase(b[i+1]);
            }
        }
        return new String(b);
    }
}