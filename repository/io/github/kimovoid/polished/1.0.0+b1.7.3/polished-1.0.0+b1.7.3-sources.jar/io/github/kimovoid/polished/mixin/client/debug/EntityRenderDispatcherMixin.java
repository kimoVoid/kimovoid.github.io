package io.github.kimovoid.polished.mixin.client.debug;

import io.github.kimovoid.polished.client.PolishedClient;
import net.minecraft.unmapped.C_14999373;
import net.minecraft.unmapped.C_32232284;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_74425583;
import net.minecraft.unmapped.C_82690114;
import net.minecraft.unmapped.C_94584382;
import net.minecraft.unmapped.C_96603444;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_32232284.class)
public class EntityRenderDispatcherMixin {

    @Inject(
            method = "render(Lnet/minecraft/entity/Entity;DDDFF)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/entity/EntityRenderer;postRender(Lnet/minecraft/entity/Entity;DDDFF)V",
                    shift = At.Shift.AFTER
            )
    )
    private void renderHitboxes(C_42232651 entity, double dx, double dy, double dz, float yaw, float tickDelta, CallbackInfo ci) {
        if (!PolishedClient.INSTANCE.debugOptions.renderHitboxes || entity.f_00583773 == null) {
            return;
        }

        this.renderHitbox(entity, dx, dy, dz, yaw, tickDelta);
    }

    @Unique
    private void renderHitbox(C_42232651 entity, double dx, double dy, double dz, float yaw, float tickDelta) {
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        C_14999373.m_94129982();
        //GL11.glDisable(GL11.GL_BLEND);

        float f = entity.f_89295741 / 2.0F;
        C_82690114 box = entity.f_00583773;
        C_82690114 box2 = C_82690114.m_23878395(
                box.f_87518512 - entity.f_78826675 + dx,
                box.f_80314167 - entity.f_31030949 + dy,
                box.f_85940458 - entity.f_97691941 + dz,
                box.f_89130367 - entity.f_78826675 + dx,
                box.f_98553650 - entity.f_31030949 + dy,
                box.f_24562106 - entity.f_97691941 + dz
        );

        this.renderOutlineShape(box2, 255, 255, 255, 255);
        if (entity instanceof C_74425583) {
            float g = 0.01F;
            this.renderOutlineShape(
                    C_82690114.m_23878395(dx - f, dy + entity.m_00612634() - 0.01F, dz - f, dx + f, dy + entity.m_00612634() + 0.01F, dz + f), 255, 0, 0, 255
            );

            C_96603444 tesselator = C_96603444.f_99414865;
            C_94584382 vec3d = ((C_74425583)entity).m_49518844(tickDelta);
            tesselator.m_89066829(GL11.GL_LINE_STRIP);
            tesselator.m_72833996(0, 0, 255, 255);
            tesselator.m_51994127(dx, dy + entity.m_00612634(), dz);
            tesselator.m_51994127(dx + vec3d.f_96140729 * 2.0, dy + entity.m_00612634() + vec3d.f_95060918 * 2.0, dz + vec3d.f_88390642 * 2.0);
            tesselator.m_70070273();
        }

        GL11.glEnable(GL11.GL_TEXTURE_2D);
        C_14999373.m_00064778();
        //GL11.glEnable(GL11.GL_BLEND);
    }

    @Unique
    private void renderOutlineShape(C_82690114 shape, int r, int g, int b, int a) {
        C_96603444 tesselator = C_96603444.f_99414865;
        tesselator.m_89066829(GL11.GL_LINE_STRIP);
        tesselator.m_72833996(r, g, b, a);
        tesselator.m_51994127(shape.f_87518512, shape.f_80314167, shape.f_85940458);
        tesselator.m_51994127(shape.f_89130367, shape.f_80314167, shape.f_85940458);
        tesselator.m_51994127(shape.f_89130367, shape.f_80314167, shape.f_24562106);
        tesselator.m_51994127(shape.f_87518512, shape.f_80314167, shape.f_24562106);
        tesselator.m_51994127(shape.f_87518512, shape.f_80314167, shape.f_85940458);
        tesselator.m_70070273();

        tesselator.m_89066829(GL11.GL_LINE_STRIP);
        tesselator.m_72833996(r, g, b, a);
        tesselator.m_51994127(shape.f_87518512, shape.f_98553650, shape.f_85940458);
        tesselator.m_51994127(shape.f_89130367, shape.f_98553650, shape.f_85940458);
        tesselator.m_51994127(shape.f_89130367, shape.f_98553650, shape.f_24562106);
        tesselator.m_51994127(shape.f_87518512, shape.f_98553650, shape.f_24562106);
        tesselator.m_51994127(shape.f_87518512, shape.f_98553650, shape.f_85940458);
        tesselator.m_70070273();
        
        tesselator.m_89066829(GL11.GL_CURRENT_BIT);
        tesselator.m_72833996(r, g, b, a);
        tesselator.m_51994127(shape.f_87518512, shape.f_80314167, shape.f_85940458);
        tesselator.m_51994127(shape.f_87518512, shape.f_98553650, shape.f_85940458);
        tesselator.m_51994127(shape.f_89130367, shape.f_80314167, shape.f_85940458);
        tesselator.m_51994127(shape.f_89130367, shape.f_98553650, shape.f_85940458);
        tesselator.m_51994127(shape.f_89130367, shape.f_80314167, shape.f_24562106);
        tesselator.m_51994127(shape.f_89130367, shape.f_98553650, shape.f_24562106);
        tesselator.m_51994127(shape.f_87518512, shape.f_80314167, shape.f_24562106);
        tesselator.m_51994127(shape.f_87518512, shape.f_98553650, shape.f_24562106);
        tesselator.m_70070273();
    }
}
