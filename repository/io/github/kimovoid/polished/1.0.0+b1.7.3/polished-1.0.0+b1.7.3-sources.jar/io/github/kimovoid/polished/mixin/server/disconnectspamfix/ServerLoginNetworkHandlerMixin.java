package io.github.kimovoid.polished.mixin.server.disconnectspamfix;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.logging.Logger;
import net.minecraft.unmapped.C_58873528;

@Mixin(C_58873528.class)
public class ServerLoginNetworkHandlerMixin {

    // this is annoying tf out of me
    @WrapOperation(
            method = "onDisconnect",
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/util/logging/Logger;info(Ljava/lang/String;)V",
                    remap = false
            )
    )
    private void removeDisconnectSpam(Logger instance, String msg, Operation<Void> original) {
    }
}
