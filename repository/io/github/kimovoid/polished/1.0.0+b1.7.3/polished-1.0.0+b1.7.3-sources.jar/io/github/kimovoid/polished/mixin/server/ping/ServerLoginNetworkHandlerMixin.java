package io.github.kimovoid.polished.mixin.server.ping;

import io.github.kimovoid.polished.server.PolishedServer;
import net.minecraft.unmapped.C_28851891;
import net.minecraft.unmapped.C_47909326;
import net.minecraft.unmapped.C_58873528;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_58873528.class)
public class ServerLoginNetworkHandlerMixin {

    @Inject(
            method = "acceptLogin",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/server/entity/mob/player/ServerPlayerEntity;initMenu()V",
                    shift = At.Shift.AFTER
            )
    )
    public void injectLogin(C_47909326 packet, CallbackInfo ci) {
        PolishedServer.SERVER.f_65897993.m_70956744(packet.f_50178374, new C_28851891());
        PolishedServer.INSTANCE.sendPlayerInfo(packet.f_50178374, true, 0);
    }
}
