package io.github.kimovoid.polished.server;

import net.minecraft.server.MinecraftServer;

public class PolishedServerProperties {

    public String serverMotd;
    public boolean onePlayerSleep;
    public boolean deathCoordinates;
    public int spawnProtection;

    public PolishedServerProperties(MinecraftServer server) {
        this.serverMotd = server.f_42116803.m_50821119("motd", "A Minecraft Server");
        this.onePlayerSleep = server.f_42116803.m_37087607("one-player-sleep", false);
        this.deathCoordinates = server.f_42116803.m_37087607("death-coordinates", false);
        this.spawnProtection = server.f_42116803.m_19563303("spawn-protection", 16);
        server.f_42116803.m_85594935();
    }
}
