package io.github.kimovoid.polished.client.feature.gui;

import java.util.function.Consumer;
import net.minecraft.unmapped.C_22481487;
import net.minecraft.unmapped.C_85125467;
import net.minecraft.unmapped.C_85740840;

public class CallbackConfirmScreen extends C_22481487 {
    private final Consumer<Boolean> callback;

    public CallbackConfirmScreen(C_85740840 screen, String title, String message, String yes, String no, Consumer<Boolean> callback) {
        super(screen, title, message, yes, no, -1);
        this.callback = callback;
    }

    @Override
    protected void m_30778170(C_85125467 button) {
        this.callback.accept(button.f_92999450 == 0);
    }
}
