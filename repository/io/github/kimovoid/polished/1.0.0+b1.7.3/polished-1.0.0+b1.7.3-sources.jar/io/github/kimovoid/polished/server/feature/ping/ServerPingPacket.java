package io.github.kimovoid.polished.server.feature.ping;

import io.github.kimovoid.polished.server.PolishedServer;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_10918870;
import net.minecraft.unmapped.C_58873528;
import net.minecraft.unmapped.C_67358769;

public class ServerPingPacket extends C_03562565 {

    private int ping = 0;

    @Override
    public void m_13296744(DataInputStream input) {
        try {
            if (input.available() > 0) { // to avoid timeout
                this.ping = input.readByte();
            }
        } catch (IOException ex) {
            this.ping = 0;
        }
    }

    @Override
    public void m_17566769(DataOutputStream output) {
    }

    @Override
    public void m_04853589(C_10918870 handler) {
        String motd = PolishedServer.INSTANCE.properties.serverMotd;
        int players = PolishedServer.SERVER.f_65897993.f_62748363.size();
        int maxPlayers = PolishedServer.SERVER.f_42116803.m_19563303("max-players", 20);

        String response;
        if (this.ping == 1) {
            // ping with color code support
            List<Object> fields = Arrays.asList(
                    1,
                    motd,
                    players,
                    maxPlayers
            );

            StringBuilder sb = new StringBuilder("§");
            for (int i = 0; i < fields.size(); i++) {
                if (i > 0) sb.append("\u0000");
                sb.append(fields.get(i).toString().replace("\u0000", ""));
            }
            response = sb.toString();
        } else {
            // basic ping for betatweaks and older mods
            response = motd.replaceAll("§[0-9a-fk-orA-FK-OR]", "") + "§" + players + "§" + maxPlayers;
        }

        C_58873528 nh = (C_58873528)handler;
        if (nh.f_82327142 == null) return;
        nh.f_82327142.m_00234283(new C_67358769(response));
        nh.f_82327142.m_17873754();
        nh.f_36361981 = true;
    }

    @Override
    public int m_85604015() {
        return 0;
    }
}
