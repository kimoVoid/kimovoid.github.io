package io.github.kimovoid.polished.mixin.server.bowsounds;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_04428890;
import net.minecraft.unmapped.C_12192847;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_64041439;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Environment(EnvType.SERVER)
@Mixin(C_04428890.class)
public abstract class SkeletonEntityMixin extends C_12192847 {

    public SkeletonEntityMixin(C_64041439 world) {
        super(world);
    }

    @WrapOperation(method = "targetInSight", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;playSound(Lnet/minecraft/entity/Entity;Ljava/lang/String;FF)V"))
    private void fixBowSound(C_64041439 instance, C_42232651 source, String sound, float volume, float pitch, Operation<Void> original) {
        this.f_94306729.m_80788745(1002, C_45510667.m_80489169(this.f_78826675), C_45510667.m_80489169(this.f_31030949 - (double)this.f_80245663), C_45510667.m_80489169(this.f_97691941), 0);
    }
}
