package io.github.kimovoid.polished.mixin.common.rain;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;
import net.minecraft.unmapped.C_08489468;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_64676926;
import net.minecraft.unmapped.C_90532916;

@Mixin(C_64041439.class)
public class WorldMixin {

	@Shadow protected C_64676926 data;
	@Final @Shadow public C_90532916 dimension;

	@WrapOperation(
			method = "saveData()V",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/storage/WorldStorage;saveData(Lnet/minecraft/world/WorldData;Ljava/util/List;)V"
			)
	)
	private void fixWeatherSave(C_08489468 storage, C_64676926 worldData, List<C_40996800> playerEntities, Operation<Void> original) {
		if (this.dimension.f_09977150 == 0) original.call(storage, data, playerEntities);
	}
}
