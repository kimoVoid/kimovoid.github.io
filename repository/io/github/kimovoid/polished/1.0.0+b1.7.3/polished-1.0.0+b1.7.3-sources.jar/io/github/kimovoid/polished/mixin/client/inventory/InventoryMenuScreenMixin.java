package io.github.kimovoid.polished.mixin.client.inventory;

import io.github.kimovoid.polished.client.PolishedClient;
import io.github.kimovoid.polished.client.feature.inventorytweaks.CreativeIntegration;
import io.github.kimovoid.polished.client.feature.inventorytweaks.InventoryTweaks;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_12356698;
import net.minecraft.unmapped.C_13858042;
import net.minecraft.unmapped.C_21951175;
import net.minecraft.unmapped.C_46053237;
import net.minecraft.unmapped.C_53504297;
import net.minecraft.unmapped.C_53724168;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_85589673;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_87711245;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_97645581;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;

@Mixin(C_87711245.class)
public abstract class InventoryMenuScreenMixin extends C_85740840 implements InventoryTweaks {
    
    @Shadow public C_46053237 menu;
    @Shadow protected abstract C_12356698 getSlot(int x, int y);

    @Unique private boolean enabled = true;
    @Unique private long currentTime;
    @Unique private C_12356698 slot;
    @Unique C_12356698 lastRMBSlot = null;
    @Unique C_12356698 lastLMBSlot = null;
    @Unique int lastRMBSlotId = -1;
    @Unique int lastLMBSlotId = -1;
    @Unique private C_88708284 leftClickMouseTweaksPersistentStack = null;
    @Unique private C_88708284 leftClickPersistentStack = null;
    @Unique private C_88708284 rightClickPersistentStack = null;
    @Unique private boolean isLeftClickDragMouseTweaksStarted = false;
    @Unique private boolean isLeftClickDragStarted = false;
    @Unique private boolean isRightClickDragStarted = false;
    @Unique private final List<C_12356698> leftClickHoveredSlots = new ArrayList<>();
    @Unique final List<C_12356698> rightClickHoveredSlots = new ArrayList<>();
    @Unique Integer leftClickItemAmount;
    @Unique Integer rightClickItemAmount;
    @Unique final List<Integer> leftClickExistingAmount = new ArrayList<>();
    @Unique final List<Integer> rightClickExistingAmount = new ArrayList<>();
    @Unique List<Integer> leftClickAmountToFillPersistent = new ArrayList<>();

    /* True if either shift key is currently held. */
    @Unique private static boolean isShiftDown() {
        return Keyboard.isKeyDown(Keyboard.KEY_LSHIFT) || Keyboard.isKeyDown(Keyboard.KEY_RSHIFT);
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    protected void inventoryTweaks_mouseClicked(int mouseX, int mouseY, int button, CallbackInfo ci) {
        if (this.inventoryTweaks_isDisabled()) return;

        isLeftClickDragMouseTweaksStarted = false;

        /* Check if client is on a server */
        boolean isClientOnServer = f_78495264.m_38583715();
        C_12356698 clickedSlot = this.getSlot(mouseX, mouseY);

        /* Craft maximum possible amount */
        if (isShiftDown()
                && clickedSlot instanceof C_53724168
                && clickedSlot.m_66326040()
                && PolishedClient.CONFIG.craftAll.get()) {
            int itemId = clickedSlot.m_96527510().f_59294634;
            for (int craftingAttempts = 0; craftingAttempts < 256; craftingAttempts++) {
                if (clickedSlot.m_66326040() && itemId == clickedSlot.m_96527510().f_59294634) {
                    this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, clickedSlot.f_00184299, button, true, this.f_78495264.f_28396371);
                } else {
                    break;
                }
            }
            ci.cancel();
            return;
        }

        /* Check special click behavior for current screen */
        if (f_78495264.f_70816363 instanceof C_85589673) {
            /* Handle shift click into armor slots */
            if (PolishedClient.CONFIG.shiftIntoArmor.get()) {
                if (inventoryTweaks_handleShiftClickIntoArmorSlots(button, clickedSlot)) {
                    /* Handle if a button was clicked */
                    super.m_23755539(mouseX, mouseY, button);
                    ci.cancel();
                    return;
                }
            }
        } else if (f_78495264.f_70816363 instanceof C_21951175) {
            /* Handle shift click into furnace */
            if (PolishedClient.CONFIG.shiftIntoFurnace.get()) {
                if (inventoryTweaks_handleShiftClickIntoFurnace(button, clickedSlot)) {
                    /* Handle if a button was clicked */
                    super.m_23755539(mouseX, mouseY, button);
                    ci.cancel();
                    return;
                }
            }
        }

        /* Right-click */
        if (button == 1) {
            /* Should click cancel Left-click + Drag */
            boolean exitFunction = inventoryTweaks_cancelLeftClickDrag(isClientOnServer)
                    || (PolishedClient.CONFIG.leftClickDrag.get() && inventoryTweaks_handleRightClick(mouseX, mouseY));

            if (exitFunction) {
                /* Handle if a button was clicked */
                super.m_23755539(mouseX, mouseY, button);
                ci.cancel();
                return;
            }
        }

        /* Left-click */
        if (button == 0) {
            boolean exitFunction = false;

            /* Should click cancel Right-click + Drag */
            if (inventoryTweaks_cancelRightClickDrag(isClientOnServer)) {
                exitFunction = true;
            } else {
                /* Handle Left-click */
                C_88708284 cursorStack = f_78495264.f_28396371.f_29439708.m_54140007();
                if (cursorStack != null) {
                    /* Check for double left-click fill cursor stack (checking for second click close to time of first click) */
                    if (PolishedClient.CONFIG.doubleClick.get()) {
                        if (null != clickedSlot && !clickedSlot.m_66326040() && null != f_78495264.f_26407825) {
                            if (5 > (f_78495264.f_26407825.m_13949261() - currentTime)) {
                                if (inventoryTweaks_handleDoubleClickEmptyCursor(clickedSlot)) {
                                    /* Handle if a button was clicked */
                                    super.m_23755539(mouseX, mouseY, button);
                                    ci.cancel();
                                    return;
                                }
                            }
                        }
                    }

                    if (PolishedClient.CONFIG.leftClickDrag.get()) {
                        exitFunction = inventoryTweaks_handleLeftClickWithItem(cursorStack, clickedSlot, isClientOnServer);
                    }
                } else {
                    /* Begin double left-click fill cursor stack (first click registered) */
                    if (PolishedClient.CONFIG.doubleClick.get()) {
                        if (null != clickedSlot && clickedSlot.m_66326040() && null != f_78495264.f_26407825) {
                            currentTime = f_78495264.f_26407825.m_13949261();
                        }
                    }

                    exitFunction = inventoryTweaks_handleLeftClickWithoutItem(clickedSlot);
                }
            }

            if (exitFunction) {
                /* Handle if a button was clicked */
                super.m_23755539(mouseX, mouseY, button);
                ci.cancel();
            }
        }
    }

    @Unique
    private boolean inventoryTweaks_handleShiftClickIntoArmorSlots(int button, C_12356698 clickedSlot) {
        boolean isShiftKeyDown = (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT) || Keyboard.isKeyDown(Keyboard.KEY_RSHIFT));
        if (isShiftKeyDown) {

            if (null != clickedSlot && clickedSlot.m_66326040()) {
                C_85589673 inventoryScreen = (C_85589673) f_78495264.f_70816363;

                if (clickedSlot != inventoryScreen.f_76651046.f_84566804.get(5)
                        && (clickedSlot != inventoryScreen.f_76651046.f_84566804.get(6))
                        && (clickedSlot != inventoryScreen.f_76651046.f_84566804.get(7))
                        && (clickedSlot != inventoryScreen.f_76651046.f_84566804.get(8))
                ) {
                    C_88708284 slotStack = clickedSlot.m_96527510();
                    int shiftToSlot = -1;
                    boolean isPumpkin = false;

                    if (slotStack.m_23235460() instanceof C_97645581) {
                        int equipmentSlot = ((C_97645581) slotStack.m_23235460()).f_17168120;

                        if (0 == equipmentSlot) {
                            if (!(inventoryScreen.f_76651046.f_84566804.get(5)).m_66326040()) {
                                shiftToSlot = 5;
                            }
                        } else if (1 == equipmentSlot) {
                            if (!(inventoryScreen.f_76651046.f_84566804.get(6)).m_66326040()) {
                                shiftToSlot = 6;
                            }
                        } else if (2 == equipmentSlot) {
                            if (!(inventoryScreen.f_76651046.f_84566804.get(7)).m_66326040()) {
                                shiftToSlot = 7;
                            }
                        } else if (3 == equipmentSlot) {
                            if (!(inventoryScreen.f_76651046.f_84566804.get(8)).m_66326040()) {
                                shiftToSlot = 8;
                            }
                        }
                    } else if (C_81592558.f_94091898.f_84602679 == slotStack.f_59294634) {
                        if (!(inventoryScreen.f_76651046.f_84566804.get(5)).m_66326040()) {
                            shiftToSlot = 5;
                            isPumpkin = true;
                        }
                    }

                    if (0 <= shiftToSlot) {
                        if (null != f_78495264.f_28396371.f_29439708.m_54140007()) {
                            this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, clickedSlot.f_00184299, button, false, this.f_78495264.f_28396371);
                            this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, (inventoryScreen.f_76651046.f_84566804.get(shiftToSlot)).f_00184299, button, false, this.f_78495264.f_28396371);
                            this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, clickedSlot.f_00184299, button, false, this.f_78495264.f_28396371);
                        } else {
                            this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, clickedSlot.f_00184299, button, false, this.f_78495264.f_28396371);
                            this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, (inventoryScreen.f_76651046.f_84566804.get(shiftToSlot)).f_00184299, button, false, this.f_78495264.f_28396371);

                            if (isPumpkin) {
                                this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, slot.f_00184299, button, false, this.f_78495264.f_28396371);
                            }
                        }

                        if (isPumpkin) {
                            this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, slot.f_00184299, button, true, this.f_78495264.f_28396371);
                        }

                        return true;
                    }
                }
            }
        }

        return false;
    }

    @Unique
    private boolean inventoryTweaks_handleShiftClickIntoFurnace(int button, C_12356698 clickedSlot) {
        boolean isShiftKeyDown = (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT) || Keyboard.isKeyDown(Keyboard.KEY_RSHIFT));
        if (isShiftKeyDown) {

            if (null != clickedSlot && clickedSlot.m_66326040()) {
                C_21951175 furnaceScreen = (C_21951175) f_78495264.f_70816363;

                if (clickedSlot != (furnaceScreen.f_76651046.f_84566804.get(0))
                        && clickedSlot != (furnaceScreen.f_76651046.f_84566804.get(1))
                        && clickedSlot != (furnaceScreen.f_76651046.f_84566804.get(2))) {
                    try {
                        C_88708284 slotStack = clickedSlot.m_96527510();
                        int shiftToSlot = -1;

                        if (null != C_13858042.m_49255699().m_22042144(slotStack.m_23235460().f_57562535)) {
                            if (0 <= this.inventoryTweaks_canItemFitInSlot(slotStack, (furnaceScreen.f_76651046.f_84566804.get(0)))) {
                                shiftToSlot = 0;
                            } else {
                                shiftToSlot = -2;
                            }
                        } else {
                            C_53504297 furnace = furnaceScreen.f_22384365;

                            if (0 < (furnace.m_22435140(slotStack))) {
                                if (0 <= this.inventoryTweaks_canItemFitInSlot(slotStack, (furnaceScreen.f_76651046.f_84566804.get(1)))) {
                                    shiftToSlot = 1;
                                } else {
                                    shiftToSlot = -2;
                                }
                            }
                        }

                        if (-2 == shiftToSlot) {
                            return true;
                        } else if (0 <= shiftToSlot) {
                            if (null != f_78495264.f_28396371.f_29439708.m_54140007()) {
                                this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, clickedSlot.f_00184299, button, false, this.f_78495264.f_28396371);
                                this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, (furnaceScreen.f_76651046.f_84566804.get(shiftToSlot)).f_00184299, button, false, this.f_78495264.f_28396371);
                                this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, clickedSlot.f_00184299, button, false, this.f_78495264.f_28396371);
                            } else {
                                this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, clickedSlot.f_00184299, button, false, this.f_78495264.f_28396371);
                                this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, (furnaceScreen.f_76651046.f_84566804.get(shiftToSlot)).f_00184299, button, false, this.f_78495264.f_28396371);
                                if (null != f_78495264.f_28396371.f_29439708.m_54140007()) {
                                    this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, clickedSlot.f_00184299, button, false, this.f_78495264.f_28396371);
                                }
                            }

                            return true;
                        }
                    } catch (Exception ex) {
                        /* Do nothing */
                    }
                }
            }
        }

        return false;
    }

    @Unique private boolean inventoryTweaks_handleDoubleClickEmptyCursor(C_12356698 clickedSlot) {
        if (null != clickedSlot) {
            C_87711245 inventory = (C_87711245) f_78495264.f_70816363;
            C_88708284 slotStack = f_78495264.f_28396371.f_29439708.m_54140007();
            boolean b = false;

            /* Shift item back into player inventory */
            for (int i = 0; i < inventory.f_76651046.f_84566804.size(); i++) {
                if (FabricLoader.getInstance().isModLoaded("creative")) {
                    if (CreativeIntegration.shouldSkipSlot((C_87711245) (Object) this, i)) {
                        continue;
                    }
                }

                if (inventoryTweaks_isItemInSlot(slotStack, (inventory.f_76651046.f_84566804.get(i)))) {
                    b = true;
                    this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, inventory.f_76651046.f_84566804.get(i).f_00184299, 0, false, this.f_78495264.f_28396371);
                    this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, inventory.f_76651046.f_84566804.get(i).f_00184299, 0, false, this.f_78495264.f_28396371);

                    C_88708284 itemStack = (inventory.f_76651046.f_84566804.get(i)).m_96527510();
                    if (null != itemStack && itemStack.f_60602012 == itemStack.m_23235460().m_03156313()) {
                        this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, clickedSlot.f_00184299, 0, false, this.f_78495264.f_28396371);
                        this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, inventory.f_76651046.f_84566804.get(i).f_00184299, 0, false, this.f_78495264.f_28396371);
                        this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, clickedSlot.f_00184299, 0, false, this.f_78495264.f_28396371);
                        this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, inventory.f_76651046.f_84566804.get(i).f_00184299, 0, false, this.f_78495264.f_28396371);
                        this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, clickedSlot.f_00184299, 0, false, this.f_78495264.f_28396371);

                        /* Stack is full */
                        break;
                    }
                }

                C_88708284 cursorStack = f_78495264.f_28396371.f_29439708.m_54140007();
                if (null != cursorStack && cursorStack.f_60602012 == cursorStack.m_23235460().m_03156313()) {
                    /* Stack is full */
                    break;
                }
            }
            return b;
        }

        return false;
    }

    @Inject(method = "mouseReleased", at = @At("RETURN"))
    private void inventoryTweaks_mouseReleasedOrSlotChanged(int mouseX, int mouseY, int button, CallbackInfo ci) {
        if (this.inventoryTweaks_isDisabled()) return;

        slot = getSlot(mouseX, mouseY);

        /* Clear dragging variables */
        if (button == 0) {
            inventoryTweaks_resetLeftClickDragVariables();
        } else if (button == 1) {
            inventoryTweaks_resetRightClickDragVariables();
        }

        /* Do nothing if mouse is not over a slot */
        if (slot == null) {
            return;
        }

        /* Right-click + Drag logic = distribute one item from held items to each slot */
        if (button == -1
                && Mouse.isButtonDown(1)
                && !isLeftClickDragStarted
                && !isLeftClickDragMouseTweaksStarted
                && rightClickPersistentStack != null) {
            C_88708284 slotItemToExamine = slot.m_96527510();

            /* Do nothing if slot item does not match held item or if the slot is full */
            if (slotItemToExamine != null
                    && (!slotItemToExamine.m_52048659(rightClickPersistentStack)
                    || slotItemToExamine.f_60602012 == rightClickPersistentStack.m_02549920())) {
                return;
            }

            /* Do nothing if there are no more items to distribute */
            C_88708284 cursorStack = f_78495264.f_28396371.f_29439708.m_54140007();
            if (cursorStack == null) {
                return;
            }

            if (!rightClickHoveredSlots.contains(slot)) {
                inventoryTweaks_handleRightClickDrag(slotItemToExamine);
            } else if (PolishedClient.CONFIG.tweakRMB.get()) {
                inventoryTweaks_handleRightClickDragMouseTweaks();
            }
        } else {
            inventoryTweaks_resetRightClickDragVariables();
        }

        /* Left-click + Drag logic = evenly distribute held items over slots */
        if (button == -1 && Mouse.isButtonDown(0) && !isRightClickDragStarted) {
            if (isLeftClickDragMouseTweaksStarted) {
                inventoryTweaks_handleLeftClickDragMouseTweaks();
            } else if (leftClickPersistentStack != null) {
                if (inventoryTweaks_handleLeftClickDrag()) {
                    return;
                }
            } else {
                inventoryTweaks_resetLeftClickDragVariables();
            }
        } else {
            inventoryTweaks_resetLeftClickDragVariables();
        }
    }

    @Unique private boolean inventoryTweaks_handleRightClick(int mouseX, int mouseY) {
        /* Get held item */
        C_88708284 cursorStack = f_78495264.f_28396371.f_29439708.m_54140007();
        if (cursorStack == null) {
            return false;
        }

        /* Ensure a slot was clicked */
        C_12356698 clickedSlot = this.getSlot(mouseX, mouseY);
        if (clickedSlot == null) {
            return false;
        }

        /* Record how many items are in the slot */
        if (clickedSlot.m_96527510() != null) {
            /* Let vanilla minecraft handle right click with an item onto a different item */
            if (!cursorStack.m_52048659(clickedSlot.m_96527510())) {
                return false;
            }
            rightClickExistingAmount.add(clickedSlot.m_96527510().f_60602012);
        } else {
            rightClickExistingAmount.add(0);
        }

        /* Begin Right-click + Drag */
        if (rightClickPersistentStack == null && !isRightClickDragStarted) {
            rightClickPersistentStack = cursorStack;
            rightClickItemAmount = rightClickPersistentStack.f_60602012;
            isRightClickDragStarted = true;
        }

        /* Handle initial Right-click */
        lastRMBSlotId = clickedSlot.f_00184299;
        lastRMBSlot = clickedSlot;
        if (PolishedClient.CONFIG.preferShiftRMB.get()) {
            boolean isShiftKeyDown = isShiftDown();
            this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, clickedSlot.f_00184299, 1, isShiftKeyDown, this.f_78495264.f_28396371);

            if (isShiftKeyDown) {
                inventoryTweaks_resetRightClickDragVariables();
            }
        } else {
            this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, clickedSlot.f_00184299, 1, false, this.f_78495264.f_28396371);
        }

        return true;
    }

    @Unique private void inventoryTweaks_handleRightClickDragMouseTweaks() {
        if (slot.f_00184299 == lastRMBSlotId) {
            return;
        }
        C_88708284 cursorStack = f_78495264.f_28396371.f_29439708.m_54140007();
        if (cursorStack != null) {
            /* Distribute one item to the slot */
            lastRMBSlotId = slot.f_00184299;
            this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, slot.f_00184299, 1, false, this.f_78495264.f_28396371);
        }
    }

    @Unique private void inventoryTweaks_handleRightClickDrag(C_88708284 slotItemToExamine) {
        /* First slot is handled instantly in mouseClicked function */
        if (slot.f_00184299 == lastRMBSlotId) {
            return;
        }

        /* Add slot to item distribution */
        if (rightClickHoveredSlots.isEmpty()) {
            rightClickHoveredSlots.add(lastRMBSlot);
        }
        rightClickHoveredSlots.add(slot);

        /* Record how many items are in the slot */
        rightClickExistingAmount.add(slotItemToExamine != null ? slotItemToExamine.f_60602012 : 0);

        /* Distribute one item to the slot */
        lastRMBSlotId = slot.f_00184299;
        this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, slot.f_00184299, 1, false, this.f_78495264.f_28396371);
    }

    @Unique private boolean inventoryTweaks_cancelRightClickDrag(boolean isClientOnServer) {
        /* Cancel Right-click + Drag */
        if (!isRightClickDragStarted || rightClickHoveredSlots.size() <= 1) {
            return false;
        }

        /* Slots cannot return to normal on a server */
        if (!isClientOnServer) {
            /* Return all slots to normal */
            f_78495264.f_28396371.f_29439708.m_74385138(new C_88708284(rightClickPersistentStack.f_59294634, rightClickItemAmount, rightClickPersistentStack.m_30227787()));
            for (int i = 0; i < rightClickHoveredSlots.size(); i++) {
                int existing = rightClickExistingAmount.get(i);
                rightClickHoveredSlots.get(i).m_06487241(existing != 0
                        ? new C_88708284(rightClickPersistentStack.f_59294634, existing, rightClickPersistentStack.m_30227787())
                        : null);
            }
        }

        /* Reset Right-click + Drag variables and exit function */
        inventoryTweaks_resetRightClickDragVariables();
        return true;
    }

    @Unique private void inventoryTweaks_resetRightClickDragVariables() {
        rightClickExistingAmount.clear();
        rightClickHoveredSlots.clear();
        rightClickPersistentStack = null;
        rightClickItemAmount = 0;
        isRightClickDragStarted = false;
    }

    @Unique private boolean inventoryTweaks_handleLeftClickWithItem(C_88708284 cursorStack, C_12356698 clickedSlot, boolean isClientOnServer) {
        /* Ensure a slot was clicked */
        if (clickedSlot == null) {
            return false;
        }

        /* Record how many items are in the slot and how many items are needed to fill the slot */
        if (clickedSlot.m_96527510() != null) {
            if (cursorStack != null) {
                /* Let vanilla minecraft handle left click with an item onto any item */
                if (isClientOnServer) {
                    return false;
                }
                /* Let vanilla minecraft handle left click with an item onto a different item */
                if (!cursorStack.m_52048659(clickedSlot.m_96527510())) {
                    return false;
                }

                leftClickAmountToFillPersistent.add(cursorStack.m_02549920() - clickedSlot.m_96527510().f_60602012);
                leftClickExistingAmount.add(clickedSlot.m_96527510().f_60602012);
            }
        } else {
            leftClickAmountToFillPersistent.add(cursorStack.m_02549920());
            leftClickExistingAmount.add(0);
        }

        /* Begin Left-click + Drag */
        if (leftClickPersistentStack == null && !isLeftClickDragStarted) {
            leftClickPersistentStack = cursorStack;
            leftClickItemAmount = leftClickPersistentStack.f_60602012;
            isLeftClickDragStarted = true;
        }

        /* Handle initial Left-click */
        lastLMBSlotId = clickedSlot.f_00184299;
        lastLMBSlot = clickedSlot;
        if (PolishedClient.CONFIG.preferShiftLMB.get()) {
            boolean isShiftKeyDown = isShiftDown();
            this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, clickedSlot.f_00184299, 0, isShiftKeyDown, this.f_78495264.f_28396371);

            if (isShiftKeyDown) {
                inventoryTweaks_resetLeftClickDragVariables();
                leftClickMouseTweaksPersistentStack = cursorStack;
                isLeftClickDragMouseTweaksStarted = true;
            }
        } else {
            this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, clickedSlot.f_00184299, 0, false, this.f_78495264.f_28396371);
        }

        return true;
    }

    @Unique private boolean inventoryTweaks_handleLeftClickWithoutItem(C_12356698 clickedSlot) {
        isLeftClickDragMouseTweaksStarted = true;

        /* Ensure a slot was clicked */
        if (clickedSlot == null) {
            /* Get info for MouseTweaks `Left-Click + Drag` mechanics */
            leftClickMouseTweaksPersistentStack = null;
            return false;
        }

        /* Get info for MouseTweaks `Left-Click + Drag` mechanics */
        leftClickMouseTweaksPersistentStack = clickedSlot.m_96527510();

        /* Handle initial Left-click */
        lastLMBSlotId = clickedSlot.f_00184299;
        lastLMBSlot = clickedSlot;
        this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, clickedSlot.f_00184299, 0, isShiftDown(), this.f_78495264.f_28396371);

        return true;
    }

    @Unique private void inventoryTweaks_handleLeftClickDragMouseTweaks() {
        if (slot.f_00184299 == lastLMBSlotId) {
            return;
        }
        lastLMBSlotId = slot.f_00184299;

        C_88708284 slotItemToExamine = slot.m_96527510();
        if (slotItemToExamine == null) {
            return;
        }

        if (PolishedClient.CONFIG.shiftClickAnyLMB.get() && isShiftDown()) {
            this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, slot.f_00184299, 0, true, this.f_78495264.f_28396371);
        }

        if (leftClickMouseTweaksPersistentStack == null
                || !slotItemToExamine.m_52048659(leftClickMouseTweaksPersistentStack)) {
            return;
        }

        if (isShiftDown()) {
            if (PolishedClient.CONFIG.tweakLMBShiftClick.get()) {
                this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, slot.f_00184299, 0, true, this.f_78495264.f_28396371);
            }
            return;
        }

        if (!PolishedClient.CONFIG.tweakLMBPickUp.get()) {
            return;
        }

        C_88708284 cursorStack = f_78495264.f_28396371.f_29439708.m_54140007();

        if (cursorStack == null) {
            /* Pick up items from slot */
            this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, slot.f_00184299, 0, false, this.f_78495264.f_28396371);
        } else if (cursorStack.f_60602012 < leftClickMouseTweaksPersistentStack.m_02549920()) {
            int amountAbleToPickUp = leftClickMouseTweaksPersistentStack.m_02549920() - cursorStack.f_60602012;
            int amountInSlot = slotItemToExamine.f_60602012;

            /* Pick up items from slot */
            if (amountInSlot <= amountAbleToPickUp) {
                this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, slot.f_00184299, 0, false, this.f_78495264.f_28396371);
                this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, slot.f_00184299, 0, false, this.f_78495264.f_28396371);
            } else if (cursorStack.f_60602012 == leftClickMouseTweaksPersistentStack.m_02549920()) {
                slot.m_06487241(new C_88708284(leftClickMouseTweaksPersistentStack.f_59294634, cursorStack.f_60602012, leftClickMouseTweaksPersistentStack.m_30227787()));
                f_78495264.f_28396371.f_29439708.m_74385138(new C_88708284(leftClickMouseTweaksPersistentStack.f_59294634, amountInSlot, leftClickMouseTweaksPersistentStack.m_30227787()));
            } else {
                this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, slot.f_00184299, 0, false, this.f_78495264.f_28396371);

                slotItemToExamine = slot.m_96527510();
                cursorStack = f_78495264.f_28396371.f_29439708.m_54140007();
                amountInSlot = slotItemToExamine.f_60602012;

                slot.m_06487241(new C_88708284(leftClickMouseTweaksPersistentStack.f_59294634, cursorStack.f_60602012, leftClickMouseTweaksPersistentStack.m_30227787()));
                f_78495264.f_28396371.f_29439708.m_74385138(new C_88708284(leftClickMouseTweaksPersistentStack.f_59294634, amountInSlot, leftClickMouseTweaksPersistentStack.m_30227787()));
            }
        }
    }

    @Unique private boolean inventoryTweaks_handleLeftClickDrag() {
        /* Do nothing if slot has already been added to Left-click + Drag logic */
        if (leftClickHoveredSlots.contains(slot)) {
            return false;
        }

        C_88708284 slotItemToExamine = slot.m_96527510();
        boolean isClientOnServer = f_78495264.m_38583715();

        /* Do nothing if slot item does not match held item */
        if (slotItemToExamine != null) {
            if (isClientOnServer) {
                return true;
            }
            if (!slotItemToExamine.m_52048659(leftClickPersistentStack)) {
                return true;
            }
        }

        /* Do nothing if there are no more items to distribute */
        if ((double) leftClickItemAmount / (double) leftClickHoveredSlots.size() == 1.0) {
            return true;
        }

        /* First slot is handled instantly in mouseClicked function */
        if (slot.f_00184299 == lastLMBSlotId) {
            return false;
        }

        /* Add slot to item distribution */
        if (leftClickHoveredSlots.isEmpty()) {
            leftClickHoveredSlots.add(lastLMBSlot);
        }
        leftClickHoveredSlots.add(slot);

        /* Record how many items are in the slot and how many items are needed to fill the slot */
        if (slotItemToExamine != null) {
            leftClickAmountToFillPersistent.add(leftClickPersistentStack.m_02549920() - slotItemToExamine.f_60602012);
            leftClickExistingAmount.add(slotItemToExamine.f_60602012);
        } else {
            leftClickAmountToFillPersistent.add(leftClickPersistentStack.m_02549920());
            leftClickExistingAmount.add(0);
        }

        /* Slots cannot return to normal on a server */
        List<Integer> leftClickAmountToFill = new ArrayList<>();
        if (!isClientOnServer) {
            /* Return all slots to normal */
            f_78495264.f_28396371.f_29439708.m_74385138(new C_88708284(leftClickPersistentStack.f_59294634, leftClickItemAmount, leftClickPersistentStack.m_30227787()));
            for (int i = 0; i < leftClickHoveredSlots.size(); i++) {
                leftClickAmountToFill.add(leftClickAmountToFillPersistent.get(i));
                int existing = leftClickExistingAmount.get(i);
                leftClickHoveredSlots.get(i).m_06487241(existing != 0
                        ? new C_88708284(leftClickPersistentStack.f_59294634, existing, leftClickPersistentStack.m_30227787())
                        : null);
            }
        }

        /* Prepare to distribute over slots */
        int numberOfSlotsRemainingToFill = leftClickHoveredSlots.size();
        int itemsPerSlot = leftClickItemAmount / numberOfSlotsRemainingToFill;
        int leftClickRemainingItemAmount = leftClickItemAmount;
        boolean rerunLoop;

        /* Slots cannot return to normal on a server */
        if (!isClientOnServer) {
            /* Distribute fewer items to slots whose max stack size will be filled */
            do {
                rerunLoop = false;
                itemsPerSlot = leftClickRemainingItemAmount / numberOfSlotsRemainingToFill;

                if (itemsPerSlot != 0) {
                    for (int i = 0; i < leftClickAmountToFill.size(); i++) {
                        int toFill = leftClickAmountToFill.get(i);
                        if (toFill != 0 && toFill < itemsPerSlot) {
                            /* Just fill the slot and return */
                            for (int fillIndex = 0; fillIndex < toFill; fillIndex++) {
                                this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, leftClickHoveredSlots.get(i).f_00184299, 1, false, this.f_78495264.f_28396371);
                            }

                            leftClickRemainingItemAmount -= toFill;
                            leftClickAmountToFill.set(i, 0);
                            numberOfSlotsRemainingToFill--;
                            rerunLoop = true;
                        }
                    }
                }
            } while (rerunLoop && numberOfSlotsRemainingToFill > 0);
        } else {
            /* Return slots to normal on when client is on a server */
            for (int i = 0; i < leftClickHoveredSlots.size() - 1; i++) {
                if (leftClickHoveredSlots.get(i).m_66326040() && leftClickHoveredSlots.size() > 1) {
                    if (f_78495264.f_28396371.f_29439708.m_54140007() != null) {
                        this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, leftClickHoveredSlots.get(i).f_00184299, 0, false, this.f_78495264.f_28396371);
                    }
                    this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, leftClickHoveredSlots.get(i).f_00184299, 0, false, this.f_78495264.f_28396371);
                }
            }
        }

        /* Distribute remaining items evenly over remaining slots that were not already filled to max stack size */
        for (int i = 0; i < leftClickHoveredSlots.size(); i++) {
            int remainingToFill = isClientOnServer ? leftClickAmountToFillPersistent.get(i) : leftClickAmountToFill.get(i);
            if (remainingToFill != 0) {
                for (int addIndex = 0; addIndex < itemsPerSlot; addIndex++) {
                    this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, leftClickHoveredSlots.get(i).f_00184299, 1, false, this.f_78495264.f_28396371);
                }
            }
        }

        return false;
    }

    @Unique private boolean inventoryTweaks_cancelLeftClickDrag(boolean isClientOnServer) {
        /* Cancel Left-click + Drag */
        if (!isLeftClickDragStarted || leftClickHoveredSlots.size() <= 1) {
            return false;
        }

        /* Check if client is running on a server or not */
        if (!isClientOnServer) {
            /* Return all slots to normal */
            f_78495264.f_28396371.f_29439708.m_74385138(new C_88708284(leftClickPersistentStack.f_59294634, leftClickItemAmount, leftClickPersistentStack.m_30227787()));
            for (int i = 0; i < leftClickHoveredSlots.size(); i++) {
                int existing = leftClickExistingAmount.get(i);
                leftClickHoveredSlots.get(i).m_06487241(existing != 0
                        ? new C_88708284(leftClickPersistentStack.f_59294634, existing, leftClickPersistentStack.m_30227787())
                        : null);
            }
        } else {
            /* Return slots to normal on when client is on a server */
            for (int i = 0; i < leftClickHoveredSlots.size() - 1; i++) {
                if (leftClickHoveredSlots.get(i).m_66326040() && leftClickHoveredSlots.size() > 1) {
                    if (f_78495264.f_28396371.f_29439708.m_54140007() != null) {
                        this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, leftClickHoveredSlots.get(i).f_00184299, 0, false, this.f_78495264.f_28396371);
                    }
                    this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, leftClickHoveredSlots.get(i).f_00184299, 0, false, this.f_78495264.f_28396371);
                }
            }
            int lastIndex = leftClickHoveredSlots.size() - 1;
            this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, leftClickHoveredSlots.get(lastIndex).f_00184299, 0, false, this.f_78495264.f_28396371);
            this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, leftClickHoveredSlots.get(lastIndex).f_00184299, 0, false, this.f_78495264.f_28396371);
        }

        /* Reset Left-click + Drag variables and exit function */
        inventoryTweaks_resetLeftClickDragVariables();
        return true;
    }

    @Unique private void inventoryTweaks_resetLeftClickDragVariables() {
        leftClickExistingAmount.clear();
        leftClickAmountToFillPersistent.clear();
        leftClickHoveredSlots.clear();
        leftClickPersistentStack = null;
        leftClickMouseTweaksPersistentStack = null;
        leftClickItemAmount = 0;
        isLeftClickDragStarted = false;
        isLeftClickDragMouseTweaksStarted = false;
    }

    @Unique
    private boolean inventoryTweaks_isItemInSlot(C_88708284 itemStack, C_12356698 slotToCheck) {
        C_88708284 slotStack = slotToCheck.m_96527510();

        if (null == slotStack) {
            /* Slot does not have item */
            return false;
        } else return itemStack.m_52048659(slotStack);
    }

    @Unique
    private int inventoryTweaks_canItemFitInSlot(C_88708284 itemStack, C_12356698 slotToCheck) {
        C_88708284 slotStack = slotToCheck.m_96527510();

        if (null == slotStack) {
            /* Slot is open */
            return 1;
        } else if (itemStack.m_52048659(slotStack)) {
            if (slotStack.f_60602012 == slotStack.m_02549920()) {
                /* Slot is taken */
                return -1;
            } else {
                /* Slot is partially empty and item matches */
                return 0;
            }
        }

        /* Slot is taken */
        return -1;
    }

    @Inject(method = "renderSlot", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/ItemRenderer;renderGuiItemWithEnchantmentGlint(Lnet/minecraft/client/render/TextRenderer;Lnet/minecraft/client/render/texture/TextureManager;Lnet/minecraft/item/ItemStack;II)V"))
    private void inventoryTweaks_renderSlot(C_12356698 slot, CallbackInfo ci) {
        if (this.inventoryTweaks_isDisabled() || !PolishedClient.CONFIG.dragGraphics.get()) {
            return;
        }

        if (rightClickHoveredSlots.contains(slot) || leftClickHoveredSlots.contains(slot)) {
            m_57734177(slot.f_95205544, slot.f_40293340, slot.f_95205544 + 16, slot.f_40293340 + 16, -2130706433);
        }
    }

    @Inject(method = "keyPressed", at = @At("RETURN"))
    private void inventoryTweaks_keyPressed(char chr, int key, CallbackInfo ci) {
        if (this.inventoryTweaks_isDisabled()) return;

        if (this.slot == null) {
            return;
        }

        if (PolishedClient.CONFIG.dropKeyInv.get() && key == Minecraft.f_33079084.f_58088711.f_53542110.f_57264828) {
            if (this.f_78495264.f_28396371.f_29439708.m_54140007() != null) {
                return;
            }

            this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, slot.f_00184299, 0, false, this.f_78495264.f_28396371);
            int dropButton = PolishedClient.CONFIG.ctrlDropStack.get() && Keyboard.isKeyDown(Keyboard.KEY_LCONTROL) ? 0 : 1;
            this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, -999, dropButton, false, this.f_78495264.f_28396371);
            this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, slot.f_00184299, 0, false, this.f_78495264.f_28396371);
        }

        if (PolishedClient.CONFIG.hotkeySwap.get()) {
            for (int i = 1; i < 10; i++) {
                int keyCode = PolishedClient.INSTANCE.keyBindingHandler.getKeyFromCode(i + 1);
                if (keyCode == key) {
                    int s = (this.menu.f_84566804.size() - 10) + i;
                    if (FabricLoader.getInstance().isModLoaded("creative")) {
                        s = CreativeIntegration.getSlot((C_87711245) (Object) this, s);
                    }

                    if (this.f_78495264.f_28396371.f_29439708.m_54140007() == null) {
                        this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, slot.f_00184299, 0, false, this.f_78495264.f_28396371);
                    }
                    this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, s, 0, false, this.f_78495264.f_28396371);
                    this.f_78495264.f_17639899.m_01117962(this.menu.f_66294390, slot.f_00184299, 0, false, this.f_78495264.f_28396371);
                }
            }
        }
    }

    @Unique
    private boolean inventoryTweaks_isDisabled() {
        return !PolishedClient.CONFIG.enableInventoryTweaks.get() || !this.enabled;
    }

    @Override
    public void inventoryTweaks_enableTweaks(boolean b) {
        this.enabled = b;
    }
}
