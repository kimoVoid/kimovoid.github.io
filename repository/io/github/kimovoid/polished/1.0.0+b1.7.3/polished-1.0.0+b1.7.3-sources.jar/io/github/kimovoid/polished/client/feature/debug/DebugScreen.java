package io.github.kimovoid.polished.client.feature.debug;

import io.github.kimovoid.polished.client.event.RenderEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_16154270;
import net.minecraft.unmapped.C_23014920;
import net.minecraft.unmapped.C_24654288;
import net.minecraft.unmapped.C_43718703;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_92766678;
import net.ornithemc.osl.branding.api.BrandingContext;
import net.ornithemc.osl.branding.impl.BrandingPatchImpl;
import org.lwjgl.Sys;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import oshi.SystemInfo;
import oshi.hardware.CentralProcessor;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class DebugScreen {

    public static final DebugScreen INSTANCE = new DebugScreen();
    private String cpuInfo;

    public void init() {
        try {
            CentralProcessor cpu = new SystemInfo().getHardware().getProcessor();
            this.cpuInfo = String.format("%dx %s", cpu.getLogicalProcessorCount(), cpu.getProcessorIdentifier().getName()).replaceAll("\\s+", " ");
        } catch (Throwable ignored) {
        }
    }

    public void renderLeft(Minecraft mc) {
        int x = C_45510667.m_80489169(mc.f_28396371.f_78826675);
        int y = C_45510667.m_80489169(mc.f_28396371.f_31030949);
        int z = C_45510667.m_80489169(mc.f_28396371.f_97691941);
        int chunkX = x >> 4;
        int chunkZ = z >> 4;
        long time = C_45510667.m_80489169((double) (mc.f_26407825.m_13949261() / 24000L));
        String biome = mc.f_26407825.m_72354999().m_16975905(x, z).f_53376351;
        float angle = (mc.f_26407825.m_15038091(1.0F) * 24.0F + 12.0F) % 24.0F;
        int h = (int) Math.floor(angle);
        int m = (int) Math.floor(angle * 60.0F) - h * 60;
        int s = (int) Math.floor(angle * 3600.0F) - h * 3600 - m * 60;
        int f = (C_45510667.m_80489169((double) (mc.f_28396371.f_80130373 * 4.0f / 360.0f) + 0.5) & 3);
        String facing = f == 0 ? "west (Towards positive Z)"
                : f == 1 ? "north (Towards negative X)"
                  : f == 2 ? "east (Towards negative Z)"
                    : "south (Towards positive X)";

        /* Add lines */
        List<String> lines = new ArrayList<>();
        String version = getVersion();
        lines.add(String.format("Minecraft %s (%s%s)", getVersionPrefixed(), version, BrandingPatchImpl.apply(BrandingContext.TITLE_SCREEN, "")));
        lines.add(mc.f_97146310);
        lines.add(mc.m_86695868());
        lines.add(mc.m_94228601());
        lines.add(mc.m_74473474());
        lines.add(mc.m_86790624());
        lines.add("");
        lines.add(String.format("XYZ: %.3f / %.3f / %.3f", mc.f_28396371.f_78826675, mc.f_28396371.f_31030949, mc.f_28396371.f_97691941));
        lines.add(String.format("Block: %s %s %s", x, y, z));
        lines.add(String.format("Facing: %s (%.1f / %.1f)", facing, this.wrapDegrees(mc.f_28396371.f_80130373), this.wrapDegrees(mc.f_28396371.f_03549461)));
        lines.add("Chunk: " + String.format("%s, %s [%s, %s]", chunkX, chunkZ, x & 15, z & 15));
        lines.add("");
        lines.add(String.format("Light: %s (bl: %s, sky: %s)", mc.f_26407825.m_53002591(x, y, z), mc.f_26407825.m_15475075(C_92766678.f_19924308, x, y, z), mc.f_26407825.m_15475075(C_92766678.f_02629467, x, y, z)));
        lines.add("Biome: " + (biome == null ? "Unknown" : biome));
        lines.add("Day: " + time);
        lines.add("Time: " + String.format("%02d:%02d:%02d", h, m, s));
        lines.add("Slime: " + this.isSlimeChunk(mc.f_26407825.m_92966154(), mc.f_28396371.f_04365121, mc.f_28396371.f_49167582));

        /* Call event so mods can add/remove lines */
        RenderEvents.DebugRenderEvent event = new RenderEvents.DebugRenderEvent(RenderEvents.DebugSide.LEFT, lines);
        RenderEvents.RENDER_DEBUG.invoker().accept(event);

        /* Render lines */
        for (int i = 0; i < event.getLines().size(); i++) {
            this.renderText(event.getLines().get(i), 2, 2 + i * 9);
        }
    }

    public void renderRight(Minecraft mc) {
        C_43718703 window = new C_43718703(mc.f_58088711, mc.f_31800787, mc.f_74192110);
        int width = window.m_39119333();
        C_23014920 tr = mc.f_21497584;

        long maxMem = Runtime.getRuntime().maxMemory();
        long totalMem = Runtime.getRuntime().totalMemory();
        long freeMem = Runtime.getRuntime().freeMemory();
        long usedMem = totalMem - freeMem;

        /* Add lines */
        List<String> lines = new ArrayList<>();
        lines.add(String.format("Java: %s %sbit", System.getProperty("java.version"), System.getProperty("sun.arch.data.model")));
        lines.add("Mem: " + usedMem * 100L / maxMem + "% (" + usedMem / 1024L / 1024L + "MB) of " + maxMem / 1024L / 1024L + "MB");
        lines.add("Allocated: " + totalMem * 100L / maxMem + "% (" + totalMem / 1024L / 1024L + "MB)");
        lines.add("LWJGL " + Sys.getVersion());
        lines.add("");

        if (this.cpuInfo != null) {
            lines.add(String.format("CPU: %s", this.cpuInfo));
            lines.add("");
        }
        lines.add(String.format("Display: %dx%d (%s)", Display.getWidth(), Display.getHeight(), GL11.glGetString(7936)));
        lines.add(GL11.glGetString(7937));
        lines.add(GL11.glGetString(7938));
        if (mc.f_26407825 != null && mc.f_81460813 != null && mc.f_81460813.f_92820457 == C_24654288.net/minecraft/unmapped/C_25850426.f_13890456) {
            int id = mc.f_26407825.m_33234383(mc.f_81460813.f_79497105, mc.f_81460813.f_09533029, mc.f_81460813.f_04223298);
            int meta = mc.f_26407825.m_06541281(mc.f_81460813.f_79497105, mc.f_81460813.f_09533029, mc.f_81460813.f_04223298);
            C_88708284 stack = new C_88708284(id, 1, meta);
            String name = C_16154270.m_56062593().m_36441695(stack.m_27822537()).trim();

            lines.add("");
            lines.add(String.format("Looking at: %s, %s, %s", mc.f_81460813.f_79497105, mc.f_81460813.f_09533029, mc.f_81460813.f_04223298));
            lines.add(String.format("%s (#%s%s)", name.isEmpty() ? stack.m_27822537() : name, stack.f_59294634, stack.m_21098843() != 0 && !stack.m_39273794() ? "/" + stack.m_21098843() : ""));
        }

        /* Call event so mods can add/remove lines */
        RenderEvents.DebugRenderEvent event = new RenderEvents.DebugRenderEvent(RenderEvents.DebugSide.RIGHT, lines);
        RenderEvents.RENDER_DEBUG.invoker().accept(event);

        /* Render lines */
        for (int i = 0; i < event.getLines().size(); i++) {
            String line = event.getLines().get(i);
            this.renderText(line, width - tr.m_09235706(line) - 1, 2 + i * 9);
        }
    }

    private boolean isSlimeChunk(long seed, int x, int z) {
        Random rnd = new Random(
                seed +
                        (int) (x * x * 0x4c1906) +
                        (int) (x * 0x5ac0db) +
                        (int) (z * z) * 0x4307a7L +
                        (int) (z * 0x5f24f) ^ 0x3ad8025fL
        );

        return rnd.nextInt(10) == 0;
    }

    private void renderText(String text, int x, int y) {
        if (text.isEmpty()) {
            return;
        }
        Minecraft.f_33079084.f_28235293.m_58083806(x - 1, y - 1, x + Minecraft.f_33079084.f_21497584.m_09235706(text), y + 8, -1873784752, -1873784752);
        Minecraft.f_33079084.f_21497584.m_72964882(text, x, y, 0xE0E0E0);
    }

    private float wrapDegrees(float degrees) {
        if ((degrees %= 360.0f) >= 180.0f) {
            degrees -= 360.0f;
        }
        if (degrees < -180.0f) {
            degrees += 360.0f;
        }
        return degrees;
    }

    private String getVersion() {
        String version = FabricLoader.getInstance()
                .getModContainer("minecraft")
                .get()
                .getMetadata()
                .getVersion()
                .getFriendlyString();

        if (version.startsWith("1.0.0-alpha.")) {
            return "a1." + version.substring(12);
        } else if (version.startsWith("1.0.0-beta.")) {
            return "b1." + version.substring(11);
        } else if (version.equals("1.0.0")) {
            return "1.0";
        }

        return version;
    }

    private String getVersionPrefixed() {
        String version = getVersion();
        return version.startsWith("b") ? "Beta " + version.substring(1) : version.startsWith("a") ? "Alpha " + version.substring(1) : version;
    }
}
