package io.github.kimovoid.polished.client.feature.zoom;

import io.github.kimovoid.polished.client.PolishedClient;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_54930763;
import org.lwjgl.input.Keyboard;

public class Zoom {

    public static final Zoom INSTANCE = new Zoom();

    public boolean active = false;
    private float originalSensitivity;
    private boolean originalSmoothCamera;
    private float targetFactor = 1;
    private float divisor;
    private float lastAnimatedFactor = 1;
    private float animatedFactor = 1;

    public float getFov(float current, float tickDelta) {
        return current * (PolishedClient.CONFIG.zoomSpeed.get() == 10 ? targetFactor : this.lerp(tickDelta, lastAnimatedFactor, animatedFactor));
    }

    public void update() {
        if (shouldStart()) {
            start();
        } else if (shouldStop()) {
            stop();
        }
    }

    private boolean shouldStart() {
        return keyHeld() && !active;
    }

    private void start() {
        active = true;
        setDivisor(PolishedClient.CONFIG.zoomDivisor.get());
        setOptions();
    }

    private boolean shouldStop() {
        return !keyHeld() && active;
    }

    private void stop() {
        active = false;
        targetFactor = 1;
        restoreOptions();
    }

    private boolean keyHeld() {
        return Minecraft.f_33079084.f_70816363 == null && Keyboard.isKeyDown(PolishedClient.INSTANCE.keyBindingHandler.getKeyByName("key.zoom", Keyboard.KEY_C));
    }

    private void setDivisor(float value) {
        divisor = value;
        targetFactor = 1F / value;
    }

    public void setOptions() {
        originalSensitivity = Minecraft.f_33079084.f_58088711.f_92231362;

        if (PolishedClient.CONFIG.smoothCamera.get()) {
            originalSmoothCamera = Minecraft.f_33079084.f_58088711.f_49392766;
            Minecraft.f_33079084.f_58088711.f_49392766 = true;

            // reset these so the previous smooth camera movement isn't applied
            Minecraft.f_33079084.f_19113424.f_03716156 = new C_54930763();
            Minecraft.f_33079084.f_19113424.f_52160030 = new C_54930763();
        }

        updateSensitivity();
    }

    public void restoreOptions() {
        Minecraft.f_33079084.f_58088711.f_92231362 = originalSensitivity;
        Minecraft.f_33079084.f_58088711.f_49392766 = originalSmoothCamera;
    }

    private void updateSensitivity() {
        if (PolishedClient.CONFIG.decreaseSensitivity.get()) {
            Minecraft.f_33079084.f_58088711.f_92231362 = originalSensitivity / (divisor * divisor);
        }
    }

    public boolean scroll(double amount) {
        if (active && PolishedClient.CONFIG.zoomScrolling.get() && amount != 0) {
            setDivisor((float) Math.max(1, divisor + (amount / Math.abs(amount))));
            updateSensitivity();
            return true;
        }

        return false;
    }

    private float lerp(float delta, float start, float end) {
        return start + delta * (end - start);
    }

    public void tick() {
        lastAnimatedFactor = animatedFactor;
        animatedFactor += (targetFactor - animatedFactor) * (PolishedClient.CONFIG.zoomSpeed.get() / 10F);
    }
}
