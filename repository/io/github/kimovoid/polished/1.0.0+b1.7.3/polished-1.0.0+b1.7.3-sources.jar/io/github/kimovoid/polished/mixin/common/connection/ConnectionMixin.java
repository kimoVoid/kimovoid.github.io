package io.github.kimovoid.polished.mixin.common.connection;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;
import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_10918870;
import net.minecraft.unmapped.C_39588828;

@Mixin(C_39588828.class)
public abstract class ConnectionMixin {

    @Shadow private Thread reader;
    @Shadow private Thread writer;
    @Shadow public boolean closed;
    @Unique private final Object writeLock = new Object();

    @Inject(method = "<init>", at = @At(value = "INVOKE", target = "Ljava/net/Socket;setTrafficClass(I)V", shift = At.Shift.AFTER))
    private void enableTcpNoDelay(Socket socket, String name, C_10918870 listener, CallbackInfo ci) {
        try {
            socket.setTcpNoDelay(true);
        } catch (SocketException ignored) {
        }
    }

    @Inject(method = "<init>", at = @At(value = "INVOKE", target = "Ljava/lang/Thread;start()V", ordinal = 0))
    private void replaceThreads(Socket socket, String name, C_10918870 listener, CallbackInfo ci) {
        C_39588828 self = (C_39588828) (Object) this;
        this.reader = new Thread(name + " read thread") {
            public void run() {
                synchronized (C_39588828.f_25799151) {
                    C_39588828.f_92997202++;
                }

                try {
                    while (self.f_56968861 && !self.f_37315414) {
                        while (self.m_36456399()) {
                        }

                        try {
                            sleep(5L);
                        } catch (InterruptedException ignored) {
                        }
                    }
                } finally {
                    synchronized (C_39588828.f_25799151) {
                        C_39588828.f_92997202--;
                    }
                }
            }
        };

        this.writer = new Thread(name + " write thread") {
            public void run() {
                synchronized (C_39588828.f_25799151) {
                    C_39588828.f_82334857++;
                }

                try {
                    while (self.f_56968861) {
                        boolean wroteSomething = false;
                        while (self.m_29036195()) {
                            wroteSomething = true;
                        }

                        if (wroteSomething) {
                            try {
                                if (self.f_84544661 != null) {
                                    self.f_84544661.flush();
                                }
                            } catch (IOException ex) {
                                if (!self.f_31864784) {
                                    self.m_99156894(ex);
                                }
                            }
                        }

                        synchronized (writeLock) {
                            if (self.f_93461034.isEmpty() && self.f_03910228.isEmpty()) {
                                try {
                                    writeLock.wait(50L);
                                } catch (InterruptedException ignored) {
                                }
                            }
                        }
                    }
                } finally {
                    synchronized (C_39588828.f_25799151) {
                        C_39588828.f_82334857--;
                    }
                }
            }
        };
    }

    @Inject(method = "send", at = @At("TAIL"))
    private void wakeWriter(C_03562565 packet, CallbackInfo ci) {
        if (!this.closed) {
            synchronized (this.writeLock) {
                this.writeLock.notifyAll();
            }
        }
    }
}
