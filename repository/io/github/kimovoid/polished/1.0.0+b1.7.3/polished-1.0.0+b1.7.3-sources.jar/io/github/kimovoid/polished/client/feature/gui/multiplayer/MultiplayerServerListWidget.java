package io.github.kimovoid.polished.client.feature.gui.multiplayer;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_16154270;
import net.minecraft.unmapped.C_76575783;
import net.minecraft.unmapped.C_96603444;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

public class MultiplayerServerListWidget extends C_76575783 {

    private final MultiplayerScreen parent;
    private int mouseX;
    private int mouseY;

    public MultiplayerServerListWidget(MultiplayerScreen parent) {
        super(parent.getMinecraft(), parent.f_05230747, parent.f_07021018, 32, parent.f_07021018 - 64, 36);
        this.parent = parent;
    }

    @Override
    public void m_60498464(int mouseX, int mouseY, float tickDelta) {
        super.m_60498464(mouseX, mouseY, tickDelta);
        this.mouseX = mouseX;
        this.mouseY = mouseY;
    }

    @Override
    protected int m_87897431() {
        return this.parent.getServersList().size();
    }

    @Override
    protected void m_07503748(int slot, boolean doubleClick) {
        this.parent.selectServer(slot, doubleClick);
    }

    @Override
    protected boolean m_62450030(int i) {
        return i == this.parent.getServersList().indexOf(this.parent.getSelectedServer());
    }

    @Override
    protected int m_40144889() {
        return this.parent.getServersList().size() * 36;
    }

    @Override
    protected void m_73025081() {
        this.parent.m_34695786();
    }

    @Override
    protected void m_41486279(int index, int x, int y, int l, C_96603444 arg) {
        ServerData server = this.parent.getServersList().get(index);
        this.parent.m_62884682(this.parent.getFontRenderer(), server.name, x + 2, y + 1, 0xffffff);
        if (!server.showIp) {
            C_16154270 translations = C_16154270.m_56062593();
            String hideIp = "(" + translations.m_77288988("multiplayer.hidden") + ")";
            this.parent.m_62884682(this.parent.getFontRenderer(), hideIp, x + 2, y + 23, 0x303030);
        } else {
            this.parent.m_62884682(this.parent.getFontRenderer(), server.ip, x + 2, y + 23, 0x303030);
        }

        if (server.canPing) {
            Object lock = parent.lock;
            synchronized (lock) {
                if (parent.serverCount < 5 && !server.isLoaded) {
                    server.isLoaded = true;
                    server.ping = -2L;
                    server.description = "";
                    server.onlinePlayers = "";
                    parent.serverCount++;
                    new Thread(() -> {
                        long currTime = System.nanoTime();
                        try {
                            server.description = "§8Polling...";
                            parent.pingServer(server);
                            long afterTime = System.nanoTime();
                            server.ping = ((afterTime - currTime) / 1000000L) / 2L;
                        } catch (UnknownHostException unknownHostException) {
                            server.ping = -1L;
                            server.description = "§4Can't resolve hostname";
                        } catch (SocketTimeoutException | ConnectException socketTimeoutException) {
                            server.ping = -1L;
                            server.description = "§4Can't reach server";
                        } catch (IOException iOException) {
                            server.description = "§7Server online!";
                            long afterTime = System.nanoTime();
                            server.ping = ((afterTime - currTime) / 1000000L) / 2L;
                        } catch (Exception exception) {
                            server.ping = -1L;
                            server.description = "ERROR: " + exception.getClass();
                        } finally {
                            Object lock1 = parent.lock;
                            synchronized (lock1) {
                                parent.serverCount--;
                            }
                        }
                    }).start();
                }
            }

            this.parent.m_62884682(this.parent.getFontRenderer(), server.description, x + 2, y + 12, 0x808080);
            if (!server.description.equals("§7Server online!")) {
                this.parent.m_62884682(this.parent.getFontRenderer(), server.onlinePlayers, x + 215 - this.parent.getFontRenderer().m_09235706(server.onlinePlayers), y + 12, 0x808080);
            }

            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            Minecraft.f_33079084.f_45465196.m_72568250(Minecraft.f_33079084.f_45465196.m_33729172("/assets/polished/textures/tablist/icons.png"));

            int shiftX = 0;
            int shiftY;
            String tooltipText;

            if (server.isLoaded && server.ping != -2L) {
                shiftY = server.ping < 0L ? 5 : (server.ping < 150L ? 0 : (server.ping < 300L ? 1 : (server.ping < 600L ? 2 : (server.ping < 1000L ? 3 : 4))));
                tooltipText = server.ping < 0L ? "(no connection)" : server.ping + "ms";
            } else {
                shiftX = 1;
                shiftY = (int)(System.currentTimeMillis() / 100L + (index * 2L) & 7L);
                if (shiftY > 4) {
                    shiftY = 8 - shiftY;
                }
                tooltipText = "Polling...";
            }

            Minecraft.f_33079084.f_28235293.m_66359748(x + 205, y, shiftX * 10, 176 + shiftY * 8, 10, 8);
            if (this.mouseX >= x + 205 - 4 && this.mouseY >= y - 4 && this.mouseX <= x + 205 + 10 + 4 && this.mouseY <= y + 8 + 4) {
                parent.tooltipText = tooltipText;
            }
        }
    }
}