package io.github.kimovoid.polished.mixin.client.multiplayerfootsteps;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_64041439;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Environment(EnvType.CLIENT)
@Mixin(C_42232651.class)
public class EntityMixin {

    @Shadow public C_64041439 world;
    @Shadow public double x;
    @Shadow public double prevX;
    @Shadow public double z;
    @Shadow public double prevZ;

    @Shadow private int blocksWalkedOn;
    @Shadow public float walkDistance;

    @ModifyArg(
            method = "move",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/util/math/MathHelper;sqrt(D)F"
            )
    )
    private double fixMultiplayerVelocity(double orig) {
        if (this.world.f_50876584) {
            double x = this.x - this.prevX;
            double z = this.z - this.prevZ;
            return x * x + z * z;
        }
        return orig;
    }

    @WrapOperation(
            method = "move",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/entity/Entity;blocksWalkedOn:I",
                    opcode = Opcodes.PUTFIELD
            )
    )
    private void fixDistance(C_42232651 instance, int value, Operation<Void> original) {
        this.blocksWalkedOn = C_45510667.m_44742066(this.walkDistance) + 1;
    }
}
