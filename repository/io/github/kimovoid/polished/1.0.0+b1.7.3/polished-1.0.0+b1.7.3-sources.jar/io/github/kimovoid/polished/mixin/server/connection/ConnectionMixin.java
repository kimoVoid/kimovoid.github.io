package io.github.kimovoid.polished.mixin.server.connection;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.kimovoid.polished.server.PolishedServer;
import io.github.kimovoid.polished.server.feature.connection.ExtendedConnectionListener;
import io.github.kimovoid.polished.server.feature.ping.PingHostHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_10918870;
import net.minecraft.unmapped.C_28851891;
import net.minecraft.unmapped.C_39588828;
import net.minecraft.unmapped.C_99660737;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.net.Socket;
import java.util.List;

@Environment(EnvType.SERVER)
@Mixin(C_39588828.class)
public class ConnectionMixin {

    @Shadow private C_10918870 listener;
    @Shadow private boolean open;
    @Shadow private Socket socket;

    @WrapOperation(method = "read", at = @At(value = "INVOKE", target = "Ljava/util/List;add(Ljava/lang/Object;)Z", remap = false))
    private boolean handlePingHost(List<C_03562565> list, Object obj, Operation<Boolean> original) {
        if (obj instanceof C_28851891) {
            C_99660737 networkHandler = (C_99660737) this.listener;
            ((PingHostHandler)networkHandler).handlePingHost((C_28851891) obj);
            return false;
        }
        return original.call(list, obj);
    }

    @Inject(method = "close*", at = @At("HEAD"))
    public void removeAddress(CallbackInfo ci) {
        if (this.open) {
            ((ExtendedConnectionListener) PolishedServer.SERVER.f_18767880).close(this.socket);
        }
    }
}
