package io.github.kimovoid.polished.mixin.client.multiplayerscreen;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.kimovoid.polished.client.feature.gui.multiplayer.MultiplayerScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_19869088;
import net.minecraft.unmapped.C_43496149;
import net.minecraft.unmapped.C_85740840;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin({C_19869088.class, C_43496149.class})
public class ReturnToMainMenuMixin {

    @WrapOperation(method = "buttonClicked", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Minecraft;openScreen(Lnet/minecraft/client/gui/screen/Screen;)V"))
    private void redirectSetScreen(Minecraft instance, C_85740840 screen, Operation<Void> original) {
        instance.m_52715402(new MultiplayerScreen());
    }
}
