package io.github.kimovoid.polished.mixin.common.ghast;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.unmapped.C_00242893;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_58653554;
import net.minecraft.unmapped.C_64041439;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(C_58653554.class)
public abstract class GhastEntityMixin extends C_00242893 {

    public GhastEntityMixin(C_64041439 world) {
        super(world);
    }

    @WrapOperation(method = "aiTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/mob/monster/GhastEntity;canSee(Lnet/minecraft/entity/Entity;)Z"))
    private boolean fixGhasts(C_58653554 instance, C_42232651 entity, Operation<Boolean> original) {
        return original.call(instance, entity) && !this.m_64566061();
    }
}
