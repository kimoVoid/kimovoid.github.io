package io.github.kimovoid.polished.mixin.client.debug;

import io.github.kimovoid.polished.client.PolishedClient;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_24384787;
import net.minecraft.unmapped.C_57778754;
import net.minecraft.unmapped.C_96603444;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_24384787.class)
public class WorldRendererMixin {

    @Inject(method = "renderLastChunks", at = @At("TAIL"))
    private void renderChunkBorders(int layer, double tickDelta, CallbackInfo ci) {
        if (!PolishedClient.INSTANCE.debugOptions.renderChunkBorders) {
            return;
        }

        C_57778754 player = Minecraft.f_33079084.f_28396371;
        double dX = player.f_09368719 + (player.f_78826675 - player.f_09368719) * tickDelta;
        double dY = player.f_93723721 + (player.f_31030949 - player.f_93723721) * tickDelta;
        double dZ = player.f_84066837 + (player.f_97691941 - player.f_84066837) * tickDelta;
        double bot = -dY;
        double top = 256D - dY;
        double cX = player.f_04365121 * 16 - dX;
        double cZ = player.f_49167582 * 16 - dZ;

        C_96603444 tessellator = C_96603444.f_99414865;
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        //GL11.glDisable(GL11.GL_BLEND);
        GL11.glLineWidth(1F);
        tessellator.m_89066829(GL11.GL_CURRENT_BIT | GL11.GL_POINT_BIT);

        for (int x = -16; x <= 32; x += 16) {
            for (int z = -16; z <= 32; z += 16) {
                tessellator.m_72833996(255, 0, 0, 0);
                tessellator.m_51994127(cX + x, bot, cZ + z);

                tessellator.m_72833996(255, 0, 0, 127);
                tessellator.m_51994127(cX + x, bot, cZ + z);
                tessellator.m_51994127(cX + x, top, cZ + z);

                tessellator.m_72833996(255, 0, 0, 0);
                tessellator.m_51994127(cX + x, top, cZ + z);
            }
        }

        for (int x = 2; x < 16; x += 2) {
            tessellator.m_72833996(255, 255, 0, 0);
            tessellator.m_51994127(cX + x, bot, cZ);

            tessellator.m_32764576(255, 255, 0);
            tessellator.m_51994127(cX + x, bot, cZ);
            tessellator.m_51994127(cX + x, top, cZ);

            tessellator.m_72833996(255, 255, 0, 0);
            tessellator.m_51994127(cX + x, top, cZ);
            tessellator.m_51994127(cX + x, bot, cZ + 16D);

            tessellator.m_32764576(255, 255, 0);
            tessellator.m_51994127(cX + x, bot, cZ + 16D);
            tessellator.m_51994127(cX + x, top, cZ + 16D);

            tessellator.m_72833996(255, 255, 0, 0);
            tessellator.m_51994127(cX + x, top, cZ + 16D);
        }

        for (int z = 2; z < 16; z += 2) {
            tessellator.m_72833996(255, 255, 0, 0);
            tessellator.m_51994127(cX, bot, cZ + z);

            tessellator.m_32764576(255, 255, 0);
            tessellator.m_51994127(cX, bot, cZ + z);
            tessellator.m_51994127(cX, top, cZ + z);

            tessellator.m_72833996(255, 255, 0, 0);
            tessellator.m_51994127(cX, top, cZ + z);
            tessellator.m_51994127(cX + 16D, bot, cZ + z);

            tessellator.m_32764576(255, 255, 0);
            tessellator.m_51994127(cX + 16D, bot, cZ + z);
            tessellator.m_51994127(cX + 16D, top, cZ + z);

            tessellator.m_72833996(255, 255, 0, 0);
            tessellator.m_51994127(cX + 16D, top, cZ + z);
        }

        for (int y = 0; y <= 256; y += 2) {
            double yLine = y - dY;
            tessellator.m_72833996(255, 255, 0, 0);
            tessellator.m_51994127(cX, yLine, cZ);

            tessellator.m_32764576(255, 255, 0);
            tessellator.m_51994127(cX, yLine, cZ);
            tessellator.m_51994127(cX, yLine, cZ + 16D);
            tessellator.m_51994127(cX + 16D, yLine, cZ + 16D);
            tessellator.m_51994127(cX + 16D, yLine, cZ);
            tessellator.m_51994127(cX, yLine, cZ);

            tessellator.m_72833996(255, 255, 0, 0);
            tessellator.m_51994127(cX, yLine, cZ);
        }

        tessellator.m_70070273();
        GL11.glLineWidth(2F);
        tessellator.m_89066829(GL11.GL_CURRENT_BIT | GL11.GL_POINT_BIT);

        for (int x = 0; x <= 16; x += 16) {
            for (int z = 0; z <= 16; z += 16) {
                tessellator.m_72833996(63, 63, 255, 0);
                tessellator.m_51994127(cX + x, bot, cZ + z);

                tessellator.m_32764576(63, 63, 255);
                tessellator.m_51994127(cX + x, bot, cZ + z);
                tessellator.m_51994127(cX + x, top, cZ + z);

                tessellator.m_72833996(63, 63, 255, 0);
                tessellator.m_51994127(cX + x, top, cZ + z);
            }
        }

        for (int y = 0; y <= 256; y += 16) {
            double yLine = y - dY;
            tessellator.m_72833996(63, 63, 255, 0);
            tessellator.m_51994127(cX, yLine, cZ);

            tessellator.m_32764576(63, 63, 255);
            tessellator.m_51994127(cX, yLine, cZ);
            tessellator.m_51994127(cX, yLine, cZ + 16D);
            tessellator.m_51994127(cX + 16D, yLine, cZ + 16D);
            tessellator.m_51994127(cX + 16D, yLine, cZ);
            tessellator.m_51994127(cX, yLine, cZ);

            tessellator.m_72833996(63, 63, 255, 0);
            tessellator.m_51994127(cX, yLine, cZ);
        }

        tessellator.m_70070273();
        GL11.glLineWidth(1F);
        //GL11.glEnable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
    }
}
