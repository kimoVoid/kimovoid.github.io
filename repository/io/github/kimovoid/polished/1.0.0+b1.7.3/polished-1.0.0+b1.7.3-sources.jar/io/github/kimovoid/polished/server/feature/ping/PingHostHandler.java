package io.github.kimovoid.polished.server.feature.ping;

import net.minecraft.unmapped.C_28851891;

public interface PingHostHandler {
    void handlePingHost(C_28851891 packet);
}
