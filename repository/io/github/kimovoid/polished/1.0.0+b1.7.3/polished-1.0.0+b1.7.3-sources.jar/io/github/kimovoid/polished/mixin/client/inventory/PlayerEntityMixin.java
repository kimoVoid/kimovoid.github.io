package io.github.kimovoid.polished.mixin.client.inventory;

import io.github.kimovoid.polished.client.PolishedClient;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_97929192;
import org.lwjgl.input.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({C_97929192.class, C_40996800.class})
public class PlayerEntityMixin {

    @Inject(method = "dropItem()V", at = @At("HEAD"), cancellable = true)
    private void inventoryTweaks_dropSelectedItem(CallbackInfo ci) {
        if (!PolishedClient.CONFIG.ctrlDropStack.get()) {
            return;
        }

        if (Keyboard.isKeyDown(Keyboard.KEY_LCONTROL)) {
            Minecraft.f_33079084.f_17639899.m_01117962(0, 36 + Minecraft.f_33079084.f_28396371.f_29439708.f_13682807, 0, false, Minecraft.f_33079084.f_28396371);
            Minecraft.f_33079084.f_17639899.m_01117962(0, -999, 0, false, Minecraft.f_33079084.f_28396371);
            ci.cancel();
        }
    }
}
