package io.github.kimovoid.polished.mixin.server.ping;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.kimovoid.polished.server.PolishedServer;
import io.github.kimovoid.polished.server.feature.ping.PingHostHandler;
import io.github.kimovoid.polished.server.feature.ping.PlayerPing;
import net.minecraft.unmapped.C_10918870;
import net.minecraft.unmapped.C_28851891;
import net.minecraft.unmapped.C_39588828;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_99660737;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_99660737.class)
public abstract class ServerPlayNetworkHandlerMixin implements PingHostHandler {

	@Shadow private C_49202226 player;
	@Shadow public C_39588828 connection;

	@Unique private int currentTick;
	@Unique private long pingHostTimeSent;
	@Unique private boolean receivedPingHost = true;
	@Unique private int lastPlayerInfoPacket;

	@WrapOperation(
			method = "<init>",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/network/Connection;setListener(Lnet/minecraft/network/PacketHandler;)V"
			)
	)
	private void redirect(C_39588828 instance, C_10918870 listener, Operation<Void> original) {
		if (connection != null) original.call(instance, listener);
	}

	@Inject(method = "tick", at = @At("HEAD"))
	public void injectTick(CallbackInfo ci) {
		this.currentTick++;
		this.lastPlayerInfoPacket++;

		if (this.lastPlayerInfoPacket >= 60) {
			PolishedServer.INSTANCE.sendPlayerInfo(this.player.f_59008391, true, ((PlayerPing)this.player).getPing());
			this.lastPlayerInfoPacket = 0;
		}

		if (this.currentTick >= 20) {
			this.currentTick = 0;
			if (!this.receivedPingHost) {
				return;
			}

			this.receivedPingHost = false;
			this.pingHostTimeSent = System.currentTimeMillis();
			this.connection.m_00234283(new C_28851891());
		}
	}

	@Inject(method = "onDisconnect(Ljava/lang/String;[Ljava/lang/Object;)V", at = @At("HEAD"))
	public void removeFromTab(CallbackInfo ci) {
		PolishedServer.INSTANCE.sendPlayerInfo(this.player.f_59008391, false, 0);
	}

	@Override
	public void handlePingHost(C_28851891 packet) {
		int ping = (int) (System.currentTimeMillis() - this.pingHostTimeSent);
		((PlayerPing)this.player).setPing(Math.max(ping, 0));
		this.receivedPingHost = true;
	}
}
