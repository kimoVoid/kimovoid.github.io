package io.github.kimovoid.polished.mixin.client.multiplayerfootsteps;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_54810664;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_54810664.class)
public abstract class RemoteClientPlayerEntityMixin extends C_40996800 {

    @Unique private int distanceOnNextBlock2;

    public RemoteClientPlayerEntityMixin(C_64041439 world) {
        super(world);
    }

    @Inject(
            method = "mobTick",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/client/entity/mob/player/RemoteClientPlayerEntity;lastBob:F",
                    opcode = Opcodes.PUTFIELD
            )
    )
    private void fixRemotePlayerFootsteps(CallbackInfo ci) {
        boolean sneaking = this.m_40164672();
        double veloX = this.f_78826675 - this.f_09368719;
        double veloZ = this.f_97691941 - this.f_84066837;

        if (this.m_24660344() && !sneaking && this.f_03824457 == null) {
            this.f_37851489 = (float)((double)this.f_37851489 + (double)C_45510667.m_14578936(veloX * veloX + veloZ * veloZ) * 0.6D);
            int x = C_45510667.m_80489169(this.f_78826675);
            int y = C_45510667.m_80489169(this.f_31030949 - (double)0.2F - (double)this.f_85480687);
            int z = C_45510667.m_80489169(this.f_97691941);
            int blockId = this.f_94306729.m_33234383(x, y, z);
            if (this.f_94306729.m_33234383(x, y - 1, z) == C_81592558.f_98928673.f_84602679) {
                blockId = this.f_94306729.m_33234383(x, y - 1, z);
            }

            if (this.f_37851489 > (float)this.distanceOnNextBlock2 && blockId > 0) {
                this.distanceOnNextBlock2 = C_45510667.m_44742066(this.f_37851489) + 1;
                C_81592558.net/minecraft/unmapped/C_01306377 sound = C_81592558.f_44428008[blockId].f_13889746;
                if (this.f_94306729.m_33234383(x, y + 1, z) == C_81592558.f_81695559.f_84602679) {
                    sound = C_81592558.f_81695559.f_13889746;
                    this.f_94306729.m_94717335(this, sound.m_48793905(), sound.m_48828997() * 0.15F, sound.m_35890820());
                } else if (!C_81592558.f_44428008[blockId].f_22724416.m_50164437()) {
                    this.f_94306729.m_94717335(this, sound.m_48793905(), sound.m_48828997() * 0.15F, sound.m_35890820());
                }

                C_81592558.f_44428008[blockId].m_25225777(this.f_94306729, x, y, z, this);
            }
        }
    }
}
