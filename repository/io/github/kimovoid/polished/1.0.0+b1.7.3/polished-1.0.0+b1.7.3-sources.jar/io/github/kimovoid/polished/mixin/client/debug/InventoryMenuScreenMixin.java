package io.github.kimovoid.polished.mixin.client.debug;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.kimovoid.polished.client.PolishedClient;
import net.minecraft.unmapped.C_12356698;
import net.minecraft.unmapped.C_16154270;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_87711245;
import net.minecraft.unmapped.C_88708284;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(C_87711245.class)
public abstract class InventoryMenuScreenMixin extends C_85740840 {

    @Shadow protected int backgroundWidth;
    @Shadow protected int backgroundHeight;
    @Shadow protected abstract C_12356698 getSlot(int x, int y);

    @WrapOperation(method = "render", at = @At(value = "INVOKE", target = "Ljava/lang/String;length()I"))
    private int replaceTooltip(String instance, Operation<Integer> original, int mouseX, int mouseY) {
        if (PolishedClient.INSTANCE.debugOptions.showAdvancedTooltips && !instance.isEmpty()) {
            C_12356698 slot = getSlot(mouseX, mouseY);
            if (slot == null || slot.m_96527510() == null) {
                return 0; // not gonna happen but ide cries
            }

            C_88708284 stack = slot.m_96527510();
            String name = C_16154270.m_56062593().m_36441695(stack.m_27822537()).trim()
                    + String.format(" (#%s%s)", stack.f_59294634, stack.m_21098843() != 0 && !stack.m_39273794() ? "/" + stack.m_21098843() : "");
            String dur = !stack.m_39273794() ? "" : String.format("Durability: %s/%s", stack.m_74550539() - stack.m_30227787(), stack.m_74550539());

            int x = mouseX - (this.f_05230747 - this.backgroundWidth) / 2 + 12;
            int y = mouseY - (this.f_07021018 - this.backgroundHeight) / 2 - 12;
            int w = Math.max(this.f_11884601.m_09235706(name), this.f_11884601.m_09235706(dur));
            int h = stack.m_39273794() ? 20 : 8;

            this.m_58083806(x - 3, y - 3, x + 3 + w, y + 3 + h, -1073741824, -1073741824);
            this.f_11884601.m_27673420(name, x, y, -1);
            if (stack.m_39273794()) {
                this.f_11884601.m_27673420(dur, x, y + 12, 11842740);
            }
            return 0;
        }
        return original.call(instance);
    }
}
