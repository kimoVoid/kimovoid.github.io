package io.github.kimovoid.polished.mixin.client.chat;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_46155730;
import net.minecraft.unmapped.C_63704535;
import net.minecraft.unmapped.C_97866173;
import org.lwjgl.Sys;
import org.lwjgl.input.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(C_97866173.class)
public class GameGuiMixin {

    @Shadow private Minecraft minecraft;
    @Shadow private List<C_46155730> chatMessages;

    @Unique private int chatOffset = 0;

    @Inject(method = "render", at = @At("HEAD"))
    private void chatScroll(float tickDelta, boolean screenOpen, int mouseX, int mouseY, CallbackInfo ci) {
        int chatRangeTop = 20;

        if (this.minecraft.f_70816363 instanceof C_63704535) {
            int currentWheelDegrees = Mouse.getDWheel();
            int numberOfTurns = Math.round((float) currentWheelDegrees / 120.0f);
            if (Sys.getVersion().startsWith("3")) {
                numberOfTurns = currentWheelDegrees;
            }
            this.chatOffset = this.chatOffset + numberOfTurns;

            if (this.chatOffset < 0) {
                this.chatOffset = 0;
            }

            if (chatRangeTop < this.chatMessages.size()) {
                if (this.chatMessages.size() <= (chatRangeTop + this.chatOffset)) {
                    this.chatOffset = this.chatMessages.size() - chatRangeTop;
                }
            } else {
                this.chatOffset = 0;
            }
        } else {
            this.chatOffset = 0;
        }
    }

    @WrapOperation(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/util/List;get(I)Ljava/lang/Object;"
            )
    )
    private Object chatOffset(List<C_46155730> instance, int i, Operation<?> original) {
        return instance.get(i + this.chatOffset);
    }

    @Inject(
            method = "addChatMessage",
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/util/List;add(ILjava/lang/Object;)V",
                    shift = At.Shift.AFTER
            ),
            cancellable = true
    )
    private void removeChatHistoryLimit(CallbackInfo ci) {
        ci.cancel();
    }
}
