package io.github.kimovoid.polished.mixin.client.debug;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.kimovoid.polished.client.PolishedClient;
import io.github.kimovoid.polished.client.feature.debug.DebugScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_76792751;
import net.minecraft.unmapped.C_97866173;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(C_97866173.class)
public class GameGuiMixin {

    @Shadow private Minecraft minecraft;

    @WrapOperation(
            method = "render",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/client/options/GameOptions;debugEnabled:Z",
                    opcode = Opcodes.GETFIELD
            )
    )
    private boolean renderModernDebugScreen(C_76792751 instance, Operation<Boolean> original) {
        if (!PolishedClient.CONFIG.modernDebugScreen.get()) {
            return original.call(instance);
        }

        if (instance.f_63869242) {
            DebugScreen.INSTANCE.renderLeft(this.minecraft);
            DebugScreen.INSTANCE.renderRight(this.minecraft);
        }
        return false;
    }
}
