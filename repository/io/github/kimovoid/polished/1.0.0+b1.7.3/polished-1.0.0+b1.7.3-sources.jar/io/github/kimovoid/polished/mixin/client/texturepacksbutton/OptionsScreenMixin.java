package io.github.kimovoid.polished.mixin.client.texturepacksbutton;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.kimovoid.polished.client.PolishedClient;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.unmapped.C_16154270;
import net.minecraft.unmapped.C_80955943;
import net.minecraft.unmapped.C_85125467;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_88528069;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(C_88528069.class)
public abstract class OptionsScreenMixin extends C_85740840 {

    @WrapOperation(method = "init", at = @At(value = "INVOKE", target = "Ljava/util/List;add(Ljava/lang/Object;)Z", ordinal = 2))
    private boolean addTexturePacks(List<Object> instance, Object obj, Operation<Boolean> original) {
        if (PolishedClient.CONFIG.texturePacksButton.get()) {
            C_16154270 lang = C_16154270.m_56062593();
            boolean sc = FabricLoader.getInstance().isModLoaded("sound-categories");

            original.call(instance, new C_85125467(99, this.f_05230747 / 2 + (sc ? 5 : -100), this.f_07021018 / 6 + (sc ? 0 : 76 + 12), sc ? 150 : 200, 20, lang.m_77288988("options.texturePacks")));
            original.call(instance, sc ? obj : new C_85125467(101, this.f_05230747 / 2 - 100, this.f_07021018 / 6 + 98 + 12, lang.m_77288988("options.video")));
            return true;
        }

        return original.call(instance, obj);
    }

    @Inject(method = "buttonClicked", at = @At("HEAD"))
    private void openPacksScreen(C_85125467 button, CallbackInfo ci) {
        if (button.f_89460239 && button.f_92999450 == 99) {
            this.f_78495264.f_58088711.m_18664673();
            this.f_78495264.m_52715402(new C_80955943(this));
        }
    }
}
