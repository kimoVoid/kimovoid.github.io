package io.github.kimovoid.polished.mixin.client.connection;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_10918870;
import net.minecraft.unmapped.C_28851891;
import net.minecraft.unmapped.C_39588828;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;

@Environment(EnvType.CLIENT)
@Mixin(C_39588828.class)
public abstract class ConnectionMixin {

    @Shadow public abstract void send(C_03562565 packet);

    @WrapOperation(
            method = "read",
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/util/List;add(Ljava/lang/Object;)Z"
            )
    )
    private boolean instantReadPackets(List<C_03562565> queue, Object p, Operation<Boolean> original) {
        if (p instanceof C_28851891) {
            this.send(new C_28851891());
            return true;
        }
        return original.call(queue, p);
    }

    @WrapOperation(method = "tick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/network/packet/Packet;handle(Lnet/minecraft/network/PacketHandler;)V"
            )
    )
    private void handleKeepAlive(C_03562565 packet, C_10918870 packetHandler, Operation<Void> original) {
        if (packet instanceof C_28851891) {
            this.send(new C_28851891());
            return;
        }
        original.call(packet, packetHandler);
    }
}
