package io.github.kimovoid.polished.mixin.server.ping;

import io.github.kimovoid.polished.server.feature.ping.PlayerPing;
import net.minecraft.unmapped.C_49202226;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_49202226.class)
public class ServerPlayerEntityMixin implements PlayerPing {

	@Unique
	private int ping;

	public int getPing() {
		return this.ping;
	}

	public void setPing(int ping) {
		this.ping = ping;
	}
}
