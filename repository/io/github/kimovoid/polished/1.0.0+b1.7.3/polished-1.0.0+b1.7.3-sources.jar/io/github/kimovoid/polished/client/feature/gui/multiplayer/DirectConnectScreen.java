package io.github.kimovoid.polished.client.feature.gui.multiplayer;

import io.github.kimovoid.polished.client.feature.gui.CallbackButtonWidget;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_16154270;
import net.minecraft.unmapped.C_16178213;
import net.minecraft.unmapped.C_43496149;
import net.minecraft.unmapped.C_85125467;
import net.minecraft.unmapped.C_85740840;
import org.lwjgl.input.Keyboard;

public class DirectConnectScreen extends C_85740840 {
    private static final int DEFAULT_PORT = 25565;

    private final C_85740840 parent;
    private C_16178213 addressField;
    private CallbackButtonWidget connectButton;

    public DirectConnectScreen(C_85740840 parent) {
        this.parent = parent;
    }

    public static int parseIntWithDefault(String s, int def) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return def;
        }
    }

    public static void connect(Minecraft minecraft, String addressText) {
        String[] split = addressText.split(":");
        minecraft.m_52715402(new C_43496149(minecraft, split[0], split.length > 1 ? parseIntWithDefault(split[1], DEFAULT_PORT) : DEFAULT_PORT));
    }

    @Override
    public void m_53520780() {
        this.addressField.m_85307449();
    }

    public void m_41805697() {
        Keyboard.enableRepeatEvents(true);

        this.f_78519977.add(connectButton = new CallbackButtonWidget(this.f_05230747 / 2 - 100, this.f_07021018 / 4 + 96 + 12, C_16154270.m_56062593().m_77288988("multiplayer.connect"), button -> {
            String address = this.addressField.m_79292215().trim();
            this.f_78495264.f_58088711.f_29321489 = address.replaceAll(":", "_");
            this.f_78495264.f_58088711.m_18664673();
            connect(this.f_78495264, address);
        }));
        this.f_78519977.add(new CallbackButtonWidget(this.f_05230747 / 2 - 100, this.f_07021018 / 4 + 120 + 12, C_16154270.m_56062593().m_77288988("gui.cancel"), button -> {
            this.f_78495264.m_52715402(this.parent);
        }));
        String lastServer = this.f_78495264.f_58088711.f_29321489.replaceAll("_", ":");
        connectButton.f_89460239 = !lastServer.isEmpty();
        this.addressField = new C_16178213(this, this.f_11884601, this.f_05230747 / 2 - 100, this.f_07021018 / 4 - 10 + 50 + 18, 200, 20, lastServer);
        this.addressField.f_03252369 = true;
        this.addressField.m_59977312(128);
    }

    public void m_47002234() {
        Keyboard.enableRepeatEvents(false);
    }

    protected void m_29116903(char character, int keyCode) {
        this.addressField.m_47314154(character, keyCode);
        if (keyCode == Keyboard.KEY_RETURN) {
            this.m_30778170((C_85125467) this.f_78519977.get(0));
        }

        ((C_85125467) this.f_78519977.get(0)).f_89460239 = this.addressField.m_79292215().length() > 0;
    }

    protected void m_23755539(int mouseX, int mouseY, int button) {
        super.m_23755539(mouseX, mouseY, button);
        this.addressField.m_27301372(mouseX, mouseY, button);
    }

    public void m_93956703(int mouseX, int mouseY, float delta) {
        this.m_34695786();
        this.m_50067982(this.f_11884601, C_16154270.m_56062593().m_77288988("multiplayer.directConnect"), this.f_05230747 / 2, this.f_07021018 / 4 - 60 + 20, 16777215);
        this.m_50067982(this.f_11884601, C_16154270.m_56062593().m_77288988("multiplayer.ipinfo"), this.f_05230747 / 2, this.f_07021018 / 4 - 60 + 60 + 36, 10526880);
        this.addressField.m_30049367();
        super.m_93956703(mouseX, mouseY, delta);
    }
}
