package io.github.kimovoid.polished.client.feature.inventorytweaks;

import io.github.kimovoid.creative.client.gui.CreativeInventoryScreen;
import io.github.kimovoid.creative.tab.CreativeModeTab;
import net.minecraft.unmapped.C_87711245;

public class CreativeIntegration {

    public static int getSlot(C_87711245 screen, int slot) {
        if (screen instanceof CreativeInventoryScreen
                && ((CreativeInventoryScreen)screen).getSelectedTab() == CreativeModeTab.INVENTORY.getId()) {
            return slot - 1;
        }
        return slot;
    }

    public static boolean shouldSkipSlot(C_87711245 screen, int slot) {
        if (screen instanceof CreativeInventoryScreen
                && ((CreativeInventoryScreen)screen).getSelectedTab() != CreativeModeTab.INVENTORY.getId()) {
            return slot < screen.f_76651046.f_84566804.size() - 9;
        }
        return false;
    }
}
