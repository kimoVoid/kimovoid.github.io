package io.github.kimovoid.polished.client.feature.gui.multiplayer;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_79370641;

public class ServerData {

    public String name;
    public String ip;
    public boolean showIp;
    public boolean canPing;
    public long ping;
    public boolean isLoaded;
    public String onlinePlayers;
    public String description;

    public C_74087615 save() {
        C_74087615 nbt = new C_74087615();
        nbt.m_91017064("name", name);
        nbt.m_91017064("ip", ip);
        nbt.m_11270099("showIp", showIp);
        nbt.m_11270099("ping", canPing);
        return nbt;
    }

    public ServerData(C_74087615 nbt) {
        this.name = nbt.m_47517355("name");
        this.ip = nbt.m_47517355("ip");
        this.showIp = nbt.m_25255788("showIp");
        this.canPing = nbt.m_25255788("ping");
    }

    public ServerData(String name, String ip, boolean showIp, boolean ping) {
        this.name = name;
        this.ip = ip;
        this.showIp = showIp;
        this.canPing = ping;
    }

    public static C_79370641 save(List<ServerData> servers) {
        C_79370641 nbt = new C_79370641();
        for (ServerData server : servers) {
            nbt.m_43125067(server.save());
        }
        return nbt;
    }

    public static List<ServerData> load(C_79370641 nbt) {
        ArrayList<ServerData> servers = new ArrayList<>();
        for (int i = 0; i < nbt.m_89439680(); i++) {
            servers.add(new ServerData((C_74087615) nbt.m_59132367(i)));
        }
        return servers;
    }
}