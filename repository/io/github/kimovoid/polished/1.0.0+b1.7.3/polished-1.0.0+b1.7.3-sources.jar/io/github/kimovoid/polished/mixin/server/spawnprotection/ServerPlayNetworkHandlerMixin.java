package io.github.kimovoid.polished.mixin.server.spawnprotection;

import io.github.kimovoid.polished.server.PolishedServer;
import net.minecraft.unmapped.C_99660737;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(C_99660737.class)
public class ServerPlayNetworkHandlerMixin {

    @ModifyConstant(
            method = {
                    "handlePlayerHandAction",
                    "handlePlayerUse"
            },
            constant = @Constant(intValue = 16)
    )
    private int setSpawnProtection(int orig) {
        return PolishedServer.INSTANCE.properties.spawnProtection;
    }
}
