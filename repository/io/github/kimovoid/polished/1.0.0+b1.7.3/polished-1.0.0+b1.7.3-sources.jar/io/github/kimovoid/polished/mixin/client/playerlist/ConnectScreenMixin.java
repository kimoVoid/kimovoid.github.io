package io.github.kimovoid.polished.mixin.client.playerlist;

import io.github.kimovoid.polished.client.PolishedClient;
import net.minecraft.unmapped.C_43496149;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_43496149.class)
public class ConnectScreenMixin {

    @Inject(method = "<init>", at = @At(value = "INVOKE", target = "Ljava/io/PrintStream;println(Ljava/lang/String;)V"))
    public void clearTab(CallbackInfo ci) {
        PolishedClient.INSTANCE.playerList.clear();
    }
}
