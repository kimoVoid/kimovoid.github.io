package io.github.kimovoid.polished.mixin.server.bowsounds;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_76154632;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Environment(EnvType.SERVER)
@Mixin(C_76154632.class)
public class BowItemMixin {

    @WrapOperation(method = "startUsing", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;playSound(Lnet/minecraft/entity/Entity;Ljava/lang/String;FF)V"))
    private void fixBowSound(C_64041439 instance, C_42232651 source, String sound, float volume, float pitch, Operation<Void> original) {
        instance.m_92696259((C_40996800) source, 1002, C_45510667.m_80489169(source.f_78826675), C_45510667.m_80489169(source.f_31030949 - (double) source.f_80245663), C_45510667.m_80489169(source.f_97691941), 0);
    }
}
