package me.kimovoid.reframed.lwjgl3compat.implementation.input;

/**
 * @author Zarzelcow
 * @created 28/09/2022 - 2:14 PM
 */
public interface InputImplementation extends KeyboardImplementation, MouseImplementation {
}
